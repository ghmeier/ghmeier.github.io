import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;


public class OthelloSimpleController implements ActionListener{
	private OthelloModel om;
	private ArrayList<Dimensioned> gameBoard;

	public OthelloSimpleController(OthelloModel om, ArrayList<Dimensioned> gb) {
		this.om = om;
		this.gameBoard = gb;
		for (Dimensioned d: gameBoard) {//adds all the buttons so that the controller can keep track of them
			DimensionedButton dButton = (DimensionedButton) d;
			dButton.addActionListener(this);
		}	
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Dimensioned d = (Dimensioned)ae.getSource();
		try {
			om.occupy(d.getRow(), d.getColumn(), om.getTurn());//occupies the spot based on the button clicked and the player that is supposed to take a turn
		} catch (IllegalMoveException e) {
			System.err.println("Incorrect move");
		} catch (IllegalPlayerException e) {
			System.err.println("Wrong Player");
		}
	}
}
