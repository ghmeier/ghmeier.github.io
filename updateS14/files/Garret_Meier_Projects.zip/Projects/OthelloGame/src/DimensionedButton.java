import javax.swing.JButton;


public class DimensionedButton extends JButton implements Dimensioned {
	private int row;	
	private int column;
	
	public DimensionedButton(int x, int y) {
		this.row = x;
		this.column=y;
	}
	
	@Override
	public int getRow() {
		return this.row;
	}

	@Override
	public int getColumn() {
		return this.column;
	}

}
