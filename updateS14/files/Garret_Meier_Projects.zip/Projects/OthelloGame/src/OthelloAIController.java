import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class OthelloAIController implements ActionListener, ChangeListener {

	private OthelloModel om;
	private ArrayList<Dimensioned> gameBoard;
	private static final int difficulty = 5;
	private static final boolean AI_COLOR = true;

	public OthelloAIController(OthelloModel om, ArrayList<Dimensioned> gb) {
		this.om = om;
		this.gameBoard = gb;
		om.addChangeListener(this);
		for (Dimensioned d: gameBoard) {//adds all the buttons so that the controller can keep track of them
			DimensionedButton dButton = (DimensionedButton) d;
			dButton.addActionListener(this);
		}		
	}
	
	public int[] maxMin(int level, boolean player, int[][] gameBoard) {//odd number of moves please :)
		int[] highestNumber = new int[] {-Integer.MIN_VALUE,0,0};//records the number of pieces, x, and y coords of the best move at current level
		int[][] newBoard = getCopyBoard(gameBoard);//makes a new model so that the old one doesn't change
		OthelloModel model = new OthelloModel(newBoard,player);
		if (level>0  && model.hasLegalMove(player)) {
			ArrayList<int[]> validMoves = this.getValidMoves(model, player);
			for (int[] coordinates: validMoves) {//goes through and takes all valid moves for the player
				//System.out.println("Now checking "+coordinates[0]+" "+coordinates[1]);
				if (om.getTurnNumber()<2) {
					Random r = new Random();
					int[] move = validMoves.get(r.nextInt(validMoves.size()));
					try {
						om.occupy(move[0], move[1], player);
					} catch (IllegalMoveException e) {
						System.err.println(coordinates[0]+","+coordinates[1]+" level " +level);
					} catch (IllegalPlayerException e) {
						System.err.println("Wrong Player "+player);
					}
				} else {
					OthelloModel newModel = new OthelloModel(getCopyBoard(newBoard),player);
					try {
					newModel.occupy(coordinates[0], coordinates[1], player);
					} catch (IllegalMoveException e){
						System.err.println(coordinates[0]+","+coordinates[1]+" level " +level);
					} catch (IllegalPlayerException e) {
						System.err.println("Wrong Player "+player);
					}
					int[] newNumber = new int[] {maxMin(level-1,!player,newModel.getGameBoard())[0],coordinates[0],coordinates[1]};//goes to a deeper level and through those moves
					if (player==AI_COLOR) {//this makes high levels of opponent's pieces a bad thing
						newNumber[0] = -1*newNumber[0];
					}
					if (newNumber[0]>highestNumber[0]){
						highestNumber = new int[]{newNumber[0],coordinates[0],coordinates[1]};//checks to determine the move with the most pieces
						
					}
				}
				//System.out.println("Current Level "+level+" Current Best "+highestNumber[0]+" at "+highestNumber[1]+","+highestNumber[2]);
			}
			//System.out.println(highestNumber[0]);
			return highestNumber;
		} else {//at level 0 it just returns the number of pieces on the board			
			return new int[]{model.getCount(player),0,0};
		}
	}
	
	private int[][] getCopyBoard(int[][] board) {
		int length = board.length;
		int[][] newBoard = new int[length][length];
		for (int i=0;i<board.length;i++) {
			for (int j=0;j<board.length;j++) {
				newBoard[i][j] = board[i][j];
			}
		}
		return newBoard;
	}
	
	private ArrayList<int[]> getValidMoves(OthelloModel model, boolean player) {
		ArrayList<int[]> answer = new ArrayList<int[]>();
		for (int i=0;i<model.getSize();i++) {
			for (int j=0; j<model.getSize();j++) {
				if (model.isLegalMove(i, j, player)) {
					answer.add(new int[]{i,j});
				}
			}
		}
		return answer;
	}
	
	private void takeAITurn(boolean player) {
		if (om.hasLegalMove(player)) {//this takes a turn if there are no legal moves
			int[] move = maxMin(difficulty,player,om.getGameBoard());//The player goes and then it takes the computer's turn
			//System.out.println("AI Turn "+move[1]+" "+move[2]);
			try {
				om.occupy(move[1], move[2], player);
			} catch (IllegalMoveException e) {
				System.out.println("Illegal Computer Move at: "+move[1]+","+move[2]);
			} catch (IllegalPlayerException e) {
				System.out.println("Not this player's turn");
			}
		} else {
			om.takeTurn();
		}
	}
	
	private void takePlayerTurn(Dimensioned d) {
		try {
			//System.out.println("Player Turn");
			om.occupy(d.getRow(), d.getColumn(), !AI_COLOR);//occupies the spot based on the button clicked and the player that is supposed to take a turn
		} catch (IllegalMoveException e) {
			System.err.println("Incorrect Player Move");
		} catch (IllegalPlayerException e) {
			System.err.println("Wrong Player");
		}
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		takePlayerTurn((Dimensioned)ae.getSource());	
	}

	@Override
	public void stateChanged(ChangeEvent ce) {
		OthelloModel model = (OthelloModel)ce.getSource();
		if (model.getTurn()==AI_COLOR) {
			takeAITurn(AI_COLOR);
		} else if (!om.hasLegalMove(!AI_COLOR)){//if the player does not have a legal move then it passes
			om.takeTurn();
		//the player will take a turn after a button press
		}
	}
}
