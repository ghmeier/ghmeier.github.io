import java.awt.Container;
import java.util.Arrays;

import javax.swing.JFrame;



public class OthelloApplication {
	private static boolean hasAI = true;//true lets you play the CPU, false lets you play 2 player
	
	public static void main(String[] args) {
		OthelloModel model;
		try {
			model = new OthelloModel(8);
			OthelloGUIView view = new OthelloGUIView(model);
			//OthelloAITestView view = new OthelloAITestView(model, 10);
			if (!hasAI) {
				OthelloSimpleController controller = new OthelloSimpleController(model, view.getGameBoard());
			}else{
				OthelloAIController controller = new OthelloAIController(model, view.getGameBoard());
			}
			JFrame frame= new JFrame("Othello");
			Container pane = frame.getContentPane();
			pane.add(view);
			frame.pack();
			frame.setVisible(true);

		} catch (IllegalSizeException e) {
			System.out.println("Wrong Size");
		}

		
		
	}
}
