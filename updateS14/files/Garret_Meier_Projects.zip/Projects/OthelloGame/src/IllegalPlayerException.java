
public class IllegalPlayerException extends Exception {

	private static final long serialVersionUID = 1L;

	public IllegalPlayerException() {
		
	}
}
