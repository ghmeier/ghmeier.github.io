import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.color.*;
import java.util.ArrayList;

public class OthelloGUIView extends JPanel implements ChangeListener{
	private JLabel lightLabel = new JLabel("LIGHT");
	private JLabel darkLabel= new JLabel("DARK");
	private JLabel lightCountLabel = new JLabel("0");
	private JLabel darkCountLabel = new JLabel("0");
	private JLabel currentTurnLabel = new JLabel("CurrentTurn: DARK");
	private JLabel turnNumberLabel = new JLabel("Turn Number: 0");
	private JPanel lightPanel = new JPanel();
	private JPanel darkPanel = new JPanel();
	private JPanel titlePanel = new JPanel();
	private JPanel turnPanel = new JPanel();
	private JPanel gameBoardPanel = new JPanel();
	private ArrayList<Dimensioned> gameBoard = new ArrayList<Dimensioned>();
	private OthelloModel om;
	
	public OthelloGUIView(OthelloModel om) {
		this.om = om;
		this.setLayout(new BorderLayout());
		lightPanel.setLayout(new GridLayout(2,1));
		darkPanel.setLayout(new GridLayout(2,1));
		titlePanel.setLayout(new BorderLayout());
		turnPanel.setLayout(new BorderLayout());
		this.add(lightPanel,BorderLayout.WEST);
		lightPanel.add(lightLabel);
		lightPanel.add(lightCountLabel);
		this.add(darkPanel,BorderLayout.EAST);
		darkPanel.add(darkLabel);
		darkPanel.add(darkCountLabel);
		this.add(titlePanel,BorderLayout.NORTH);
		titlePanel.add(currentTurnLabel,BorderLayout.WEST);
		titlePanel.add(turnNumberLabel,BorderLayout.EAST);
		gameBoardPanel.setLayout(new GridLayout(om.getSize(),om.getSize()));
		this.add(gameBoardPanel, BorderLayout.CENTER);
		for (int j=0;j<om.getSize();j++) {
			for (int i=0;i<om.getSize();i++) {
				gameBoard.add(new DimensionedButton(i,j));
			}
		}
		for (Dimensioned d: gameBoard) {
			DimensionedButton db = (DimensionedButton)d;			
			db.setOpaque(true);
			db.setBackground(Color.LIGHT_GRAY);
			gameBoardPanel.add(db);
		}
		makeGameBoard();
		om.addChangeListener(this);
		
	}
	
	public ArrayList<Dimensioned> getGameBoard() {
		return this.gameBoard;
	}

	@Override
	public void stateChanged(ChangeEvent ce) {
		OthelloModel om = (OthelloModel)ce.getSource();
		this.lightCountLabel.setText(om.getCount(true)+"");
		this.darkCountLabel.setText(om.getCount(false)+"");
		//System.out.println(om.toString());
		if (om.getTurn()==true) {
			this.currentTurnLabel.setText("Current Turn: LIGHT");
		} else {
			this.currentTurnLabel.setText("Current Turn: DARK");
		}
		this.turnNumberLabel .setText("Turn Number: "+om.getTurnNumber());
		if (om.gameOver()) {
			makeGameBoard();
			JOptionPane gameOver = new JOptionPane();
			if (om.getCount(om.LIGHT)>om.getCount(om.DARK)) {//puts up a dialog box based on who won the game
				gameOver.showMessageDialog(null, "The Light Side has won with "+om.getCount(om.LIGHT)+" pieces\n you brought balance to the force.", "Game Over", JOptionPane.PLAIN_MESSAGE);
			}else if(om.getCount(om.LIGHT)==om.getCount(om.DARK)) {
				gameOver.showMessageDialog(null, "The game is a tie the struggle to bring\nbalance to the force rages on.", "Game Over", JOptionPane.PLAIN_MESSAGE);
			}else {
				gameOver.showMessageDialog(null, "The Dark Side has won with "+om.getCount(om.DARK)+" pieces\n everyone gets cookies.", "Game Over", JOptionPane.PLAIN_MESSAGE);
			}
			om.reset();
		}
		makeGameBoard();
	}
	
	private void makeGameBoard() {//goes through the buttons in the gameBoard and sets their text based on what they contain
		for (Dimensioned d:gameBoard) {
			DimensionedButton db = (DimensionedButton)d;
			if (om.isOccupiedBy(d.getRow(),d.getColumn(),true)) {
				db.setBackground(Color.WHITE);//setText("L");
			} else if(om.isOccupiedBy(d.getRow(), d.getColumn(), false)) {
				db.setBackground(Color.BLACK);//setText("D");
			}else if(om.isLegalMove(d.getRow(),d.getColumn(),om.getTurn())) {
				db.setBackground(Color.LIGHT_GRAY);//setText("*");
			} else {
				db.setBackground(Color.GRAY);//setText("-");
			}
		}		
	}
	
}
