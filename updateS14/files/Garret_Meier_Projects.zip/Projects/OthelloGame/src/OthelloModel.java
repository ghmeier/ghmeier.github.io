import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class OthelloModel implements Serializable{
	private static final long serialVersionUID = 1L;//Dont know what this does yet

	static private final int[][] boardDirections = new int[][] {{-1,-1},{0,-1},{1,-1},{-1,0},{1,0},{-1,1},{0,1},{1,1}};//directions uplt,up,uprt,lt,rt,dnlt,dn,dnrt
	static private final int MIN_SIZE = 8;//8 is the standard and also the lowest that is interesting
	static public final boolean LIGHT = true;
	static public final boolean DARK = false;
	private List<ChangeListener> changeListeners = new ArrayList<ChangeListener>();//this holds all of the views watching this model
	private int[][] gameBoard;//in the board 0 is empty 1 is light and 2 is dark
	private int size;
	private int turnNumber;
	private boolean currentTurn = false;//it is custom for dark to take the first move
	
	public OthelloModel(int size) throws IllegalSizeException {
		turnNumber = 1;
		if (size>=MIN_SIZE && size%2==0) {
			this.gameBoard = new int[size][size];
			placePiece(size/2, size/2, LIGHT);//sets the game board with the starting four pieces in the middle
			placePiece(size/2-1,size/2-1,LIGHT);
			placePiece(size/2,size/2-1,DARK);
			placePiece(size/2-1,size/2,DARK);
			this.size = size;
		} else {
			throw new IllegalSizeException();
		}
	}
	
	public OthelloModel(int[][] gameBoard,boolean turn){
		turnNumber = 1;
		this.gameBoard = gameBoard;
		this.size=this.gameBoard.length;
		this.currentTurn = turn;
	}
//	public static void main(String[] args) {//this just tests the model it's saved just in case
//		try {
//			OthelloModel model = new OthelloModel(8);
//			System.out.println(model.toString());
//			Scanner s = new Scanner(System.in);
//			while (true) {
//				try{
//					if (model.hasLegalMove(model.getTurn())) {
//						model.occupy(s.nextInt(), s.nextInt(), model.getTurn());
//					} else {
//						model.takeTurn();
//					}
//				} catch (IllegalMoveException e) {
//					System.out.println("WrongMove");
//				} catch (IllegalPlayerException e) {
//					System.out.println("IncorrectPlayer");
//				}
//			System.out.println("Turn "+model.getTurnNumber());
//			System.out.println(model.toString());		 
//			System.out.println("Light:" + model.getCount(LIGHT) + " Dark: " + model.getCount(DARK));
//			}
//
//		} catch (IllegalSizeException e) {
//			System.out.println("Please enter an even number 8 or above");
//		}
//	}
	
	public void reset() {
		this.gameBoard = new int[this.size][this.size];//makes shiny new board ready to play
		this.turnNumber=1;
		this.currentTurn = false;
		placePiece(this.size/2, this.size/2, LIGHT);
		placePiece(this.size/2-1,this.size/2-1,LIGHT);
		placePiece(this.size/2,this.size/2-1,DARK);
		placePiece(this.size/2-1,this.size/2,DARK);
	}
	
	public String toString() {
		String board = "Turn: "+getTurn() +"\n  0 1 2 3 4 5 6 7\n";
		String currentLetter = "";
		for (int j = 0; j<this.gameBoard.length; j++) {
			board = board + j + " ";
			for (int i=0; i<this.gameBoard.length; i++) {
				if (isOccupiedBy(i,j,LIGHT)) {
					currentLetter = "L ";
				} else if (isOccupiedBy(i,j,DARK)) {
					currentLetter = "D ";
				} else {
					currentLetter = ". ";
				}
				board = board + currentLetter;
			}
			board = board + "\n";
		}
		return board;
	}
	
	public int[][] getGameBoard() {
		return this.gameBoard;
	}
	
	public void addChangeListener(ChangeListener cl) {
		this.changeListeners.add(cl);
	}
	
	public void removeChangeListener(ChangeListener cl) {
		this.changeListeners.remove(cl);
	}
	
	public void notifyChangeListeners() {
			for (ChangeListener cl:this.changeListeners) {
				cl.stateChanged(new ChangeEvent(this)); 
			}
	}

	public int getSize() {
		return this.size;
	}
	
	public int getCount(Boolean player) {//goes through the board counting all like pieces
		int count = 0;
		for (int i =0;i<this.size;i++) {
			for (int j=0;j<this.size;j++) {
				if (isOccupiedBy(i,j,player)) {
					count++;
				}
			}
		}
		return count;
	}
	
	public int getTurnNumber() {
		return this.turnNumber;
	}
	
	public boolean getTurn() {
		return this.currentTurn;
	}
	
	public void takeTurn() {//changes the turn to the other color, notifies all observers, and adds to the turn count
		this.currentTurn = !this.currentTurn;
		this.notifyChangeListeners();
		this.turnNumber++;
	}
	
	public boolean isOccupied(int x, int y) {
		return this.gameBoard[x][y]>0;//checks for anything (light, dark, purple, cookie...) on the board at the x,y location on the board
	}
	
	public boolean isOccupiedBy(int x, int y, Boolean player) {
		boolean temp;//goes one step further and says whether or not the piece is the same type as the player variable
		if (this.gameBoard[x][y]==1) {
			temp = true;
		} else if (this.gameBoard[x][y]==2) {
			temp = false;
		} else {
			return false;
		}
		return player==temp;
	}
	
	public void occupy(int x, int y, boolean player) throws IllegalMoveException, IllegalPlayerException {
		if (getTurn()==player) {//make sure the correct player is moving
			if (hasLegalMove(player)) {//this will pass if there is no possible move for the player
				if (isLegalMove(x,y,player)) {//continue if the selected move is legal by the rules of Othello
					placePiece(x, y, player);//just puts the correctly colored piece in the specified spot
					findFriends(x,y,player);//this flips the pieces by the rules of othello
				} else {
					throw new IllegalMoveException();
				}
			}
		} else {
			throw new IllegalPlayerException();
		}
		takeTurn();
	}
	
	private void placePiece(int x, int y, boolean player) {
		int temp;
		if (player == LIGHT) {
			temp = 1;
		} else {
			temp = 2;
		}
		this.gameBoard[x][y]=temp;
	}
	
	public boolean isLegalMove(int x, int y, Boolean player) {//checks to be sure that the proposed placement is not over top of a piece and there is a potential 
		if (!isOccupied(x,y) && hasValidFriend(x,y,player)) { //opposite colored piece to be flipped
			return true;
		} else {
			return false;
		}
	}
	
	private boolean hasValidFriend(int x,int y,boolean player) {//goes in all directions from the x,y to make sure there is a same-colored piece (i.e. friend)
		for (int[] d:boardDirections) {							//more than one space away with an opposite piece in between and that there are no empty spaces in between
			int j=y + d[1];
			for (int i = x+d[0];i<this.size && i>=0 && j>=0 && j<this.size; i=i+d[0]) {
				if (!isOccupied(i,j)) {
					break;
				}else if (isOccupiedBy(i,j,player) && (i>x+1 || i<x-1 || j>y+1 || j<y-1) && (!isOccupiedBy(x+d[0], y+d[1], player))) {
					return true;
				}
				j=j+d[1];
			}
		}
		return false;
	}
	
	public boolean hasLegalMove(boolean player) {//goes through the whole board an looks at all possible moves to be sure that
		for (int i=0; i<this.size;i++) {		  //the specified player has a move to do
			for (int j=0; j<this.size;j++) {
				if (!isOccupied(i,j)) {
					if (isLegalMove(i,j,player)) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public boolean gameOver() {//if no one has a legal move then the game is over
		return !hasLegalMove(LIGHT) && !hasLegalMove(DARK);

	}
	
	private void findFriends(int x,int y,boolean player) {//works similarly to the hasValidFriendMethod, but it also goes and flips the pieces back to the original location
		for (int[] direction: boardDirections) { 
			int j = y+direction[1];
			for (int i=x+direction[0]; i<this.size && i>=0 && j>=0 && j<this.size; i =i+direction[0]) {
				if (!isOccupied(i,j)) {
					break;
				}else if (isOccupiedBy(i,j,player)) {
					int q=i;
					int w=j;
					while (q!=x || w!=y) {
						placePiece(q,w,player);
						w=w-direction[1];
						q=q-direction[0];
					}
					break;
				}
				j=j+direction[1];
			}
		}

	}	
}