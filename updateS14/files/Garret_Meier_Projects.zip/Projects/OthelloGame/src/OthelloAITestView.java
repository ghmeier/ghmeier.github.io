import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class OthelloAITestView implements ChangeListener{
	//private ArrayList<Dimensioned> gameBoard = new ArrayList<Dimensioned>();
	private OthelloModel om;
	private int numberOfTests;
	private int testsComplete;
	private int whiteWins;
	private int darkWins;
	private int ties;
	private ArrayList<Dimensioned> gameBoard = new ArrayList<Dimensioned>();
	
	public OthelloAITestView(OthelloModel om, int numberOfTests) {
		this.om = om;
		this.numberOfTests = numberOfTests;
		for (int j=0;j<om.getSize();j++) {
			for (int i=0;i<om.getSize();i++) {
				gameBoard.add(new DimensionedCoordinates(i,j));
			}
		}
		om.addChangeListener(this);
	}
	
	public ArrayList<Dimensioned> getGameBoard() {
		return this.gameBoard;
	}
	
	@Override
	public void stateChanged(ChangeEvent ce) {
		System.out.println("In View Change");
		if (om.gameOver() && testsComplete<numberOfTests) {
			if (om.getCount(om.LIGHT)>om.getCount(om.DARK)) {//puts up a dialog box based on who won the game
				whiteWins++;
			}else if(om.getCount(om.LIGHT)==om.getCount(om.DARK)) {
				darkWins++;
			}else {
				ties++;
			}
			testsComplete++;
			System.out.println(testsComplete+" of "+numberOfTests+" are complete");
			om.reset();
		} else if(testsComplete>=numberOfTests){
			System.out.println("After all games, White won " +whiteWins+", Black won "+darkWins+", tied "+ties );
		}
	}
	
}
