
public interface Dimensioned {

	public int getRow();
	
	public int getColumn();
	
	
}
