/** Automatically generated file. DO NOT MODIFY */
package com.example.uttower;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}