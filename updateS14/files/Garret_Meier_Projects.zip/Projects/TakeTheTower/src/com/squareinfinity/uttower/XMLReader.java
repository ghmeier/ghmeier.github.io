package com.squareinfinity.uttower;
 //
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import android.content.pm.FeatureInfo;
import android.util.Xml;


public class XMLReader{
	public URL url;
	public String nameSpace = null;
	public final String TITLE = "title";
	public final String PUB_DATE = "pubDate";
	public final String DESCRIPTION = "description";
	public final String OPEN_TAG = "channel";//this tag defines the new rss section
	public final String ITEM_TAG = "item";//this tag separates each item to read
	public final String IMAGE_URL_TAG = "url";
	public static final String IMAGE_DEFAULT_URL = "squareinfinity.com/feed/towerstatus.jpg";

	public XMLReader(String name) {
		try {
			url = new URL(name);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		
	}
	public List<Item> parse() throws XmlPullParserException, IOException {
				XmlPullParser s = Xml.newPullParser();
				s.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
				s.setInput(url.openStream(),null);
				s.nextTag();
				s.nextTag();
				return readFeed(s);	
	}
	
	private List<Item> readFeed(XmlPullParser p) throws XmlPullParserException, IOException {
		List<Item> entries = new ArrayList<Item>();
		
		p.require(XmlPullParser.START_TAG,nameSpace,OPEN_TAG);
		while (p.next() != XmlPullParser.END_TAG) {
			if (p.getEventType() != XmlPullParser.START_TAG) {
				continue;
			}
			String name = p.getName();
			if (name.equals(ITEM_TAG)) {
				entries.add(readItem(p));
			} else {
				skip(p);
			}
		}
		return entries;		
	}
	
	private Item readItem(XmlPullParser p)  throws XmlPullParserException, IOException {
		String title = "";
		String pubDate = "";
		String description ="";
		String url = "";
	    while (p.next() != XmlPullParser.END_TAG) {
	        if (p.getEventType() != XmlPullParser.START_TAG) {
	            continue;
	        }
	        String name = p.getName();
	        if (name.equals(TITLE)) {//these are the tags we're interested in
	            title = readTitle(p);
	        } else if (name.equals(PUB_DATE)) {
	            pubDate = readPubDate(p);
	        } else if (name.equals(DESCRIPTION)) {
	            description = readDescription(p);
	        }else if(name.equals(IMAGE_URL_TAG)){
	        	url = readURL(p);
	        } else {
	            skip(p);//skips tags we don't care about
	        }
	    }
	    return new Item(title,pubDate,description,url);
	}
	
	private String readTitle(XmlPullParser p)  throws XmlPullParserException, IOException{
		p.require(XmlPullParser.START_TAG, nameSpace, TITLE);
		String title = readText(p);
		p.require(XmlPullParser.END_TAG, nameSpace, TITLE);
		return title;
	}
	
	private String readPubDate(XmlPullParser p)  throws XmlPullParserException, IOException{
		p.require(XmlPullParser.START_TAG, nameSpace, PUB_DATE);
		String title = readText(p);
		p.require(XmlPullParser.END_TAG, nameSpace, PUB_DATE);
		return title;
	}
	
	private String readDescription(XmlPullParser p)  throws XmlPullParserException, IOException{
		p.require(XmlPullParser.START_TAG, nameSpace, DESCRIPTION);
		String title = readText(p);
		p.require(XmlPullParser.END_TAG, nameSpace, DESCRIPTION);
		return title;
	}
	
	private String readURL(XmlPullParser p)  throws XmlPullParserException, IOException{
		p.require(XmlPullParser.START_TAG, nameSpace, IMAGE_URL_TAG);
		String title = readText(p);
		p.require(XmlPullParser.END_TAG, nameSpace, IMAGE_URL_TAG);
		return title;
	}
	
	private String readText(XmlPullParser p) throws XmlPullParserException, IOException{
		String answer = "";
		if (p.next() == XmlPullParser.TEXT) {
			answer = p.getText();
			p.nextTag();
		}
		return answer;
	}
	
	private void skip(XmlPullParser p) throws XmlPullParserException, IOException  {
		if (p.getEventType() != XmlPullParser.START_TAG) {
	        throw new IllegalStateException();
	    }
	    int depth = 1;
	    while (depth != 0) {
	        switch (p.next()) {
	        case XmlPullParser.END_TAG:
	            depth--;
	            break;
	        case XmlPullParser.START_TAG:
	            depth++;
	            break;
	        }
	    }
	}
}
