package com.squareinfinity.uttower;

public class Item {
	private String title;
	private String pubDate;
	private String description;
	private String url;
	
	public Item(String t,String pD, String d,String url) {
		this.title = t;
		this.pubDate = pD;
		this.description = d;
		if (url!="") {
			this.url = url;
		} else{
			this.url = XMLReader.IMAGE_DEFAULT_URL;
		}
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public String getPubDate() {
		return this.pubDate;
	}
	
	public String getDescription() {
		return this.description;
	}
	
	public String getURL(){
		return this.url;
	}
}
