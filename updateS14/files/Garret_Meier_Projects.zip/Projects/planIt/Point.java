package planIt;

public abstract class Point extends ListItem {
	private String name;
	private String description;
	private String location;
	private String importance;
	private Date occurs;
	
	public static String[] importances = new String[]{"HIGH","MED","LOW"};
	
	public Point(String name, int x, int y) {
		super(x,y);
		this.name = name;
	}
	
	
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return this.description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getLocation() {
		return this.location;
	}
	
	public void setLocation(String location) {
		this.location = location;
	}
	
	public String getImportance() {
		return this.importance;
	}
	
	public void setImportance(int importanceCount) {//Based on the value assigned by the user, the import is either LOW, MED, or HIGH
		this.importance = importances[importanceCount];
	}
	
	public Date getOccurance() {
		return this.occurs;
	}
	
	public void setOccurance(String toOccur) {//Takes the user string and parses it into an int[] which can be used to create a Date
		this.occurs = new Date(Date.stringToDays(toOccur));
	}
	
	
}
