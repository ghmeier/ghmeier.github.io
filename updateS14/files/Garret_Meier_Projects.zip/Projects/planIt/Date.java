package planIt;

public class Date {
	private int year;
	private int month;
	private int day;
	private int hour;
	private int minute;
	
	public Date(int[] dates) {
		this.year = dates[0];
		this.month = dates[1];
		this.day = dates[2];
		this.hour = dates[3];
		this.minute = dates[4];
	}
	
	public int getYear() {
		return this.year;
	}
	
	public int getMonth() {
		return this.month;
	}
	
	public int getDay() {
		return this.day;
	}
	
	public int getHour() {
		return this.hour;
	}
	
	public int getMinute() {
		return this.minute;
	}
	
	public static int[] stringToDays(String toChange) {
		int[] answer = new int[5];
		
		return answer;
	}
}
