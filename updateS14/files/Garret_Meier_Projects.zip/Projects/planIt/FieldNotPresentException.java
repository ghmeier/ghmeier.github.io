package planIt;

public class FieldNotPresentException extends Exception {
	public FieldNotPresentException(String s) {
		super(s);
	}
}
