package planIt;

public class Note extends Point {

	public Note(String name, int x, int y) {
		super(name,x,y);
		// TODO Auto-generated constructor stub
	}

}
