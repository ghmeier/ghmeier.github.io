package planIt;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

public class PlanItGUIController implements ActionListener{
	private PlanItModel model;
	private GUIView view;
	
	public PlanItGUIController (PlanItModel model, GUIView view) {
		this.model = model;
		this.view = view;
		view.getLeftCalButton().addActionListener(this);
		view.getRightCalButton().addActionListener(this);
		
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object source = ae.getSource();
		if (source.equals(this.view.getLeftCalButton())) {
			//System.out.println("Left");
			view.calendar.roll(Calendar.MONTH, false);
			if (view.calendar.get(Calendar.MONTH)==11) { 
				view.calendar.roll(Calendar.YEAR, false);
			}
			view.refreshCalendar();
		} else if(source.equals(this.view.getRightCalButton())) {

			view.calendar.roll(Calendar.MONTH,true);
			//System.out.println(view.calendar.get(Calendar.MONTH));
			if (view.calendar.get(Calendar.MONTH)==0) {
				view.calendar.roll(Calendar.YEAR,true);
			}
			view.refreshCalendar();
		}
	}
	
	
}
