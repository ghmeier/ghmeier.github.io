package planIt;

public abstract class ListItem {
	protected int[] position;
	
	public ListItem(int x, int y) {
		this.position = new int[2];
		this.position[0] = x;
		this.position[1] = y;
		
	}
 	
	public int[] getPosition() {
		return this.position;
	}
	
	public void setPosition(int x, int y) {
		this.position[0] = x;
		this.position[1] = y;
	}
}
