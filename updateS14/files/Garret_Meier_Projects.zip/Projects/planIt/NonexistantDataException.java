package planIt;

public class NonexistantDataException extends Exception {
	public NonexistantDataException(String name) {
		super(name);
	}
}
