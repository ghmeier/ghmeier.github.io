package planIt;

import java.util.ArrayList;

public class PointHolder extends ListItem{
	private String name;
	private ArrayList<Point> points;
	
	public PointHolder(String name, Point firstPoint,int x, int y) {
		super(x,y);
		this.name = name;
		points.add(firstPoint);
	}
	
	protected ArrayList<Point> getPoints() {
		return this.points;
	}
	
	public void addPoint(Point toAdd) {
		this.points.add(toAdd);
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getTotalPoints() {
		return points.size();
	}
	
	public Point getPointAt(int index) {
		return points.get(index);
	}
	
	//TODO: Sorting by various point aspects? 
}
