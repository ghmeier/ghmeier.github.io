package planIt;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.ChangeListener;

public class PlanItModel {

	private List<ChangeListener> listeners;
	private List<PointHolder> containers;
	private List<Point> eventsAndNotes;
	
	public PlanItModel() {
		this.listeners = new ArrayList<ChangeListener>();
		this.containers = new ArrayList<PointHolder>();
		this.eventsAndNotes = new ArrayList<Point>();
	}
	
	public PlanItModel(List<Point> eventsAndNotes, List<PointHolder> containers) {
		this.eventsAndNotes = eventsAndNotes;
		this.containers = containers;
	}
	
	public void addPoint(Point toAdd) {
		this.eventsAndNotes.add(toAdd);
	}
	
	public void addContainer(PointHolder toAdd) {
		this.containers.add(toAdd);
	}
	
	public void addToContainer(String containerName, Point toAdd) throws NonexistantDataException {
		containers.add(getContainer(containerName));
	}
	
	public PointHolder getContainer(String containerName) throws NonexistantDataException {
		for (PointHolder c : this.containers) {
			if (c.getName().equals(containerName)) {
				return c;
			}
		}
		throw new NonexistantDataException(containerName); 
	}
	
	public Point getPoint(String pointName) throws NonexistantDataException {
		for (Point p : this.eventsAndNotes) {
			if (p.getName().equals(pointName)) {
				return p;
			}
		}
		throw new NonexistantDataException(pointName);
	}
	
	
}
