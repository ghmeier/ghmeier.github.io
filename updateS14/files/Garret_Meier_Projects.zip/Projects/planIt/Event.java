package planIt;

public class Event extends Point {

	public Event(String name, int x, int y) {
		super(name,x,y);
		// TODO Auto-generated constructor stub
	}

}
