package planIt;

import java.awt.Button;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.LayoutManager;
import java.util.Calendar;
import java.util.Locale;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class GUIView extends JPanel implements ChangeListener{
	public PlanItModel model;	
	private Locale currentLocale = Locale.US;
	public Calendar calendar = Calendar.getInstance(currentLocale);
	private LayoutManager theLayout = new GridBagLayout();
	private GridBagConstraints constraints = new GridBagConstraints();
	private GridBagConstraints c = new GridBagConstraints();//calendar constraints
	private GridBagConstraints ec = new GridBagConstraints();//edit constraints
	private JPanel calendarPanel = new JPanel();
	private JPanel editPanel = new JPanel();
	private JPanel showPanel = new JPanel();
	private JButton leftCalButton = new JButton("<<");
	private JButton rightCalButton = new JButton(">>");
	private JLabel month = new JLabel(calendar.getDisplayName(Calendar.MONTH, Calendar.LONG, this.currentLocale) + " " + calendar.get(Calendar.YEAR));
	private JLabel[] dayName = new JLabel[]{new JLabel("SUN"),new JLabel("MON"),new JLabel("TUE"),new JLabel("WED"),new JLabel("THU"),new JLabel("FRI"),new JLabel("SAT")};
	private JLabel[][] days = new JLabel[7][6];
	
	public GUIView(PlanItModel model) {
		this.model = model;
		this.calendar = Calendar.getInstance();
		this.currentLocale = Locale.US;
		this.setLayout(theLayout);
		
		this.constraints.ipadx = 2;//initial and unchanged constraints
		this.constraints.ipady = 2;
		this.constraints.weightx = 1;
		this.constraints.weighty = 1;
		this.constraints.fill = GridBagConstraints.BOTH;
		
		calendarPanel.setBackground(new Color(255,0,0));//yaya for colors :)
		editPanel.setBackground(new Color(0,255,0));
		showPanel.setBackground(new Color(0,0,255));
		
		this.constraints.gridheight = 1;//rules for calendarPanel
		this.constraints.gridwidth = 2;
		this.constraints.gridx = 0;
		this.constraints.gridy = 0;
		this.add(calendarPanel,constraints);
		
		setUpCalendar(calendarPanel);//just Something to clear up some code to the bottom
		setUpEdit(editPanel);
		
		this.constraints.gridheight = 2;//rules for editPanel
		this.constraints.gridx = 0;
		this.constraints.gridy = 1;
		this.add(editPanel,constraints);
		
		this.constraints.gridheight = 3;//rules for showPanel
		this.constraints.gridwidth = 3;
		this.constraints.gridx = 2;
		this.constraints.gridy = 0;
		this.add(showPanel,constraints);		
	}
	
	public static void main(String[] args) {
		PlanItModel model = new PlanItModel();
		GUIView view = new GUIView(model);
		PlanItGUIController controller = new PlanItGUIController(model, view);
		JFrame frame = new JFrame("RememberMe");
		Container pane = frame.getContentPane();
		pane.add(view);
		frame.setSize(800, 600);
		frame.setVisible(true);
	}
	
	public void changed(PlanItModel model) {
		
	}
	
	public void refreshCalendar() {
		for (int i=0;i<days[0].length;i++) {
			for (int j=0;j<days.length;j++) {
				days[j][i].setText("");
			}
		}
		month.setText(calendar.getDisplayName(Calendar.MONTH, Calendar.LONG, this.currentLocale) + " " + calendar.get(Calendar.YEAR));
		calendar.set(Calendar.DATE, 1);
		int dayOfFirst = calendar.get(Calendar.DAY_OF_WEEK)-1;
		for (int i=0;i<calendar.getMaximum(Calendar.DATE);i++) {
			int currentDay = calendar.get(Calendar.DAY_OF_WEEK)-1;
			int currentWeek = calendar.get(Calendar.WEEK_OF_MONTH)-1;
				//c.gridx = currentDay;
				//c.gridy = currentWeek+3;
				String currentDayText = Integer.toString(calendar.get(Calendar.DATE));
				//System.out.println(currentDayText + " " + calendar.get(Calendar.MONTH));
				days[currentDay][currentWeek].setText(currentDayText);
				calendar.roll(Calendar.DATE,true);
				//getCalPanel().add(days[currentDay][currentWeek],c);
		}
	}
	
	public void setUpCalendar(JPanel panel) {

		LayoutManager layout = new GridBagLayout();
		panel.setLayout(layout);
		leftCalButton.setBackground(new Color(0,0,0,0));
		leftCalButton.setBorder(new EmptyBorder(0,0,0,0));
		leftCalButton.setFocusPainted(false);
		leftCalButton.setContentAreaFilled(false);
		rightCalButton.setBackground(new Color(0,0,0,0));
		rightCalButton.setBorder(new EmptyBorder(0,0,0,0));
		rightCalButton.setFocusPainted(false);
		rightCalButton.setFocusPainted(false);
		month.setHorizontalAlignment(JLabel.CENTER);
		c.weightx = 2;
		c.weighty = 2;
		c.fill = GridBagConstraints.HORIZONTAL;
		
		c.gridheight  = 1;
		c.gridwidth = 2;
		c.gridx = 0;
		c.gridy = 0;
		panel.add(leftCalButton,c);
		c.gridwidth = 3;
		c.gridx = 2;
		panel.add(month,c);
		c.gridwidth = 2;
		c.gridx = 5;
		panel.add(rightCalButton,c);
		c.gridwidth = 1;
		c.gridx = 0;
		c.gridy = 2;
		for (int i=0; i<dayName.length;i++) {
			c.gridx = i;
			panel.add(dayName[i],c);
		}
		c.gridy = 2;
		//
		for (int i=0;i<days[0].length;i++) {
			for (int j=0;j<days.length;j++) {
				days[j][i] = new JLabel();
				c.gridx = j;
				c.gridy = i+3;
				panel.add(days[j][i],c);
			}
		}
		calendar.set(Calendar.DATE, 1);
		int dayOfFirst = calendar.get(Calendar.DAY_OF_WEEK)-1;
		for (int i=0;i<calendar.getMaximum(Calendar.DATE);i++) {
			int currentDay = calendar.get(Calendar.DAY_OF_WEEK)-1;
			int currentWeek = calendar.get(Calendar.WEEK_OF_MONTH)-1;

				String currentDayText = Integer.toString(calendar.get(Calendar.DATE));
				days[currentDay][currentWeek].setText(currentDayText);
				calendar.roll(Calendar.DATE,true);
				//panel.add(days[currentDay][currentWeek],c);
		}
	}
	
	public void setUpEdit(JPanel panel) {
		LayoutManager layout = new GridBagLayout();
		panel.setLayout(layout);
		JButton addButton = new JButton("Add");
		JButton delButton = new JButton("Remove");
		JLabel name = new JLabel("Name:");
		JLabel description = new JLabel("Description:");
		JLabel date = new JLabel("Date:");
		JLabel priority = new JLabel("Priority:");
		JRadioButton LowPriorityButton = new JRadioButton("LOW");
		JRadioButton MedPriorityButton = new JRadioButton("MED");
		JRadioButton HighPriorityButton = new JRadioButton("HIGH");
		ButtonGroup priorityButtons = new ButtonGroup();
		priorityButtons.add(LowPriorityButton);
		priorityButtons.add(MedPriorityButton);
		priorityButtons.add(HighPriorityButton);
		
		ec.weightx = 2;
		ec.weighty = 2;
		//ec.fill = GridBagConstraints.HORIZONTAL;		
		ec.gridheight  = 1;
		ec.gridwidth = 2;
		
		ec.gridx = 0;
		ec.gridy = 0;	
		panel.add(addButton,ec);
		
		ec.gridx = 2;
		panel.add(delButton,ec);
		
		ec.gridwidth = 1;
		ec.gridx = 0;
		ec.gridy = 1;
		panel.add(name,ec);
		
		ec.gridy =2;
		panel.add(description,ec);
		
		ec.gridy = 3;
		panel.add(date,ec);
		
		ec.gridy = 4;
		panel.add(priority,ec);
		
		ec.gridx = 1;
		ec.gridy = 4;
		panel.add(LowPriorityButton,ec);
		ec.gridy = 5;
		panel.add(MedPriorityButton,ec);
		ec.gridy = 6;
		panel.add(HighPriorityButton,ec);
		
	}
	
	public JButton getLeftCalButton() {
		return this.leftCalButton;
	}
	
	public JButton getRightCalButton() {
		return this.rightCalButton;
	}
	
	public JPanel getCalPanel() {
		return this.calendarPanel;
	}

	@Override
	public void stateChanged(ChangeEvent ce) {
		PlanItModel model = (PlanItModel)ce.getSource();
		
		//this is what happens when something in the model changes
	}
}
