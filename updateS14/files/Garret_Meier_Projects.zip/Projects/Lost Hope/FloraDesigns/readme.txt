The first line of text is the type
5=oak tree
6=birch tree
7=flower/sapling
8=Cactus
the second two lines are width and height
[x]
[y]
then number of layers
after that its symbols to make the shape
O=oak
B=birch
L=Leaf
C=Cactus
!=red flower
@=yellow flower
S=sapling