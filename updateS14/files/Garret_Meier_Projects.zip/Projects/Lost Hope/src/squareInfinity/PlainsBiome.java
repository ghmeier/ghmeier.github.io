package squareInfinity;

public class PlainsBiome extends Biome {

	public PlainsBiome(int startX, int startY,int width, byte type) {
		super(startX,startY,width,type);
		
		this.validTerrainTypes = new TerrainType[] {new SuperFlat(), new SemiFlat()};
		for (Design d:WorldGenerator.floraDesigns) {
			byte currentType = (byte) d.getType();
			if (currentType==Design.FLOWER) {
				this.validFloraDesigns.add(d);
			}
		}
	}
//	@Override
//	protected void fillArea() {
//		// TODO Auto-generated method stub
//
//	}

}
