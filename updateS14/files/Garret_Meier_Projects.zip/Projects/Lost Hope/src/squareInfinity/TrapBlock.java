package squareInfinity;

import java.io.IOException;

public class TrapBlock extends GameBlock{

	public TrapBlock(byte type, int x, int y) throws IOException {
		super(type, x, y);
		
	}

}
