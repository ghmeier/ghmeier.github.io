package squareInfinity;

import javax.swing.JButton;

public class GridButton extends JButton{
	
	private int gridX;
	private int gridY;
	
	private byte value;
	
	public GridButton(String name, int x, int y){
		super(name);
		
		this.value = 0;
		
		this.gridX = x;
		this.gridY = y;
	}
	
	public byte getValue(){
		return this.value;
	}
	
	public int getGridX(){
		return this.gridX;
	}
	
	public int getGridY(){
		return this.gridY;
	}
	

}
