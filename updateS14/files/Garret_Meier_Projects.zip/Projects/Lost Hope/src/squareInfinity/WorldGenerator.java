package squareInfinity;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.swing.SwingWorker;

import squareInfinity.npc.Bear;
import squareInfinity.npc.Bunny;
import squareInfinity.npc.Butterfly;
import squareInfinity.npc.Wolf;


public class WorldGenerator extends SwingWorker<Void, String>{

	protected LostHope controller;
	protected Location location;
	protected Location[] locations=new Location[4];
	
	public static Random theRandomizer = new Random(LostHope.SEED);//The all important random seed
	protected int villageMax = (int)(theRandomizer.nextDouble()*2+1);
	protected int width;
	protected int seaLevel;
	protected int height;
	 
	public static ArrayList<Design> houseDesigns;
	public static ArrayList<Design> floraDesigns;
	public static ArrayList<Biome> biomes = new ArrayList<Biome>();
	private int numberOfBiomes = 3;
	
	private static final byte NOTHING = -1;
	
	public WorldGenerator(int width, LostHope controller){
		this.controller = controller;
		int height=width*2/3;
		this.width = width/LostHope.BLOCKSIDE;//switching from global coords to a 32x32 grid
		this.height = height/LostHope.BLOCKSIDE;
		this.seaLevel = height/(4*LostHope.BLOCKSIDE);
		
		houseDesigns = new ArrayList<Design>();
		this.loadDesigns(houseDesigns,"HouseDesigns");
		floraDesigns = new ArrayList<Design>();
		this.loadDesigns(floraDesigns,"FloraDesigns");
	}
	
	public void loadDesigns(ArrayList<Design> designs, String fileName){
		//File readmeFile = new File("HouseDesigns/readme.txt");
		File directory = new File(fileName);

		File[] files = directory.listFiles();
		
		//houseDesigns = new HouseDesign[0];
		
		try {
			Scanner s;
			
			//int amountOfDesigns = s.nextInt();
			
			//houseDesigns = new HouseDesign[amountOfDesigns];
			
			for(int i = 0; i<files.length; i++){
				StringTokenizer st = new StringTokenizer(files[i].getName(), "-");
				
				String modifier = st.nextToken();
				
				if(modifier.equalsIgnoreCase("design")){
					
					File f = files[i];
					s = new Scanner(f);
					
					byte type = s.nextByte();
					int width = s.nextInt();
					int height = s.nextInt();
					int maxLayers = s.nextInt();
					
					Design design = new Design(width, height,type,maxLayers);
					
					s.nextLine();
					for (int layer = 0; layer<maxLayers; layer ++){
						for(int y = 0; y<height; y++){
							String line = s.nextLine();
							line.trim();
							
							//System.err.println("line " + y + ": <<" + line + ">>");
							
							char[] letters = line.toCharArray();
							
							for(int x = 0; x<letters.length; x ++){
								byte value = 0;
								if (fileName.equals("HouseDesigns")) {
									if(letters[x] == 'W'){
										value = GameBlock.WOOD_PLANK;
									}else if(letters[x] == '-'){
										value = GameBlock.STONE_WALL;
									}else if(letters[x] == 'S'){
										value = GameBlock.WOOD_STAIRS;
									}else if(letters[x]=='*') {
										value = GameBlock.WORKBENCH;
									} else if(letters[x]=='T') {
										value = GameBlock.TABLE;
									} else if(letters[x]=='C') {
										value = GameBlock.CHAIR;
									} else if(letters[x] =='^') {
										value = GameBlock.CHEST;
									} else if(letters[x]=='B') {
										value = GameBlock.BED;
									} else if(letters[x]=='#') {
										value = GameBlock.STONE_BLOCK;
									}  else if(letters[x]=='F') {
										value = GameBlock.FURNACE;
									} else if(letters[x]=='A'){
										value = GameBlock.ANVIL;
									} else if(letters[x] =='L') {
										value = GameBlock.LADDER;	
									}
								} else if(fileName.equals("FloraDesigns")) {
									if(letters[x] =='O') {
										value = GameBlock.OAK_WOOD;
									} else if(letters[x] =='L') {
										value = GameBlock.LEAF;
									} else if(letters[x] =='B') {
										value = GameBlock.BIRCH_WOOD;
									} else if(letters[x] =='!') {
										value = GameBlock.RED_FLOWER;
									} else if(letters[x] =='@') {
										value = GameBlock.YELLOW_FLOWER;
									} else if (letters[x]=='S') {
										value = GameBlock.SAPLING;
									} else if (letters[x]=='C') {
										value = GameBlock.CACTUS;
									}
								}
								design.set(x, y,layer, value);
							}
						}
						
						designs.add(design);
					}
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public void generateWorld(){
		execute();
	}
	
	@Override
	protected Void doInBackground() {
		try{
			for(int i=0; i<4; i++){
				location = new Location(width*LostHope.BLOCKSIDE, height*LostHope.BLOCKSIDE, "Created Location", "createdLocation", controller);
				location.startGenerating();
				LostHope.factory.setLocationToEdit(location);
				fillLocationWith(0,seaLevel,width,height,i==0);//this makes the world according to the size of the WorldGeneartor object
				location.setSeaLevel((seaLevel * LostHope.BLOCKSIDE));
				location.finishGenerating();
				locations[i]=location;
			}
		}catch(Exception e){e.printStackTrace();}
		return null;
	}
	
	@Override
	protected void process(List<String> chunks) {
		controller.showLoading(getProgress(), chunks.get(chunks.size()-1));
	}
	
	public void fillLocationWith(int startX, int startY, int endX, int endY, boolean placePlayer){
		int firstY = 0;
		int villageCount = 0;
		setProgress(0);
		publish("Placing Pixels");
		for (int currentX = startX; currentX<=endX-16; currentX=currentX+16) {//starts at the left and goes right by chunks				
			startY = createChunk(currentX,startY,16, endY, false);	
			double truePercent = (double)currentX / ((double) endX);
			int percent = (int)(truePercent*100);					
			if(currentX == startX){
				firstY = startY;
			}
			setProgress(percent);
			publish("Placing Pixels");
		}
		
		for (int x=1; x<this.width; x++) {//starts at left for making caves
			double truePercent = (double)x / ((double)this.width);				
			int percent = (int) (truePercent * 100);
			
			for (int y=1; y<this.height; y++) {	
					if (theRandomizer.nextDouble()<.001) {
						createCave(x,y,(int)(theRandomizer.nextDouble()*20+5));//makes a cave that can contain up to 25 sections
					}		
			}
			setProgress(percent);
			publish("Spelunking");
		}
		
		fillLiquid();// Put H2O here when it works
		
		for (int x=2;x<this.width-64;x++) {
			double truePercent = (double)x / ((double)this.width);				
			int percent = (int) (truePercent * 100);
			setProgress(percent);
			publish("Building Civilization");
			if (theRandomizer.nextDouble()<.1 && villageCount<villageMax) {
				for (int y=0; y<this.seaLevel; y++) {
					if (LostHope.factory.getCollidingGameObject(x*LostHope.BLOCKSIDE, y*LostHope.BLOCKSIDE,1,1)!=null){
							x=createVillage(x,y);
							villageCount ++;
							y=this.seaLevel+1;
					}
					
				}			
			}
		}
		
		for (int x=1; x<this.width-3; x++) {
			for (int y=1; y<=this.seaLevel; y++){
				GameObject object = LostHope.factory.getCollidingGameObject(x*LostHope.BLOCKSIDE, y*LostHope.BLOCKSIDE,1,1); 
				if (object!=null){
					if (object.getType()==GameBlock.DIRT 
						&& LostHope.factory.getCollidingGameObject(x*LostHope.BLOCKSIDE, (y-1)*LostHope.BLOCKSIDE,1,1)==null){
						createFlora(x,y);
						/*if (x==20) {
						NPC gerard = LostHope.factory.createNPC(new Wolf("Gerard",x*LostHope.BLOCKSIDE,y*LostHope.BLOCKSIDE,location));
						gerard.setY(gerard.getY()-(gerard.getHeight()*2));
						gerard.setX(gerard.getWidth()+gerard.getX());
						}*/
						double animalCheck = theRandomizer.nextDouble();
						if (animalCheck < .02) {//this number effects how common the animal is to see, change it for testing
							NPC rainbow = LostHope.factory.createNPC(new Butterfly("Rainbow",x*LostHope.BLOCKSIDE,y*LostHope.BLOCKSIDE,location));
							rainbow.setY(rainbow.getY() - (rainbow.getHeight() * 2));
						}else if(animalCheck<.04) {
							NPC patsy = LostHope.factory.createNPC(new Bunny("Patsy",x*LostHope.BLOCKSIDE,y*LostHope.BLOCKSIDE,location));
							patsy.setY(patsy.getY()-(patsy.getHeight()*2));
						} else if(animalCheck<.06) {
							for (int i=0; i<theRandomizer.nextInt(2)+1;i++) {
								NPC gerard = LostHope.factory.createNPC(new Wolf("Gerard",x*LostHope.BLOCKSIDE,y*LostHope.BLOCKSIDE,location));
								gerard.setY(gerard.getY()-(gerard.getHeight()*2));
							}
						} else if(animalCheck<.07) {
							NPC ulgar = LostHope.factory.createNPC(new Bear("Ulgar",x*LostHope.BLOCKSIDE,y*LostHope.BLOCKSIDE,location));
							ulgar.setY(ulgar.getY()-(ulgar.getHeight() * 2));
						}
						y=seaLevel+1;
					}
				}
			}	
		}

		if(placePlayer){
			Player player = controller.getCurrentPlayer();
			
			player.setY((firstY*LostHope.BLOCKSIDE - player.getHeight()));
			player.setX((startX+16)*LostHope.BLOCKSIDE);//creates a the player at the correct spot
		}

	}
	
	public int createChunk(int startX, int currentY,int length, int endY, boolean isFlat) {
		
		TerrainType[] allTypes = new TerrainType[] {new SuperFlat(), new SemiFlat(), new UpSlope(), new DownSlope()};//creates an array for the terrain types to choose from
		int chunkType;
		if (currentY>seaLevel+20) {//prevents giant trenches
			chunkType=(int)(theRandomizer.nextDouble()*(allTypes.length-1));
		} else {
			chunkType=(int)(theRandomizer.nextDouble()*(allTypes.length));//chooses a type from them all
		}
		
		boolean isDesert = false;
		if (chunkType==0 && theRandomizer.nextDouble()>.5) {
			isDesert = true;
		}
		
		for (int x=startX; x<startX+length; x++) {
			
			double maxDepth;//calculating the maximum depth for the wedges
			if (x<=this.width/2) {
				maxDepth = ((this.width/2.0)/(this.height-this.seaLevel))*x+this.seaLevel;
			} else {
				maxDepth = ((-this.width/2.0)/(this.height-this.seaLevel))*(x-this.width)+this.seaLevel;
			}
			
			int modifier;
			if (!isFlat) {
				modifier = allTypes[chunkType].getModifier();
			} else {
				modifier = 0;
			}
			int nextY = currentY +modifier;//Sets the next 'top' block to be a random amount higher or lower than previous 
			
			if (nextY<0) {//this limits the max height and depth to prevent array index problems....
				nextY=0;
			} else if (nextY>=(this.height)) {
				nextY = (this.height)-1;
			}
			
			if(nextY <=maxDepth) {//making sure its within the wedge
				if (nextY<=this.seaLevel || isDesert) {
					LostHope.factory.createGameObject(GameBlock.DIRT, x*LostHope.BLOCKSIDE, nextY*LostHope.BLOCKSIDE  );//places the top grass block
				} else {
					LostHope.factory.createGameObject(GameBlock.SAND, x*LostHope.BLOCKSIDE, nextY*LostHope.BLOCKSIDE);
				}
			}
			currentY = nextY;
			
//			if(currentY > this.seaLevel ){
//				fillLiquid(x,currentY-1,GameBlock.WATER);//puts water below sea level
//			}
			
			int dirtDepth = (int)(theRandomizer.nextDouble()*3) + 3;
			for(int y=currentY+1; y< currentY + dirtDepth+1; y++){ // 5 is the height of dirt below

				if (y<maxDepth ) {//keeps everything inside the wedge
					GameObject toCheck = LostHope.factory.getCollidingGameObject(x*LostHope.BLOCKSIDE, (y-1)*LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, LostHope.BLOCKSIDE);

					if( toCheck!=null && toCheck.getType()==GameBlock.SAND){
						LostHope.factory.createGameObject(GameBlock.SAND, x*LostHope.BLOCKSIDE, y * LostHope.BLOCKSIDE);
					} else {
						LostHope.factory.createGameObject(GameBlock.DIRT, x*LostHope.BLOCKSIDE, y * LostHope.BLOCKSIDE);
					}
				}
			}

			for(int y=currentY+dirtDepth+1; y < maxDepth ; y++){//places stone to the max depth
				GameObject toCheck = LostHope.factory.getCollidingGameObject(x*LostHope.BLOCKSIDE, (y-1)*LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, LostHope.BLOCKSIDE);
				if (toCheck!=null && toCheck.getType()==GameBlock.SAND && theRandomizer.nextDouble()<.5) {
					LostHope.factory.createGameObject(GameBlock.SANDSTONE, x*LostHope.BLOCKSIDE, y * LostHope.BLOCKSIDE);	
				} else {
					LostHope.factory.createGameObject(GameBlock.ROCK, x*LostHope.BLOCKSIDE, y * LostHope.BLOCKSIDE);
				}
				createOre(x,y,4,GameBlock.DIRT,(-4*.001/height/height)*y*(y-(.5*height)));
				createOre(x,y,3,GameBlock.COAL_VEIN,(-16*.005/height/height/9)*y*(y-(.75*height)));//coal starts being open to form at y of 0 and stops at 3height/4 with a max abundance of .005
				createOre(x,y,3,GameBlock.COPPER_VEIN,(-4*.002/height/height)*y*(y-(.5*height)));//starts at the top and goes to half way at .002
				createOre(x,y,3,GameBlock.TIN_VEIN,(-4*.002/height/height)*y*(y-(.5*height)));
				createOre(x,y,3,GameBlock.IRON_VEIN,-1/Math.pow((y),2)+.0005);//iron starts forming at sea level and slowly gets more abundant until .001
				createOre(x,y,4,GameBlock.MARBLE,(-98*.003/height/height/3.125)*(y-height/2)*(y-6*height/7));//marble starts at h/2 and goes to 6h/7 with a .003 abundance
				createOre(x,y,4,GameBlock.GRANITE,(-196*.003/height/height/3)*(y-2*height/7)*(y-4*height/7));//granite starts at 2h/7 and goes to 4h/7 with a .003 abundance
				createOre(x,y,2,GameBlock.ADAMANTINE_VEIN,.0002*(1-Math.exp(-y+height/2)));
				createOre(x,y,2,GameBlock.GOLD_VEIN,.0003*(1-Math.exp(-y+height/2.5)));//All of these are exponential growth stopped at either .0002 or .0003
				createOre(x,y,2,GameBlock.MITHRIL_VEIN,.0002*(1-Math.exp(-y+height/2)));
				createOre(x,y,2,GameBlock.DIAMOND_VEIN,.0001/(1+Math.exp(-y+(height*.625))));//logistical growth that always provides some chance of finding but is only significant by 5h/8 at .0001
				createOre(x,y,2,GameBlock.URANIUM_VEIN,(.0001/(1+Math.exp(-y+(height*.625)))));
			}			
		}

		return currentY;//returns the end y for generating the next chunk
	}
	
	private void createCave(int startX, int startY, int iterationsLeft) {
		if (startX>=this.width-1) {//keeps things in bounds
			startX=this.width-2;
		} else if (startX<=0) {
			startX = 1;
		} else if (startY>=this.height-1) {
			startY = this.height-2;
		} else if (startY<=0) {
			startY = 1;
		}
		int[] nextCoords = new int[] {startX,startY};
				if (LostHope.factory.getCollidingGameObject(startX*LostHope.BLOCKSIDE, startY*LostHope.BLOCKSIDE,1,1)!=null 
						&& iterationsLeft>0
						&& LostHope.factory.getCollidingGameObject(startX*LostHope.BLOCKSIDE, startY*LostHope.BLOCKSIDE,1,1).getPrimaryType()!=ObjectData.WATER) {//makes sure you are below the ground and still need to generate things
					for (int i=0; i<(theRandomizer.nextDouble()*2); i++) {//allows for branching caves
						if (theRandomizer.nextDouble()<=.15) {
							createCircle(startX,startY,(int)(theRandomizer.nextDouble()*5),NOTHING);//circular sections
								createCave(nextCoords[0],nextCoords[1],iterationsLeft-1);//creates a new cave at the end of this one
						} else {
							nextCoords=createRect(startX,startY,(int)(theRandomizer.nextDouble()*20-10),NOTHING);//rectangular sections
								createCave(nextCoords[0],nextCoords[1],iterationsLeft-1);	
						}
					}		
				}
	}
	
	private void createFlora(int x, int y) {
		if (LostHope.factory.getCollidingGameObject(x*LostHope.BLOCKSIDE, y*LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, LostHope.BLOCKSIDE).getPrimaryType() != GameBlock.WATER) {
			if (theRandomizer.nextDouble()<.07) {					
				int choice = theRandomizer.nextInt(this.floraDesigns.size());
				Design design = this.floraDesigns.get(choice);
				if ((design.getType()==Design.OAK_TREE || design.getType()==Design.BIRCH_TREE) && y>design.getHeight() && x>design.getWidth()/2 && x< (this.width-design.getWidth())/2 ) {
					design.createSelf(x-(design.getWidth()/2), y);				
					location.flowersAndTrees.add(new Tree(x-(design.getWidth()/2),y,design.getWidth(),design.getHeight(),(byte)(design.getType())));
				}else if (design.getType()==Design.CACTUS && y>design.getHeight() && x>design.getWidth()/2 && x< (this.width-design.getWidth())/2 ) {
					design.createSelf(x-(design.getWidth()/2), y);
				}else if (y>2 && y<this.height && x>2 && x<this.width-1){
					design.createSelf(x,y);
				}
				
			} else {
				LostHope.factory.createBackgroundGameObject(GameBlock.GRASS, (x)*LostHope.BLOCKSIDE, (y)*LostHope.BLOCKSIDE);
				Grass tempGrass = new Grass(x,y,LostHope.BLOCKSIDE,LostHope.BLOCKSIDE);
				location.grass.add(tempGrass);
				controller.plantController.add(tempGrass);
			}
		}
	}
	
	private int[] createRect(int startX, int startY, int width, byte type) {			
		TerrainType[] allTypes = new TerrainType[] {new SuperFlat(), new SemiFlat(), new UpSlope(), new DownSlope()};//allows for different types of terrain
		int currentY = startY;
		int rectType=(int)(theRandomizer.nextDouble()*(allTypes.length));
		int height = (int) (theRandomizer.nextDouble()*5+3);//makes it a random height below 8
		for (int x=startX; x<startX+width && x<this.width-1 && x>0; x++) {
			currentY = currentY+allTypes[rectType].getModifier();
			for (int y=currentY; y<currentY+height &&y<this.height-1 && y>0;y++) {
					GameObject toReplace = LostHope.factory.getCollidingGameObject(x*LostHope.BLOCKSIDE,y*LostHope.BLOCKSIDE,1,1);
					if (toReplace!=null && toReplace.getPrimaryType()!=GameBlock.WATER) {
						LostHope.factory.destroyGameObject(toReplace);
						if ((y<=currentY || y>=currentY+height-1) && type<0) {//crystals can only form on top and bottom
							createCrystal(x,y,GameBlock.BROWN_AGATE,(-9*.07/this.height/this.height)*y*(y-(.33*this.height)));//BrownAgate can be formed in caves anywhere from 0 to 1/3 height at .1 chance
							createCrystal(x,y,GameBlock.GARNET,(-8*.07/this.height/this.height)*(y-(.25*this.height))*(y-(.5*this.height)));//Garnet can be found from h/4-h/2 at .1
							createCrystal(x,y,GameBlock.AMETHYST,(-8*.07/this.height/this.height/2.25)*(y-(.375*this.height))*(y-(.75*this.height)));//Amethyst starts at 3h/8 and goes to 3h/4 at .1
							createCrystal(x,y,GameBlock.ONYX,(-8*.035/this.height/this.height/2.25)*(y-(.625*this.height))*(y-this.height));
							createCrystal(x,y,GameBlock.BERYL,(-8*.035/this.height/this.height/2.25)*(y-(.625*this.height))*(y-this.height));
							createCrystal(x,y,GameBlock.SERAPHINITE,(-4*.01/this.height/this.height*2.25)*(y-(.75*this.height))*(y-this.height));
						
						}
						if (type>=0) {
							LostHope.factory.createGameObject(type, x*LostHope.BLOCKSIDE, y*LostHope.BLOCKSIDE);//can use it to create rects of other stuff.. trees?
						}
					}
			}
		}
		return new int[] {startX+width,currentY};//returns the end of the rect to use for the next section
	}
	
	
	private void createCircle(int centerX, int centerY, int radius, byte type) {
		for(int x=centerX-radius; x<=centerX+radius; x++) {
			for (int y=centerY-radius; y<=centerY+radius; y++) {
				if (Math.sqrt((x-centerX)*(x-centerX)+(y-centerY)*(y-centerY))<=radius && x>1 && y>1 && x<this.width && y<this.height) {//makes a circle starting from the top left
						GameObject toReplace = LostHope.factory.getCollidingGameObject(x*LostHope.BLOCKSIDE,y*LostHope.BLOCKSIDE,1,1);
						if (toReplace!=null && toReplace.getPrimaryType()!=GameBlock.WATER) {		
							
							if (type>=0 && theRandomizer.nextDouble()<.5) {//for generating ores
								LostHope.factory.destroyGameObject(toReplace);
								LostHope.factory.createGameObject(type, x*LostHope.BLOCKSIDE, y*LostHope.BLOCKSIDE);

							} else if (type<0) {
								LostHope.factory.destroyGameObject(toReplace);
								if ((y<=centerY-radius || y>=centerY+radius)) {//crystals can only form on top and bottom
									createCrystal(x,y,GameBlock.BROWN_AGATE,(-4*.1/this.height/this.height)*y*(y-(.5*this.height)));//BrownAgate can be formed in caves anywhere from 0 to 1/3 height at .1 chance
									createCrystal(x,y,GameBlock.GARNET,(-.3/this.height/this.height)*(y-(.25*this.height))*(y-(.75*this.height)));//Garnet can be found from h/4 to 3h/4 at .5
								}
							}
						}
				}
			}			
		}
		
	}
	
	private void createOre(int x, int y, int radius, byte type, double chance) {
		if (theRandomizer.nextDouble()<chance) {
			createCircle(x,y,radius,type);
		}
	}
	
	private void createCrystal(int x,int y, byte type, double chance) {
		if (theRandomizer.nextDouble()<chance) {
			LostHope.factory.createBackgroundGameObject(type, x*LostHope.BLOCKSIDE, y*LostHope.BLOCKSIDE);
		}
	}
	
	private int createVillage(int startX, int startY) {
		int maxHouses = (int)(theRandomizer.nextDouble()*4+1);
		int numberOfHouses = 0;
		boolean hasBlacksmith=false;
		boolean hasWell=false;
		boolean hasMarket=false;
		boolean hasInn=false;
		
		Random r = new Random();
		
		for(int x=startX; x<startX + 10*maxHouses; x++){
			int choice = r.nextInt(this.houseDesigns.size());
			Design design = this.houseDesigns.get(choice);

			if((numberOfHouses < maxHouses && design.getType()==HouseDesign.HOUSE) 
					|| (design.getType()==Design.BLACKSMITH && !hasBlacksmith) 
					|| (design.getType()==Design.MARKET && !hasMarket)
					|| (design.getType()==Design.WELL && !hasWell)
					|| (design.getType()==Design.INN && !hasInn)){
							
				clearForVillage(x,startY,design.getWidth(),design.getHeight());
				design.createSelf(x, startY);
				if (design.getType()==Design.BLACKSMITH) {
					hasBlacksmith=true;
				} else  if(design.getType()==Design.HOUSE){
					numberOfHouses ++;
				}else if(design.getType()==Design.INN) {
					hasInn=true;
				}else if(design.getType()==Design.MARKET) {
					hasMarket=true;
				} else if(design.getType()==Design.WELL) {
					//LostHope.factory.createLiquidGameBlock((x+1)*LostHope.BLOCKSIDE, (startY-1)*LostHope.BLOCKSIDE, LiquidGameBlock.WATER_BLOCK);
					hasWell=true;
				}
				x = x + design.getWidth();
			} else {
				clearForVillage(x,startY,1,10);
			}
			
		}

		return startX+64;
	}
	
	private void clearForVillage(int startX, int startY, int width, int height) {
		for (int x = startX;x<=startX+width;x++ ) {
			for (int y=startY;y>=startY-height-(int)(theRandomizer.nextDouble()*3); y--) {
					if (LostHope.factory.getCollidingGameObject(x*LostHope.BLOCKSIDE, y*LostHope.BLOCKSIDE,2,2)!=null && y!=startY){
						LostHope.factory.destroyGameObject(LostHope.factory.getCollidingGameObject(x*LostHope.BLOCKSIDE, y*LostHope.BLOCKSIDE,2,2));
					} else if (y==startY) {
						LostHope.factory.createGameObject(GameBlock.STONE_BLOCK, x*LostHope.BLOCKSIDE, y*LostHope.BLOCKSIDE);
					}
			}
		}
	}

	private void fillLiquid(/*int x,int y,byte type*/) {
		for (int i=2; i<this.width; i++) {
			for (int j=this.height/5; j<(this.height/5)+5; j++) {
				if (LostHope.factory.getCollidingGameObject(i*LostHope.BLOCKSIDE, j*LostHope.BLOCKSIDE, LostHope.BLOCKSIDE,LostHope.BLOCKSIDE)==null) {
					LostHope.factory.createLiquidGameBlock(i*LostHope.BLOCKSIDE, j*LostHope.BLOCKSIDE, LiquidGameBlock.WATER_BLOCK);
				}
			}
		}
		for (int i=0; i<500; i++) {
			int percent = (int)((i/500d)*100d);
			LostHope.updateLiquidBlocks(location.getLiquidBlocks());
			setProgress(percent);
			publish("Settling Water");
		}
		for(LiquidGameBlock o:location.getLiquidBlocks()) o.firstTime=true;
//		while(y>=seaLevel) {
//			LostHope.factory.createLiquidGameBlock(x*LostHope.BLOCKSIDE, y*LostHope.BLOCKSIDE, LiquidGameBlock.WATER_BLOCK);
//			y--;
//		}
	}
	
	public Location[] getLocations(){
		return locations;
	}

}
