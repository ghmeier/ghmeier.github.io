package squareInfinity;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;

public class RainWeather extends Weather{

	protected ArrayList<Raindrop> drops;
	
	protected int delayBetweenDrops;
	
	protected long startTime;
	protected long currentTime;
	
	protected boolean spawnsParticles;
	
	public RainWeather(int delayBetweenDrops, boolean spawnsParticles, LostHope controller){
		drops = new ArrayList<Raindrop>();
		
		this.spawnsParticles = spawnsParticles;
		
		this.delayBetweenDrops = delayBetweenDrops;
		
		startTime = System.currentTimeMillis();
		
		controller.setBackgroundPic(new Color(100,100,100));
	}
	
	public void spawnRaindrop(LostHope controller, int xOffset, int yOffset){
		Random r = new Random();
		
		int startX = r.nextInt(controller.getWidth()) + (int)controller.getCurrentPlayer().getX() - 300;
		int startY = -10;
		int endX = startX;
		int endY = startY + 6;
		
		Raindrop tempDrop = new Raindrop(startX, startY, endX, endY);
		tempDrop.setSpeed(10);
		
		
		drops.add(tempDrop);
	}
	
	public void destroyRaindrop(Raindrop r){
		this.drops.remove(r);
	}
	
	@Override
	public void drawWeather(Graphics g, int xOffset, int yOffset, LostHope controller) {
		for(int x=0; x<drops.size(); x++){
			Raindrop currentDrop = drops.get(x);
			
			currentDrop.moveSelf();
			currentDrop.drawSelf(g, xOffset, yOffset);
			currentDrop.checkCollisions(controller, xOffset, yOffset,this, this.spawnsParticles);
		}
		
		currentTime = System.currentTimeMillis();
		
		if(currentTime - startTime >= delayBetweenDrops){
			startTime = System.currentTimeMillis();
			
			this.spawnRaindrop(controller, xOffset, yOffset);
		}
	}

}
