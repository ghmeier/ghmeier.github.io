package squareInfinity;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.*;

public class MagicEditor {
	
	private Player player;
	private LostHope controller;
	
	private JFrame mainFrame;
	private JButton createButton;
	
	private JTextArea codeArea;
	private JTextField nameField;
	
	private int width;
	private int height;
	
	private String code;
	
	public MagicEditor(Player player, LostHope controller, int width, int height){
		this.width = width;
		this.height = height;
		
		this.player = player;
		this.controller = controller;
		
		mainFrame = new JFrame("Magic Editor Beta");
		
		createButton = new JButton("Create spell!");
		createButton.addActionListener(new CreateSpellActionListener());
		codeArea = new JTextArea(5,5);
		
		JPanel namePanel = new JPanel();
		
		nameField = new JTextField(20);
		JLabel nameLabel = new JLabel("Spell Name:");
		
		namePanel.add(nameLabel);
		namePanel.add(nameField);
		
		Container contentPane = mainFrame.getContentPane();
		
		contentPane.add(BorderLayout.SOUTH, createButton);
		contentPane.add(BorderLayout.CENTER, codeArea);
		contentPane.add(BorderLayout.NORTH, namePanel);
		
		mainFrame.setSize(this.width, this.height);
		mainFrame.setLocationRelativeTo(null); // centers it on the screen
		
		mainFrame.setVisible(true);
	}
	
	public void close(){
		this.code = codeArea.getText();
		String name = nameField.getText();
		
		this.mainFrame.dispose();
		
//		MagicInterpreter mi = new MagicInterpreter(null, controller);
//		
//		mi.parseMagicCode(code);
		
		this.code.trim();
		name.trim();
		
		if(this.code.length() > 0){
			try {
				MagicScroll tempScroll = new MagicScroll(this.code, name);
				this.player.addItemToInventory(tempScroll);
			} catch (IOException e) {
				System.err.println("cound not load scroll image");
			}
		}
	}
	
	
	
	public class CreateSpellActionListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			controller.closeMagicCreationWindow();
		}
		
	}
	
	
	
	
	public static void main(String[] args){
		MagicEditor fred = new MagicEditor(null, null, 800, 600);
	}

}
