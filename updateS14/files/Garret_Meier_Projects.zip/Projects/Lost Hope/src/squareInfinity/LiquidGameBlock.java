package squareInfinity;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.io.Serializable;
import java.util.Arrays;

@SuppressWarnings("serial")
public class LiquidGameBlock extends GameBlock implements Serializable{
	
	public static final int WATER_BLOCK = 1;
	public static final int LAVA_BLOCK = 2;
	
	protected double liquidAmount;
	protected double pressure=1;
	
	protected double flowRate;
	protected boolean central;
	protected boolean hasUpdatedPressure;
	protected boolean finishedUpdating=true;
	
	private GameObject[] borders=new GameObject[4]; //up, down, left, right
	private static final double[] pressureMod={1, -1, 0, 0};
	private static final double[] flowSpeed={.5, 2, 1, 1};
	protected boolean firstTime=true;
	private int emptyCounter=0;
	
	public LiquidGameBlock(int x, int y, int type){
		super((byte)type,x,y,LostHope.BLOCKSIDE, LostHope.BLOCKSIDE);
		if(type == WATER_BLOCK){
			this.primaryType = ObjectData.WATER;
		}else if(type == LAVA_BLOCK){
			this.primaryType = ObjectData.LAVA;
		}
		
		liquidAmount = 1;
		
		if(type == WATER_BLOCK){
			this.flowRate = .08;
		}else if(type == LAVA_BLOCK){
			this.flowRate = .005;
		}else{
			this.flowRate = .05;
		}
	}
	
	public void updateBorders(){
		borders[0]=LostHope.factory.getCollidingGameObject(x+width/2, y-1, 0, 0);
		borders[1]=LostHope.factory.getCollidingGameObject(x+width/2, y+height+1, 0, 0);
		borders[2]=LostHope.factory.getCollidingGameObject(x-1, y+height/2, 0, 0);
		borders[3]=LostHope.factory.getCollidingGameObject(x+width+1, y+height/2, 0, 0);
	}
	
	public void updatePressure(){
		if(firstTime){
			updateBorders();
			firstTime=false;
		}
		if(!finishedUpdating) return;
		finishedUpdating=false;
		if(!hasUpdatedPressure){
			if(liquidAmount==0){
				if(emptyCounter++>=10){
					LostHope.factory.destroyGameObject(this);
					return;
				}
			}
			else emptyCounter=0;
		}
		double oldPressure=pressure;
		pressure=liquidAmount;
		if(!hasUpdatedPressure) central=true;
		for(int i=0; i<borders.length; i++){
			GameObject o=borders[i];
			if(o!=null && o instanceof LiquidGameBlock){
				if(!hasUpdatedPressure||pressure>oldPressure) ((LiquidGameBlock)o).updatePressure();
				double p=(((LiquidGameBlock)o).getPressure()+pressureMod[i])*(liquidAmount);
				if(p>pressure) pressure=p;
			}
			if(!hasUpdatedPressure)
				if(o==null || (o instanceof LiquidGameBlock && 
						((LiquidGameBlock)o).getLiquidAmount()<getLiquidAmount())) central=false;
		}
		hasUpdatedPressure=true;
		finishedUpdating=true;
	}
	
	public void flow(){
		double[] amounts=getFlowAmounts();
		for(int i=0; i<borders.length; i++){
			if(amounts[i]==0||i==0&&liquidAmount<1) continue;
			double flowAmt=flowRate*amounts[i];
			if(borders[i]==null){
				int x=this.x+(i==2?-width:i==3?width:0);
				int y=this.y+(i==0?-height:i==1?height:0);
				LiquidGameBlock b=LostHope.factory.createLiquidGameBlock(x, y, type);
				double d=Math.min(flowAmt, liquidAmount);
				b.setLiquidAmount(d);
				borders[i]=b;
				liquidAmount-=d;
			}else if(borders[i] instanceof LiquidGameBlock){
				LiquidGameBlock b=(LiquidGameBlock)borders[i];
				//Can't flow negative amounts (shouldn't happen anyway, but just in case)
				double d=Math.max(0, 
						//Can't flow so much that the other block will have more than this one
						Math.min(i==1?1:(liquidAmount-b.getLiquidAmount()/2), 
						//Also can't flow more than this block has, 
						Math.min(liquidAmount, 
						//and can't fill other block more than 100%
						Math.min(1-b.getLiquidAmount(), flowAmt))));
				b.increaseLiquidAmount(d);
				liquidAmount-=d;
			}
		}
	}
	private double[] getFlowAmounts(){
		double[] amounts=new double[4];
		Arrays.fill(amounts, 0);
		double total=0;
		for(int i=0; i<borders.length; i++){
			GameObject o=borders[i];
			if(o==null||o instanceof LiquidGameBlock){
				double p=(o==null?0:((LiquidGameBlock) o).getPressure())+pressureMod[i];
				if(p<getPressure()){
					amounts[i]=(getPressure()-p)*flowSpeed[i];
					total+=amounts[i];
				}
			}
		}
		if(total>0) for(int i=0; i<amounts.length; i++) amounts[i]/=total;
		return amounts;
	}
	
	public double getPressure(){
		return pressure;
	}
	
	public void setLiquidAmount(double amt){
		liquidAmount=amt;
	}
	
	public void increaseLiquidAmount(double amt){
		liquidAmount+=amt;
	}
	
	public double getLiquidAmount(){
		return liquidAmount;
	}
	
	@Override
	public void drawSelf(Graphics g, int xModifier, int yModifier){
		if(liquidAmount==0) return;
		double l=liquidAmount;
		if(liquidAmount>0 && borders[0]!=null&&borders[0] instanceof LiquidGameBlock 
				&& ((LiquidGameBlock) borders[0]).liquidAmount>flowRate*2) l=1;
		//else if(liquidAmount<=flowRate*2) return;
		
		if(this.primaryType == ObjectData.LAVA){
			g.setColor(Color.ORANGE);
		}else if(this.primaryType == ObjectData.WATER){
			g.setColor(Color.BLUE);
		}else{
			g.setColor(Color.GREEN);
		}
		if(central) g.setColor(new Color(0, 0, 200));
		
		int liquidOffset = ((int)(height*(1-l)));
		AffineTransform at=((Graphics2D)g).getTransform();
		boolean rotating=(Math.abs(Math.atan2(at.getShearY(), at.getScaleY()))%(Math.PI/2))>.01;
		int x1=this.x+xModifier, y1=this.y+yModifier+liquidOffset, 
				w=width+(rotating?1:0), h=height-liquidOffset+(rotating?1:0);
		if((borders[0]!=null && borders[0] instanceof LiquidGameBlock && 
				((LiquidGameBlock)borders[0]).liquidAmount>0))
				g.fillRect(x1, y1, w, h);
		else{
			double left=borders[2]==null?0:(borders[2] instanceof LiquidGameBlock)?
					((LiquidGameBlock)borders[2]).liquidAmount:liquidAmount;
			double right=borders[3]==null?0:(borders[3] instanceof LiquidGameBlock)?
					((LiquidGameBlock)borders[3]).liquidAmount:liquidAmount;
			g.fillPolygon(new int[]{x1, x1+(w/2), x1+w, x1+w, x1, x1}, 
					new int[]{y1+(int)(h*(liquidAmount-left)/2), y1, y1+(int)(h*(liquidAmount-right)/2), y1+h, y1+h, y1+(int)(h*(liquidAmount-left)/2)}, 6);
		}
	/*	g.setColor(Color.white);
		g.setFont(new Font("Arial", Font.PLAIN, 8));
		g.drawString(""+(double)((int)(pressure*10)/10d), x+xModifier, y+yModifier+6);
		g.setFont(new Font("Arial", Font.PLAIN, 12));*/
	}

}
