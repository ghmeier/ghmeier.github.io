package squareInfinity;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;

public abstract class InventoryItem {
	
	protected String name;
	protected Image icon;
	protected int weight;
	protected boolean isBeingDragged;
	
	public InventoryItem(String name, int weight){
		this.name = name;
		this.weight = weight;
	}
	
	public int getWeight(){
		return this.weight;
	}
	
	public void setIsBeingDragged(boolean isBeingDragged){
		this.isBeingDragged = isBeingDragged;
	}
	
	public void setWeight(int weight){
		this.weight = weight;
	}
	
	public String getName(){
		return this.name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public void setIcon(Image icon){
		this.icon = icon;
	}
	
	public Image getIcon(){
		return this.icon;
	}
	
	public void drawSelfInInventory(Graphics g, int x, int y, boolean mouseOver){
		
		if(mouseOver){
			g.setColor(Color.YELLOW);
			g.drawRect(x, y, 16, 16); // all inventory items are drawn in 16-bit size, even on the field, at least right now
			g.setColor(Color.WHITE);
			
			FontMetrics fm = g.getFontMetrics();
			int length = fm.stringWidth(this.name);
			
			
			g.fillRect(x, y - 11, length + 4, 13);
			g.setColor(Color.BLACK);
			g.drawString(this.name, x + 1, y);
		}else{
			// no surrounding prettyness
			if(isBeingDragged){
				g.setColor(Color.WHITE);
				
				FontMetrics fm = g.getFontMetrics();
				int length = fm.stringWidth(this.name);
				
				
				g.fillRect(x, y - 11, length + 1, 12);
				g.setColor(Color.BLACK);
				g.drawString(this.name, x + 1, y);
			}
		}
		
		if(icon == null){
			g.setColor(Color.RED);
			g.fillRect(x + 2, y + 2, 12, 12);
		}else{
			int xScale = icon.getWidth(null);
			int yScale = icon.getHeight(null);
			
			if(icon.getWidth(null) > 14){
				xScale = 14;
			}
			if(icon.getHeight(null) > 14){
				yScale = 14;
			}
			
			g.drawImage(icon, x + 2, y + 2, xScale, yScale, null);
		}
	}
	
	public void drawSelf(Graphics g, int x, int y){
		g.drawImage(this.icon, x, y, null);
	}
	
	
	
}
