package squareInfinity;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class PlasmaParticle extends PhysicsObject{
	
	private static final int countingSpeed = 1;
	private static final int countingMin = 50;
	private static final int countingMax = 120;
	
	private Random r;
	private int counter;
	private boolean countingUp;

	public PlasmaParticle(double x, double y) {
		super(x, y, 2, 2, 0);
		
		r = new Random();
		
		this.counter = 0;
		
		this.countingUp = true;
		
		this.increaseYSpeed((double)(-r.nextInt(100) - 1) / 60);
		this.setHeat(450);
	}

	@Override
	public void drawSelf(Graphics g) {
		Color colorToDraw = new Color(counter * 2, counter, 0);
		
		g.setColor(colorToDraw);
		g.fillRect((int)x, (int)y, 2, 2);
		
		this.x = this.x + r.nextInt(5) - 2;
		this.ySpeed = this.ySpeed - r.nextInt(1) - .065;
		
//		if(countingUp){
//			counter = counter + countingSpeed;
//		}else{
//			counter = counter - countingSpeed;
//		}
//		
//		if(counter > countingMax){
//			countingUp = false;
//		}
//		if(counter < countingMin){
//			countingUp = true;
//			counter = countingMin;
//		}
		
		if(this.heat > 0){
			this.counter = (int) (this.heat % 255) / 2;
			System.out.println("Counter: " + this.counter);
		}else{
			this.counter = 0;
			this.heat = 1;
			LostHope.factory.destroyPlasmaParticle(this);
		}
	}
	
	public void touchedGround(){
		//LostHope.factory.destroyPlasmaParticle(this);
	}

	@Override
	public void setPower(int power) {
		// TODO setpower does nothing
	}

	@Override
	public void magicExplode(LostHope controller, int power) {
		// TODO explode does nothing
	}

	@Override
	public MagicPrimitive createCopyOfSelf() {
		// TODO create copy does nothing
		return null;
	}

}
