package squareInfinity;

import java.awt.Dimension;
import java.awt.Graphics;

public class CraftedItem extends InventoryItem{
	
	protected Dimension rotationPoint;
	
	
	
	public CraftedItem(String name, int weight, Dimension rotationPoint) {
		super(name, weight);
		
		this.rotationPoint = rotationPoint;
	}
	
	public void createImageFromArray(ObjectData[][] data){
		
	}
	
	@Override
	public void drawSelf(Graphics g, int x, int y){
		
	}

}
