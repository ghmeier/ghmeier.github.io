package squareInfinity;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ClearWeather extends Weather{
	
	public ClearWeather(LostHope controller){
		try {
			BufferedImage image = ImageIO.read(new File("Pic/Misc/Background.png"));
			controller.setBackgroundPic(image);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void drawWeather(Graphics g, int xOffset, int yOffset,
			LostHope controller) {
		
	}

}
