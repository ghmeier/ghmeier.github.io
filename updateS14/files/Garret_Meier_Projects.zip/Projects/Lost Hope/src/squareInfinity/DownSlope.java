package squareInfinity;

public class DownSlope extends TerrainType{
	public int getModifier() {
		double randomNumber = WorldGenerator.theRandomizer.nextDouble();
		if (randomNumber<=.2) {
			return 0;
		} else if (randomNumber<=.8) {
			 return 1;
		} else if (randomNumber<=.95) {
			return 2;
		} else {
			return 3;
		}
	}
}
