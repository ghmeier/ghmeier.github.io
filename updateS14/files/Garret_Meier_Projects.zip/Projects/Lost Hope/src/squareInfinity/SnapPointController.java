package squareInfinity;

import java.awt.Dimension;
import java.awt.Graphics;
import java.util.HashMap;
import java.util.Iterator;

public class SnapPointController {
	
	private HashMap<int[], SnapPointHolder> holders;
	
	public SnapPointController(){
		holders = new HashMap<int[], SnapPointHolder>();
	}
	
	public Iterator<SnapPointHolder> iterator(){
		return holders.values().iterator();
	}
	
	public void addSnapPoint(Dimension d, ItemCraftingHolder ich, ItemCraftingInterface controller){
		int[] key = {(int)d.getWidth(), (int)d.getHeight()};
		
		holders.put(key, new SnapPointHolder((int)d.getWidth(), (int)d.getHeight(), ich, controller));
	}
	
	public void removeSnapPoint(Dimension d){
		int[] key = {(int) d.getWidth(), (int) d.getHeight()};
		
		holders.remove(key);
	}
	
	public void drawSelf(Graphics g){
		Iterator<SnapPointHolder> holderIterator = holders.values().iterator();
		
		while(holderIterator.hasNext()){
			SnapPointHolder currentHolder = holderIterator.next();
			
			currentHolder.drawSelf(g, 3, 3);
		}
	}
	

}
