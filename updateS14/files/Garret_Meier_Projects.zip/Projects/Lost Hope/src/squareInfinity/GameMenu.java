package squareInfinity;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import squareInfinity.gui.GUIActionListener;
import squareInfinity.gui.GUIAlignment;
import squareInfinity.gui.GUIButton;
import squareInfinity.gui.GUIElement;
import squareInfinity.gui.GUIElementController;
import squareInfinity.gui.GUINumberInputBox;
import squareInfinity.gui.GUIToggleButton;

@SuppressWarnings("serial")
public class GameMenu extends JPanel implements GUIActionListener, MouseListener, MouseMotionListener, KeyListener{
	
	private JFrame mainFrame;
	
	private GUIElementController controller;
	
	// default menu
	
	private GUIButton playButton;
	private GUIButton settingsButton;
	private GUIButton exitButton;
	
	// settings menu
	
	private SettingsProfile mainProfile;
	
	private GUIButton backButton;
	private GUIToggleButton toggleMusicButton;
	private GUINumberInputBox widthInput;
	
	///
	
	private int width;
	private int height;
	
	private GUIAlignment defaultMenuAlignment;
	private GUIAlignment settingsAlignment;
	
	private BufferedImage backgroundImage;
	
	public GameMenu(int width, int height, boolean createsSeperateWindow){
		controller = new GUIElementController(width, height);
		
		this.mainProfile = new SettingsProfile();
		
		this.width = width;
		this.height = height;
		
		try {
			backgroundImage = ImageIO.read(new File("Pic/Logo/Splash Screen.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		playButton = new GUIButton(10, 100, "Play Game");
		playButton.addActionListener(this);
		
		settingsButton = new GUIButton(10,125, "Settings");
		settingsButton.addActionListener(this);
		
		exitButton = new GUIButton(10,150, "Exit Game");
		exitButton.addActionListener(this);
		
		defaultMenuAlignment = new GUIAlignment(0, 0, width, height);
		
		defaultMenuAlignment.addElement(playButton);
		defaultMenuAlignment.addElement(settingsButton);
		defaultMenuAlignment.addElement(exitButton);
		
		controller.setCurrentAlignment(defaultMenuAlignment);
		
		settingsAlignment = new GUIAlignment(0, 0, width, height);
		
		backButton = new GUIButton(10, 75, "<= Save and Return");
		backButton.addActionListener(this);
		
		toggleMusicButton = new GUIToggleButton(10, 100, "Music");
		toggleMusicButton.setState(true);
		
		widthInput = new GUINumberInputBox(10, 125, 20, 14, this);
		
		
		
		settingsAlignment.addElement(toggleMusicButton);
		settingsAlignment.addElement(backButton);
		settingsAlignment.addElement(widthInput);
		
		
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		
		if(createsSeperateWindow){
			this.mainFrame = new JFrame("Lost Hope");
			
			mainFrame.addMouseListener(this);
			mainFrame.addMouseMotionListener(this);
			
			mainFrame.getContentPane().add(BorderLayout.CENTER, this);
			
			mainFrame.setSize(width, height);
			mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			mainFrame.setLocationRelativeTo(null);
			mainFrame.setVisible(true);
		}
	}
	
	public void transferToGame(){
		mainFrame.remove(this);
		new Thread(){public void run(){

			LostHope game = new LostHope(width, height, false, false, mainFrame, mainProfile);
			
			mainFrame.getContentPane().add(BorderLayout.CENTER, game);
		}}.start();
	}
	
	@Override
	public void paintComponent(Graphics g){
		g.drawImage(backgroundImage, 0,0,null);
		
		controller.drawElements(g);
	}
	
	@Override
	public void elementClicked(GUIElement element){
		if(element == exitButton){
			System.exit(0);
		}else if(element == playButton){
			transferToGame();
		}else if(element == backButton){
			controller.setCurrentAlignment(defaultMenuAlignment);
			this.mainProfile.setMusic(toggleMusicButton.getState());
		}else if(element == settingsButton){
			controller.setCurrentAlignment(settingsAlignment);
		}
		
		this.repaint();
	}
	
	

	@Override
	public void mouseClicked(MouseEvent arg0) {
		controller.mouseChanged(arg0.getX(), arg0.getY(), true);
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		controller.mouseChanged(arg0.getX(), arg0.getY(), false);
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		controller.mouseChanged(arg0.getX(), arg0.getY(), false);
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		//controller.mouseChanged(arg0.getX(), arg0.getY(), true);
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		controller.mouseChanged(arg0.getX(), arg0.getY(), false);
	}
	
	@Override
	public void mouseDragged(MouseEvent arg0) {
		controller.mouseChanged(arg0.getX(), arg0.getY(), true);
	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		controller.mouseChanged(arg0.getX(), arg0.getY(), false);
		
		this.repaint();
	}
	
	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		controller.keyPressed(arg0.getKeyChar());
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	////////////////////////////////////////////////
		
	public static void main(String[] args){
		new GameMenu(800, 600, true);
	}

	

}
