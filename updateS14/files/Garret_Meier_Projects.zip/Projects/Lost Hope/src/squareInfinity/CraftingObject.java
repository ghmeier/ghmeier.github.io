package squareInfinity;

public class CraftingObject { // The base class for all objects used in crafting
	
	protected byte type;
	
	protected int width;
	protected int height;
	
	public CraftingObject(byte type, int width, int height){ // a size width x height object
		this.type = type;
		
		this.width = width;
		this.height = height;
	}
	
	public CraftingObject(byte type){ // a size 1 object
		this.type = type;
		
		this.width = 1;
		this.height = 1;
	}
	
	public byte getType(){
		return this.type;
	}
	
	public int getWidth(){
		return this.width;
	}
	
	public int getHeight(){
		return this.height;
	}
	
	

}
