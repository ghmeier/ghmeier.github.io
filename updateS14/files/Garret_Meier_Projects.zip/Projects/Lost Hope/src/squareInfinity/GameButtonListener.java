package squareInfinity;

//import java.awt.event.MouseEvent;

public interface GameButtonListener {
	
	public void mouseHasClicked();
}
