package squareInfinity;

public class ChunkOrganizerNode {
	
	public static final int UP = 1;
	public static final int DOWN = 2;
	public static final int LEFT = 3;
	public static final int RIGHT = 4;
	
	///
	
	private ChunkOrganizerNode topNode;
	private ChunkOrganizerNode bottomNode;
	private ChunkOrganizerNode leftNode;
	private ChunkOrganizerNode rightNode;
	
	private Chunk chunk;
	
	public ChunkOrganizerNode(Chunk chunk){
		this.chunk = chunk;
	}
	
	public Chunk getChunk(){
		return this.chunk;
	}
	
	public Chunk getChunk(int angle, int distance){
		if(distance == 0){
			return this.chunk;
		}else{
			if(angle == UP){
				if(this.topNode != null){
					return this.topNode.getChunk(angle, distance - 1);
				}else{
					return null;
				}
			}else if(angle == DOWN){
				if(this.bottomNode != null){
					return this.bottomNode.getChunk(angle, distance - 1);
				}else{
					return null;
				}
			}else if(angle == LEFT){
				if(this.leftNode != null){
					return this.leftNode.getChunk(angle, distance - 1);
				}else{
					return null;
				}
			}else if(angle == RIGHT){
				if(this.rightNode != null){
					return this.rightNode.getChunk(angle, distance - 1);
				}else{
					return null;
				}
			}
		}
		
		return null;
	}
	
	public void addChunk(int direction, int distance, Chunk chunk){
		
		if(direction == UP){
			
			if(this.topNode == null || direction == 1){
				this.topNode = new ChunkOrganizerNode(chunk);
			}else{
				this.topNode.addChunk(direction,distance - 1, chunk);
			}
			
		}else if(direction == DOWN){
			
			if(this.bottomNode == null || direction == 1){
				this.bottomNode = new ChunkOrganizerNode(chunk);
			}else{
				this.topNode.addChunk(direction, distance - 1, chunk);
			}
			
		}else if(direction == LEFT){
			
			if(this.leftNode == null || direction == 1){
				this.leftNode = new ChunkOrganizerNode(chunk);
			}else{
				this.leftNode.addChunk(direction, distance - 1, chunk);
			}
			
		}else if(direction == RIGHT){
			
			if(this.rightNode == null || direction == 1){
				this.rightNode = new ChunkOrganizerNode(chunk);
			}else{
				this.rightNode.addChunk(direction, distance - 1, chunk);
			}
			
		}
	}
	
	public void setTopNode(ChunkOrganizerNode node){
		this.topNode = node;
	}
	
	public void setBottomNode(ChunkOrganizerNode node){
		this.bottomNode = node;
	}
	
	public void setLeftNode(ChunkOrganizerNode node){
		this.leftNode = node;
	}
	
	public void setRightNode(ChunkOrganizerNode node){
		this.rightNode = node;
	}
	
	public ChunkOrganizerNode getTopNode(){
		return this.topNode;
	}
	
	public ChunkOrganizerNode getBottomNode(){
		return this.bottomNode;
	}
	
	public ChunkOrganizerNode getLeftNode(){
		return this.leftNode;
	}
	
	public ChunkOrganizerNode getRightNode(){
		return this.rightNode;
	}

}
