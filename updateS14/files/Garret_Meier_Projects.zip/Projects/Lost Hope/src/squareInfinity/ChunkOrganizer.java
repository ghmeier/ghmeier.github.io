package squareInfinity;

public class ChunkOrganizer {
	
	private int radius;
	
	private  ChunkOrganizerNode centerNode;
	
	public ChunkOrganizer(int radius){
		this.radius = radius; // not sure if we need this value but why not I guess
	}
	
	public void addChunk(int angle, int distance, Chunk chunk){
		if(centerNode == null){
			centerNode = new ChunkOrganizerNode(chunk);
		}else{
			int trueValue = (angle%90) + 1;
			
			if(trueValue == 1){
				centerNode.addChunk(ChunkOrganizerNode.UP, distance, chunk);
			}else if(trueValue == 2){
				centerNode.addChunk(ChunkOrganizerNode.LEFT, distance, chunk);
			}else if(trueValue == 3){
				centerNode.addChunk(ChunkOrganizerNode.DOWN, distance, chunk);
			}else if(trueValue == 4){
				centerNode.addChunk(ChunkOrganizerNode.RIGHT, distance, chunk);
			}
		}
	}
	
	public Chunk getChunk(int angle, int distance){
		if(distance == 0){
			if(centerNode != null){
				return centerNode.getChunk();
			}else{
				return null;
			}
		}else{
			if(centerNode != null){
				int trueValue = (angle%90) + 1;
				
				return centerNode.getChunk(trueValue, distance - 1);
			}else{
				return null;
			}
		}
	}
	
	

}
