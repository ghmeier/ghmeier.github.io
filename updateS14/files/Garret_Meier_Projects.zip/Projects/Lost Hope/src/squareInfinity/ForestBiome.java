package squareInfinity;

public class ForestBiome extends Biome {

	public ForestBiome(int startX,int startY, int width, byte type) {
		super(startX,startY,width,type);
		
		this.validTerrainTypes = new TerrainType[]{new SemiFlat(), new UpSlope(), new DownSlope()};
		for (Design d:WorldGenerator.floraDesigns) {
			byte currentType = (byte) d.getType();
			if (currentType==Design.BIRCH_TREE || currentType==Design.FLOWER || currentType==Design.OAK_TREE) {
				this.validFloraDesigns.add(d);
			}
		}
		
	}
//	@Override
//	protected void fillArea() {
//		// TODO Auto-generated method stub
//
//	}

}
