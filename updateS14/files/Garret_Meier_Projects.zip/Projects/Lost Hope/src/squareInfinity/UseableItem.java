package squareInfinity;

import java.awt.Dimension;
import java.awt.Image;


public class UseableItem extends InventoryItem{
	
	protected Dimension rotationPoint;
	
	protected boolean rotates;
	protected boolean createsProjectile;
	protected Projectile projectile;
	
	protected int damage;
	protected int reach;
	
	protected boolean canMine;
	
	protected Dimension projectileSpawnPoint;
	
	public UseableItem(String name, int weight, int damage, Dimension rotationPoint, Image image, boolean rotates) {
		super(name, weight);
		
		this.damage = damage;
		
		this.rotates = rotates;
		
		this.rotationPoint = rotationPoint;
		
		this.createsProjectile = false;
		
		this.canMine = false;
		
		this.setIcon(image);
	}
	
	public Dimension getProjectileSpawnPoint(){
		return this.projectileSpawnPoint;
	}
	
	public void setProjectileSpawnPoint(Dimension projectileSpawnPoint){
		this.projectileSpawnPoint = projectileSpawnPoint;
	}
	
	public int getDamage(){
		return this.damage;
	}
	
	public void setReach(int reach){
		this.reach = reach;
	}
	
	public boolean canMine(){
		return this.canMine;
	}
	
	public void setCanMine(boolean canMine){
		this.canMine = canMine;
	}
	
	public int getReach(){
		return this.reach;
	}
	
	public Dimension getRotationPoint(){
		return this.rotationPoint;
	}
	
	public void setProjectile(Projectile projectile){
		this.projectile = projectile;
		this.createsProjectile = true;
	}
	
	public Projectile getProjectile(){
		return this.projectile;
	}
	
	public boolean doesRotate(){
		return this.rotates;
	}

}
