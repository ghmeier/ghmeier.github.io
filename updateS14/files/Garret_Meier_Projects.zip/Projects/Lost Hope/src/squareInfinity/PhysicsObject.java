package squareInfinity;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.HashSet;

public abstract class PhysicsObject implements MagicPrimitive{
	
	protected ArrayList<ObjectCollisionListener> listeners;

	protected double x;
	protected double y;
	
	protected double xSpeed;
	protected double ySpeed;
		
	protected int width;
	protected int height;
	
	protected double oldX;
	protected double oldY;

	protected double[] CForce=new double[9];
	protected double[] CPForce=new double[9];
	protected double xBounceSpeed=Double.NaN;
	protected double yBounceSpeed=Double.NaN;
	
	protected double friction;
	protected double bounce=0.2;
	
	protected boolean isTouchingGround;
	protected boolean stopped=false;
	protected HashSet<PhysicsObject> hasCollided=new HashSet<PhysicsObject>();
	
	protected boolean isHeld = false;
	
	protected int heat;
	
	protected double currentRotation;
	protected boolean overrideRotation;
	
	protected boolean collides=true;
	
	
	public PhysicsObject(double x, double y, int width, int height, double friction){
		this.x = x;
		this.y = y;
		
		this.heat = 0;
		
		this.isTouchingGround = false;
		
		this.width = width;
		this.height = height;
		
		this.friction = friction;
		
		this.xSpeed = 0;
		this.ySpeed = 0;
		
		this.oldX = x;
		this.oldY = y;
		
		this.listeners = new ArrayList<ObjectCollisionListener>();
	}
	
	public void addObjectCollisionListener(ObjectCollisionListener ocl){
		this.listeners.add(ocl);
	}
	
	public void removeObjectCollisionListener(ObjectCollisionListener ocl){
		this.listeners.remove(ocl);
	}
	
	public double getOldX(){
		return this.oldX;
	}
	
	public boolean isTouchingGround(){
		return this.isTouchingGround;
	}
	
	public void setIsTouchingGround(boolean isTouchingGround){
		this.isTouchingGround = isTouchingGround;
	}
	
	public double getOldY(){
		return this.oldY;
	}
	
	public int getWidth(){
		return this.width;
	}
	
	public int getHeight(){
		return this.height;
	}
	
	public void setWidth(int width){
		this.width = width;
	}
	
	public void setHeight(int height){
		this.height = height;
	}
	
	public void setX(double x){
		this.x = x;
	}
	
	public void setY(double y){
		this.y = y;
	}
	
	public void increaseXSpeed(double amount){
		this.xSpeed = this.xSpeed + amount;
	}
	
	public void increaseYSpeed(double amount){
		this.ySpeed = this.ySpeed + amount;
	}
	
	public double getX(){
		return this.x;
	}
	
	public double getY(){
		return this.y;
	}
	
	public double getXSpeed(){
		return this.xSpeed;
	}
	
	public double getYSpeed(){
		return this.ySpeed;
	}
	
	public double getFriction(){
		return this.friction;
	}
	
	public void setFriction(double friction){
		this.friction = friction;
	}
	
	public void setXSpeed(double amount){
		this.xSpeed = amount;
	}
	
	public void setYSpeed(double amount){
		this.ySpeed = amount;
	}
	
	public void increaseX(double amount){
		this.x = this.x + amount;
	}
	
	public  void increaseY(double amount){
		this.y = this.y + amount;
	}
	
	public void setOldX(double oldX){
		this.oldX = oldX;
	}
	
	public void setOldY(double oldY){
		this.oldY = oldY;
	}
	
	public int getHeat(){
		return this.heat;
	}
	
	public void setHeat(int heat){
		this.heat = heat;
	}
	
	public void increaseHeat(int amountToIncreaseBy){
		this.heat = this.heat + amountToIncreaseBy;
	}
	
	public void drawWithTransform(Graphics2D g, int xModifier, int yModifier){
		g.translate(xModifier, yModifier);
		currentRotation-=currentRotation<0?Math.max(-.05, currentRotation*.05):Math.min(.05, currentRotation*.05);
		if(Math.abs(currentRotation)<.005) currentRotation=0;
		currentRotation=((currentRotation+Math.PI)%(Math.PI*2))-Math.PI;
		g.rotate(currentRotation, x+width/2, y+height/2);
		drawSelf(g);
		g.rotate(-currentRotation, x+width/2, y+height/2);
		g.translate(-xModifier, -yModifier);
	}
	
	public abstract void drawSelf(Graphics g);
	
	public static boolean areObjectsColliding(PhysicsObject o1, PhysicsObject o2){
		if(o1.getX() + o1.getWidth() >= o2.getX() && o1.getY() + o1.getHeight() >= o2.getY() && o1.getX() <= o2.getX() + o2.getWidth()
				&& o1.getY() <= o2.getY() + o2.getWidth()){
			return true;
		}
		
		return false;
		
	}
	
	public static double getDistanceBetweenTwoPoints(double x1, double y1, double x2, double y2){
		return Math.sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2));
	}
	
	public byte isObjectWithin(PhysicsObject object){
		double oldx=object.getOldX(), oldy=object.getOldY();
		double ex = this.x + this.width;
		double ey = this.y + this.height;
		
		int pex = (int) (object.x + object.getWidth()); // object end x
		int pey = (int) (object.y + object.getHeight()); // object end y
		
		byte whatToReturn = GameBlock.NO_COLLISION;
		
	/*	whatToReturn=GameFactory.getCollisionSide(new double[]{
				oldX, oldY, oldX+width, oldY+height, x-oldX, y-oldY
		}, new double[]{
				oldx, oldy, oldx+object.width, oldy+object.height, object.x-oldx, object.y-oldy
		});*/
		
		// first check if is in
		if(whatToReturn==GameBlock.NO_COLLISION && object.x <= ex && object.y <= ey && pex >= this.x && pey >= this.y){
			
			double min=Double.POSITIVE_INFINITY;
			if(oldx >= ex){
				if(oldx - ex<min){
					min=oldx - ex;
					whatToReturn = GameBlock.RIGHT_COLLISION;
				}
			}
			if(oldx + object.getWidth() <= this.x){
				if(this.x - (oldx + object.getWidth())<min){
					min=this.x - (oldx + object.getWidth());
					whatToReturn = GameBlock.LEFT_COLLISION;
				}
			}
			if(oldy + object.getHeight() <= this.y){
				if(this.y - (oldy + object.getHeight())<min){
					min=this.y - (oldy + object.getHeight());
					whatToReturn = GameBlock.TOP_COLLISION;
				}
			}
			if(oldy >= ey){
				if(oldy - ey<min){
					min=oldy - ey;
					whatToReturn = GameBlock.BOTTOM_COLLISION;
				}
			}
		}
		return whatToReturn;
		
	}
	
	public boolean isHeld(){
		return this.isHeld;
	}
	
	public void setIsHeld(boolean isHeld){
		this.isHeld = isHeld;
	}
	
	public void notifyListeners(PhysicsObject object, byte collisionInfo){

		
		for(int x=0; x<listeners.size(); x++){
			ObjectCollisionListener ocl = listeners.get(x);
			
			ocl.hasCollidedWithObject(this, object, collisionInfo);
		}
	}
	
	public void toggleHold(boolean hold){
		this.isHeld = hold;
	}
	
}
