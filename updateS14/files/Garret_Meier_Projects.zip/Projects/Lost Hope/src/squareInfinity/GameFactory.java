package squareInfinity;

import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Transparency;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Collection;

import javax.imageio.ImageIO;

public class GameFactory { // USE THIS TO MAKE GAME OBJECTS, THERE SHOULD ONLY BE ONE, MOST OF THE TIME
	
	protected LostHope controller;
	
	protected Location currentLocation;

	public static BufferedImage[] blocks;
	
	public static BufferedImage loadingImage;
	public static BufferedImage backgroundImage;
	
	private static GraphicsConfiguration config = 
			GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
	

	private static final String TILE_LOCATION = "Pic/Tiles/Finals/";
	
	private static final String DIRT_FILE = TILE_LOCATION + "Dirt.png";
	private static final String ROCK_FILE = TILE_LOCATION + "Stone.png";
	private static final String IRON_VEIN_FILE = TILE_LOCATION + "Iron.png";
	private static final String GRASS_FILE = TILE_LOCATION + "Grass.png";
	private static final String ADAMANTINE_VEIN_FILE = TILE_LOCATION + "Adamantine.png";
	private static final String COAL_VEIN_FILE = TILE_LOCATION + "Coal.png";
	private static final String GOLD_VEIN_FILE = TILE_LOCATION + "Gold.png";
	private static final String DIAMOND_VEIN_FILE = TILE_LOCATION + "Diamond.png";
	private static final String MITHRIL_VEIN_FILE = TILE_LOCATION + "Mithril.png";
	private static final String BROWN_AGATE_FILE = TILE_LOCATION + "BrownAgate.png";
	private static final String GARNET_FILE = TILE_LOCATION + "Garnet.png";
	private static final String OAK_WOOD_FILE = TILE_LOCATION +  "OakWood.png";
	private static final String LEAF_FILE = TILE_LOCATION + "Leaf.png";
	private static final String COPPER_VEIN_FILE = TILE_LOCATION + "Copper.png";
	private static final String TIN_VEIN_FILE = TILE_LOCATION + "Tin.png";
	private static final String SAND_FILE = TILE_LOCATION + "Sand.png";
	private static final String MARBLE_FILE = TILE_LOCATION + "Marble.png";
	private static final String GRANITE_FILE = TILE_LOCATION + "Granite.png";
	private static final String SANDSTONE_FILE = TILE_LOCATION + "SandStone.png";
	private static final String BIRCH_WOOD_FILE = TILE_LOCATION + "BirchWood.png";
	private static final String URANIUM_VEIN_FILE = TILE_LOCATION + "Uranium.png"; 
	private static final String AMETHYST_FILE = TILE_LOCATION + "Amethyst.png"; 
	private static final String ONYX_FILE = TILE_LOCATION + "Onyx.png";
	private static final String BERYL_FILE = TILE_LOCATION + "Beryl.png"; 
	private static final String SERAPHINITE_FILE = TILE_LOCATION + "Seraphinite.png";
	private static final String RED_FLOWER_FILE = "Pic/Plants/RedFlower.png";
	private static final String YELLOW_FLOWER_FILE = "Pic/Plants/YellowFlower.png";
	private static final String WORKBENCH_FILE = TILE_LOCATION+"WorkBench.png";
	private static final String BED_FILE = TILE_LOCATION+"Bed.png";
	private static final String CHAIR_FILE = TILE_LOCATION+"Chair.png";
	private static final String TABLE_FILE = TILE_LOCATION+"Table.png";
	private static final String CHEST_FILE = TILE_LOCATION+"Chest.png";
	private static final String STONE_WALL_FILE = TILE_LOCATION+"StoneWall.png";
	private static final String STONE_BLOCK_FILE = TILE_LOCATION+"StoneBlock.png";
	private static final String WOOD_PLANK_FILE = TILE_LOCATION+"WoodPlank.png";
	private static final String WOOD_STAIRS_FILE = TILE_LOCATION+"WoodStairs.png";
	private static final String ANVIL_FILE = TILE_LOCATION + "Anvil.png";
	private static final String FURNACE_FILE = TILE_LOCATION + "Furnace.png";
	private static final String LADDER_FILE = TILE_LOCATION + "Ladder.png";
	private static final String SAPLING_FILE = TILE_LOCATION + "Sapling.png";
	private static final String CACTUS_FILE = TILE_LOCATION + "Cactus.png";

	//private static final File WATER_FILE = new File(TILE_LOCATION + "Water.png");
	
	public GameFactory(LostHope controller){
		this.controller = controller;
		
		this.currentLocation = controller.getCurrentLocation();
		initImages();
	}
	
	public static void initImages(){
		
		// other classes
		
		Chest.loadChestImage();
		Door.loadDoorImages();
		//Consumable.loadAllImages();
		
		// basic stuff
		
		blocks=new BufferedImage[43];

		blocks[GameBlock.DIRT]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, DIRT_FILE);
		blocks[GameBlock.IRON_VEIN]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, IRON_VEIN_FILE);
		blocks[GameBlock.GRASS]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, GRASS_FILE);
		blocks[GameBlock.ROCK]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, ROCK_FILE);
		blocks[GameBlock.ADAMANTINE_VEIN]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, ADAMANTINE_VEIN_FILE);
		blocks[GameBlock.COAL_VEIN]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, COAL_VEIN_FILE);
		blocks[GameBlock.GOLD_VEIN]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, GOLD_VEIN_FILE);
		blocks[GameBlock.DIAMOND_VEIN]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, DIAMOND_VEIN_FILE);
		blocks[GameBlock.MITHRIL_VEIN]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, MITHRIL_VEIN_FILE);
		blocks[GameBlock.BROWN_AGATE]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, BROWN_AGATE_FILE);
		blocks[GameBlock.GARNET]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, GARNET_FILE);
		blocks[GameBlock.AMETHYST]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, AMETHYST_FILE);
		blocks[GameBlock.OAK_WOOD]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, OAK_WOOD_FILE);
		blocks[GameBlock.LEAF]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, LEAF_FILE);
		blocks[GameBlock.COPPER_VEIN]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, COPPER_VEIN_FILE);
		blocks[GameBlock.TIN_VEIN]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, TIN_VEIN_FILE);
		blocks[GameBlock.SAND]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, SAND_FILE);
		blocks[GameBlock.MARBLE]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, MARBLE_FILE);
		blocks[GameBlock.GRANITE]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, GRANITE_FILE);
		blocks[GameBlock.SANDSTONE]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, SANDSTONE_FILE);
		blocks[GameBlock.BIRCH_WOOD]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, BIRCH_WOOD_FILE);		
		blocks[GameBlock.URANIUM_VEIN]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, URANIUM_VEIN_FILE);
		blocks[GameBlock.ONYX]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, ONYX_FILE);
		blocks[GameBlock.BERYL]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, BERYL_FILE);
		blocks[GameBlock.SERAPHINITE]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, SERAPHINITE_FILE);
		blocks[GameBlock.RED_FLOWER]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, RED_FLOWER_FILE);
		blocks[GameBlock.YELLOW_FLOWER]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, YELLOW_FLOWER_FILE);
		blocks[GameBlock.WORKBENCH]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, WORKBENCH_FILE);
		blocks[GameBlock.BED]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, BED_FILE);
		blocks[GameBlock.CHAIR]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, CHAIR_FILE);
		blocks[GameBlock.TABLE]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, TABLE_FILE);
		blocks[GameBlock.CHEST]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, CHEST_FILE);
		blocks[GameBlock.STONE_WALL]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, STONE_WALL_FILE);
		blocks[GameBlock.STONE_BLOCK]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, STONE_BLOCK_FILE);
		blocks[GameBlock.WOOD_PLANK]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, WOOD_PLANK_FILE);
		blocks[GameBlock.WOOD_STAIRS]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, WOOD_STAIRS_FILE);
		blocks[GameBlock.ANVIL]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, ANVIL_FILE);
		blocks[GameBlock.FURNACE]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, FURNACE_FILE);
		blocks[GameBlock.LADDER]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, LADDER_FILE);
		blocks[GameBlock.SAPLING]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, SAPLING_FILE);
		blocks[GameBlock.CACTUS]=getOptimizedImage(LostHope.BLOCKSIDE, LostHope.BLOCKSIDE, CACTUS_FILE);
		
		loadingImage=getOptimizedImage("Pic/Logo/LoadingScreen_Small.png");
		backgroundImage=getOptimizedImage("Pic/Misc/Background.png");
		
	}
	
	public static BufferedImage getOptimizedImage(int width, int height, String file){
		BufferedImage b=getBufferedImage(width, height);
		b.createGraphics().drawImage(getImageResource(file), 0, 0, width, height, null);
		return b;
	}
	
	public static BufferedImage getOptimizedImage(String file){
		Image i=getImageResource(file);
		BufferedImage b=getBufferedImage(i.getWidth(null), i.getHeight(null));
		b.createGraphics().drawImage(getImageResource(file), 0, 0, b.getWidth(), b.getHeight(), null);
		return b;
	}
	
	public static BufferedImage getBufferedImage(int width, int height){
		return config.createCompatibleImage(Math.max(width,1), Math.max(height,1), Transparency.TRANSLUCENT);
	}
	
	public static Image getImageResource(String filename){
		//return Toolkit.getDefaultToolkit().getImage(filename);
		try {
			return ImageIO.read(new File(filename));
		} catch (IOException e) {
			System.out.println("Error reading image "+filename);
			return null;
		}
	}
	
	public void setLocationToEdit(Location location){
		this.currentLocation = location;
	}
	
	public void resetLocationToEdit(){
		this.currentLocation = controller.getCurrentLocation();
	}
	
	public Particle createParticle(double x, double y, byte type){
		Particle temp = new Particle(x,y,type);
		
		currentLocation.addParticle(temp);
		
		//controller.addPhysicsObjectMoveListener(temp); //Calls the particle's physicsobjecthasmoved
		
		//temp.addObjectCollisionListener(controller); //Calls LostHope's HasCollidedWithObject(particle, particle)
		
		return temp;
	}
	
	public PlasmaParticle createPlasmaParticle(double x, double y){
		PlasmaParticle temp = new PlasmaParticle(x, y);
		
		currentLocation.addPhysicsObject(temp);
		
		return temp;
	}
	
	public void destroyPlasmaParticle(PlasmaParticle particle){
		currentLocation.removePhysicsObject(particle);
	}
	
	public GameObject createGameObject(byte type, int x, int y, int width, int height){
		GameObject temp = new GameBlock(type, x, y, width, height);
		currentLocation.addObject(temp);
		updateNearbyObjects(temp, false);
		return temp;
	}
	
	public GameObject createGameObject(byte type, int x, int y){
		GameObject temp = new GameBlock(type,x,y);
		currentLocation.addObject(temp);
		updateNearbyObjects(temp, false);
		return temp;
	}
	
	public GameObject createBackgroundGameObject(byte type, int x, int y){
		GameObject temp = new BackgroundBlock(type,x,y);
		currentLocation.addObject(temp);
		return temp;
	}
	
	public NPC createNPC(NPC toMake) {
		Location location = currentLocation;
		
		location.addNPC(toMake);
		
		return toMake;
	}
	
	public Projectile createProjectile(byte type, int damage, double x, double y){
		Location location = currentLocation;
		
		Projectile temp = new Projectile(type, damage, x,y);
		
		location.addPhysicsObject(temp);
		return temp;
	}
	
	public Projectile createProjectile(byte type, int damage, double x, double y, int height, int width, double friction){
		Location location = currentLocation;
		
		Projectile temp = new Projectile(type, damage, x,y, height, width, friction);
		
		location.addPhysicsObject(temp);
		
		return temp;
	}
		
	public Projectile createProjectileFromUseableItem(UseableItem item, Player player){
		
		Dimension spawnPoint = item.getProjectileSpawnPoint();
		
		Projectile temp = new Projectile(player.getEquippedItem().getProjectile().getType(), 
				player.damage, 
				spawnPoint.getWidth() + player.getHandX(), spawnPoint.getHeight() + player.getHandY());
		int x=10;
		int y=1;
		if(temp.type==Projectile.ARROW){
			x=5;
			y=3;
		}
		if(player.isForward()){
			temp.setXSpeed(x+Math.random()*.3-.15);
		}else{
			temp.setXSpeed(-x+Math.random()*.3-.15);
		}
		
		temp.setYSpeed(-y+Math.random()*.3-.15);
		
		Location location = currentLocation;
		
		location.addPhysicsObject(temp);
		
		return temp;
	}
	
	public void destroyProjectile(Projectile projectile){
		currentLocation.destroyProjectile(projectile);
	}
	
	public void destroyParticle(Particle particle){
		currentLocation.removeParticle(particle);
	}
	
	public UseableItem createUseableItem(String name, int weight, int damage, Dimension rotationPoint, BufferedImage image, boolean doesRotate){
		return new UseableItem(name, weight, damage, rotationPoint, (Image) image, doesRotate);
	}
	
	public void addPeiceToInventory(Player player, Particle particle){
		player.addItemToInventory(new InventoryPeicesHolder(
				ObjectData.getNameForType(particle.getType()), particle.getType(), 1));
		
		//System.out.println("collected particle with id " + particle.type);
	}
	
	public GameObject convertParticleToStaticObject(Particle particle){
		currentLocation.removeParticle(particle);
		
		GameBlock particleAsObject = (GameBlock)createGameObject(particle.getType(), (int)particle.getX(), (int)particle.getY(), 2, 2);
		
		particleAsObject.canPickUp=true;
		return particleAsObject;
	}
	
	public Particle convertGameObjectToParticle(GameObject object){
		destroyGameObject(object);
		return createParticle(object.getX(), object.getY(), object.getPrimaryType());
	}
	
	public GameObject getCollidingGameObject(int x, int y, int width, int height){
		Collection<GameObject> c=null;
		if(width==0&&height==0) c=currentLocation.getObjectsAt(x, y);
		else c=currentLocation.getObjectsBetween(x, y, x+width, y+height);
		return (c!=null&&!c.isEmpty())?c.iterator().next():null;
	}
	
	protected static boolean inBounds(Object[][] objects, int x, int y) {
		return (x>=0&&y>=0&&x<objects.length&&y<objects[x].length);
	}

	public void destroyGameObject(GameObject object){
		currentLocation.removeObject(object);
		updateNearbyObjects(object, true);
	}
	
	private void updateNearbyObjects(GameObject object, boolean destroyed){
		if(currentLocation.generating) return;
		Collection<GameBlock> c=new ArrayDeque<GameBlock>(64);
		for(GameObject o:currentLocation.getObjectsBetween(object.x, object.y, 
				object.x+object.width, object.y+object.height)){
			if(o instanceof LiquidGameBlock){
				((LiquidGameBlock)o).updateBorders();
			}else if(o instanceof GameBlock && destroyed){
			//	if(((GameBlock) o).drop(controller)) c.add((GameBlock)o);
			}
		}
		for(GameBlock b:c) convertGameObjectToParticle(b);
	}
	
	public void replaceGameObject(GameObject object, byte newType){
		int x = object.getX();
		int y = object.getY();
		
		createGameObject(newType, x, y);
		
		destroyGameObject(object);
	}
	
	public LiquidGameBlock createLiquidGameBlock(int x, int y, int type){
		LiquidGameBlock temp = new LiquidGameBlock(x, y, type);
		temp.collides=false;
		currentLocation.addObject(temp);
		updateNearbyObjects(temp, false);
		return temp;
	}
	
	public double getDistanceBetweenPhysicsObjectAndPlayer(PhysicsObject p1){
		Player p = controller.getCurrentPlayer();
		
		return PhysicsObject.getDistanceBetweenTwoPoints(p1.getX(), p1.getY(), p.getX(), p.getY());
	}
	
	//Takes arrays of the form [x1, y1, x2, y2, dx, dy]
	//Returns the side of r2 that r1 is colliding with
	public static byte getCollisionSide(double[] r1, double[] r2){
		if(r1[0]<=r2[2]&&r1[1]<=r2[3]&&r1[2]>=r2[0]&&r1[3]>=r2[1]) return GameBlock.NO_COLLISION;
		byte collisionType=GameBlock.NO_COLLISION;
		double leastSqDist=Double.POSITIVE_INFINITY;
		//Calculate motion relative to r2, so we only have 1 moving object
		double dx=r1[4]-r2[4];
		double dy=r1[5]-r2[5];
		//Check each corner of r1
		for(int a=0; a<2; a++){
			for(int b=0; b<2; b++){
				double x=r1[a*2], y=r1[(b*2)+1];
				//Check each side of r2
				for(int c=0; c<4; c++){
					double val=r2[c];
					double intersect=c%2==0?((val-x)/dx)*dy + y:((val-y)/dy)*dx + x;
					//Intersection point is within the side of r2 - collision has occurred
					if(intersect>=r2[(c+1)%2] && intersect<=r2[(c+1)%2+2]){
						//Calculate distance to point of collision to see if it is the first collision
						double d1=(val-(c%2==0?x:y)), d2=(intersect-(c%2==0?y:x));
						double sqDist=d1*d1+d2*d2;
						if(sqDist<leastSqDist){
							leastSqDist=sqDist;
							collisionType=c==0?GameBlock.LEFT_COLLISION:c==1?GameBlock.TOP_COLLISION:c==2?
									GameBlock.RIGHT_COLLISION:GameBlock.BOTTOM_COLLISION;
						}
					}
				}
			}
		}
		return collisionType;
	}
	
	public static double fastInvSqrtApprox(double x) {
	    double a = Double.longBitsToDouble(0x5fe6ec85e7de30daL - (Double.doubleToLongBits(x)>>1));
	    return a*(1.5d - 0.5d*x*a*a);
	}
	
	public static BufferedImage getFlippedImage(BufferedImage image){
		AffineTransform at = AffineTransform.getScaleInstance(-1,1);
		
		
		
		at.translate(-image.getWidth(null), 0);
		
		AffineTransformOp op = new AffineTransformOp(at,
				AffineTransformOp.TYPE_NEAREST_NEIGHBOR);

		BufferedImage image2 = op.filter(image, null);
		
		return image2;
	}

}
