package squareInfinity;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Chest extends GameObject implements InteractibleObject{
	
	public static BufferedImage CHEST_IMAGE = null;

	private InventoryItem[][] items;
	
	private int itemsWidth;
	private int itemsHeight;
	
	public Chest(int x, int y) {
		super(x, y, (byte)0);
		
		this.setWidth(LostHope.BLOCKSIDE);
		this.setHeight(LostHope.BLOCKSIDE);
		
		this.itemsWidth = 20;
		this.itemsHeight = 20;
		
		items = new InventoryItem[itemsWidth][itemsHeight];
	}
	
	@Override
	public void clickedOn(LostHope controller){
		// TODO: nothing happens when clicked on
	}
	
	public static void loadChestImage(){
		File f = new File("Pic/Tiles/Finals/Chest.png");

		try {
			CHEST_IMAGE = ImageIO.read(f);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public InventoryItem[][] getItems(){
		return this.items;
	}
	
	public int getItemsWidth(){
		return this.itemsWidth;
	}
	
	public int getItemsHeight(){
		return this.itemsHeight;
	}

	@Override
	public void setPower(int power) {
		// TODO does nothing right now
	}

	@Override
	public void magicExplode(LostHope controller, int power) {
		// TODO magic explode does nothing
	}

	@Override
	public void toggleHold(boolean isHeld) {
		// TODO toggle hold does nothing
	}

	@Override
	public MagicPrimitive createCopyOfSelf() {
		// TODO create copy does nothing and returns null
		return null;
	}

	@Override
	public void drawSelf(Graphics g, int xOffset, int yOffset) {
		g.drawImage(CHEST_IMAGE, this.x + xOffset, this.y + yOffset, null);
	}


	@Override
	public void forceApplied(double force, LostHope controller) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public byte isObjectWithin(PhysicsObject object) {
		// TODO Auto-generated method stub
		return 0;
	}

}
