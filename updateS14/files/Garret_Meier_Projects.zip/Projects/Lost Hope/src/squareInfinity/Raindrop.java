package squareInfinity;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Raindrop {
	
	
	private int startX;
	private int startY;
	private int endX;
	private int endY;
	
	private int x;
	private double y;
	
	private int oldX;
	private double oldY;
	
	private double ySpeed;
	
	public Raindrop(int startX, int startY, int endX, int endY){
		this.startX = startX;
		this.startY = startY;
		
		this.endX = endX;
		this.endY = endY;
		
		this.x = startX;
		this.y = startY;
		
		this.ySpeed = 1;
	}
	
	public double getYSpeed(){
		return this.ySpeed;
	}
	
	public void setSpeed(double speed){
		this.ySpeed = speed;
	}
	
	public void moveSelf(){
		this.oldX = x;
		this.oldY = y;
		
		this.y = this.y + ySpeed;
	}
	
	
	public void drawSelf(Graphics g, int xOffset, int yOffset){
		g.setColor(Color.BLUE);
		
		g.drawLine(x + xOffset, (int) y + yOffset, (startX - endX) + x + xOffset, (startY - endY) + (int)y + yOffset);
	}
	
	private int lockToGrid(int gridSize, double number){
		return (int) (number / gridSize) * gridSize;
	}
	
	public void checkCollisions(LostHope controller, int xOffset, int yOffset, RainWeather weatherController, boolean spawnsParticles){
		Location currentLocation = controller.getCurrentLocation();
		
		Chunk chunk = currentLocation.getChunkForLocation(this.x, (int)this.y);
		
		int x = lockToGrid(LostHope.BLOCKSIDE, this.x);
		int y = lockToGrid(LostHope.BLOCKSIDE, this.y);
		
		if(x < 0){
			x = 0;
		}else if(x >= Chunk.CHUNKSIZE + chunk.getX()){
			x = (Chunk.CHUNKSIZE + chunk.getX()) - 1;
		}
		if(y<0){
			y = 0;
		}else if(y >= Chunk.CHUNKSIZE + chunk.getY()){
			y = (Chunk.CHUNKSIZE + chunk.getY()) - 1;
		}
		
		
		if(chunk.get(x, y) != null){
			weatherController.destroyRaindrop(this);
			
			if(spawnsParticles){
				Particle p1 = LostHope.factory.createParticle(oldX, oldY, ObjectData.WATER);
				Particle p2 = LostHope.factory.createParticle(oldX, oldY, ObjectData.WATER);
				Particle p3 = LostHope.factory.createParticle(oldX, oldY, ObjectData.WATER);
				
				Random r = new Random();
				
				p1.setXSpeed(r.nextInt(6));
				p1.setYSpeed(r.nextInt(6));
				
				p2.setXSpeed(r.nextInt(6));
				p2.setYSpeed(r.nextInt(6));
				
				p3.setXSpeed(r.nextInt(6));
				p3.setYSpeed(r.nextInt(6));
			}
		}
	}

}
