package squareInfinity;

public class SettingsProfile {
	
	private boolean music;
	private int musicLevel;
	
	private int width;
	private int height;
	
	public SettingsProfile(){
		
	}
	
	public boolean isMusicOn(){
		return this.music;
	}
	
	public void setMusic(boolean isOn){
		this.music = isOn;
	}
	
	public int getMusicLevel(){
		return this.musicLevel;
	}
	
	public void setMusicLevel(int level){
		this.musicLevel = level;
	}
	
	public int getWidth(){
		return this.width;
	}
	
	public void setWidth(int width){
		this.width = width;
	}
	
	public int getHeight(){
		return this.height;
	}
	
	public void setHeight(int height){
		this.height = height;
	}

}
