package squareInfinity;

import java.awt.Graphics;
import java.io.Serializable;

@SuppressWarnings("serial")
public abstract class GameObject implements MagicPrimitive, Serializable{
	protected int x;
	protected int y;
	
	protected int width;
	protected int height;
	protected byte type;
	protected byte primaryType;
	
	protected boolean collides=true;
	
	public GameObject(int x, int y, byte primaryType){
		this.x = x;
		this.y = y;
		
		this.primaryType = primaryType;
	}
	
	public abstract void drawSelf(Graphics g, int xOffset, int yOffset);
	
	public abstract byte isObjectWithin(PhysicsObject object);
	
	public abstract void forceApplied(double force, LostHope controller);
	
	public byte getType() {
		return this.type;
	}
	public byte getPrimaryType(){
		return this.primaryType;
	}
	
	public void setX(int x){
		this.x = x;
	}
	
	public void setY(int y){
		this.y = y;
	}
	
	public void setWidth(int width){
		this.width = width;
	}
	
	public void setHeight(int height){
		this.height = height;
	}
	

	public int getX(){
		return this.x;
	}
	
	public int getY(){
		return this.y;
	}
	
	public int getWidth(){
		return this.width;
	}
	
	public int getHeight(){
		return this.height;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (collides ? 1231 : 1237);
		result = prime * result + height;
		result = prime * result + primaryType;
		result = prime * result + type;
		result = prime * result + width;
		result = prime * result + x;
		result = prime * result + y;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GameObject other = (GameObject) obj;
		if (collides != other.collides)
			return false;
		if (height != other.height)
			return false;
		if (primaryType != other.primaryType)
			return false;
		if (type != other.type)
			return false;
		if (width != other.width)
			return false;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}
}
