package squareInfinity;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JComponent;


public class GameButton implements MouseListener{
	
	protected ArrayList<GameButtonListener> listeners;
	
	protected int x;
	protected int y;
	
	protected Image image;
	protected Image mouseOverImage;
	
	protected int width; // inherited from the images...
	protected int height;
	
	public GameButton(int x, int y, Image image, Image mouseOverImage){
		this.x = x;
		this.y = y;
		
		this.image = image;
		this.mouseOverImage = mouseOverImage;
	}
	
	public void setComponentConnection(JComponent component){
		component.addMouseListener(this);
	}
	
	
	public void notifyListeners(){
		Iterator<GameButtonListener> listenersIterator = listeners.iterator();
		
		while(listenersIterator.hasNext()){
			listenersIterator.next().mouseHasClicked();
		}
	}
	
	
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
