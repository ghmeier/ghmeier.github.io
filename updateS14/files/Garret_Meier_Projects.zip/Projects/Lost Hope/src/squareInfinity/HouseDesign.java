package squareInfinity;

public class HouseDesign {
	
	private byte[][] stuff;
	
	private int width;
	private int height;
	private byte type;
	
	public static byte HOUSE = 0;
	public static byte WELL = 1;
	public static byte BLACKSMITH = 2;
	public static byte MARKET = 3;
	public static byte INN = 4;
	
	public HouseDesign(int width, int height, byte type){
		this.stuff = new byte[width][height];
		
		this.width = width;
		this.height = height;
		this.type = type;
	}
	
	public int getType() {
		return this.type;
	}
	public int getWidth(){
		return this.width;
	}
	
	public int getHeight(){
		return this.height;
	}
	
	public byte get(int x, int y){
		return stuff[x][y];
	}
	
	public void set(int x, int y, byte number){
		stuff[x][y] = number;
	}
	
	public void createSelf(int startX, int startY){
		for(int x=0; x<stuff.length; x++){
			for(int y=0; y<stuff[0].length; y++){
				if(stuff[x][y] != 0){
					int trueX = (x + startX) * LostHope.BLOCKSIDE;
					int trueY = (y + startY - stuff[0].length) * LostHope.BLOCKSIDE;
					
					if(stuff[x][y] == GameBlock.STONE_BLOCK || stuff[x][y]==GameBlock.WOOD_PLANK || stuff[x][y] == GameBlock.WOOD_STAIRS){
						LostHope.factory.createGameObject(stuff[x][y], 
								trueX, trueY);
					}else{
						LostHope.factory.createBackgroundGameObject(stuff[x][y],
								trueX, trueY);
					}
				}
			}
		}
	}

}
