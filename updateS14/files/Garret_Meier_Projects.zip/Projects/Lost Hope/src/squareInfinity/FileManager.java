package squareInfinity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class FileManager {
	
	private String mainDirectory;
	
	public FileManager(){
		mainDirectory = "";
	}
	
	public void loadChunks(Chunk[][] arrayToLoadInto, int x, int y, int width, int height){
		int chunkX = 0;
		int chunkY = 0;
		
		for(int trueX = x; trueX<width + x; trueX = trueX + Chunk.CHUNKSIZE){
			for(int trueY = y; trueY<height + y; trueY = trueY + Chunk.CHUNKSIZE){
				arrayToLoadInto[chunkX][chunkY] = loadChunk(trueX, trueY);
				
				chunkY = chunkY + 1;
			}
			chunkY = 0;
			chunkX = chunkX + 1;
		}
	}
	
	public Chunk loadChunk(int x, int y){
		Chunk theChunk = null;
		
		File file = new File("Saves/World/" + x + "-" + y + ".lhsv");
		
		System.out.println("loading file at" + x +"," + y);
		
		try {
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			theChunk = (Chunk) ois.readObject();
			
			ois.close();
			fis.close();
		} catch (FileNotFoundException e) {
			System.err.println("Could not find chunk at " + x + ", " + y);
		} catch (IOException e){
			e.printStackTrace();
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		
		return theChunk;
	}
	
	public void saveChunk(Chunk chunk){
		File locationFile = new File("Saves/World/");
		
		locationFile.mkdirs();
		
		File file = new File("Saves/World/", chunk.getX() + "-" + chunk.getY() + ".lhsv");
		
		try {
			FileOutputStream fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			
			oos.writeObject(chunk);
			
			oos.close();
			fos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	public void saveAndUnloadChunks(Chunk[][] chunks, int startX, int startY, int endX, int endY){
		saveChunks(chunks, startX, startY, endX, endY);
		
		for(int x=startX; x<endX; x++){
			for(int y=startY; y<endY; y++){
				chunks[x][y] = null;
			}
		}
	}
	
	public void saveChunks(Chunk[][] chunks, int startX, int startY, int endX, int endY){
		for(int x=startX; x<endX; x++){
			for(int y=startY; y<endY; y++){
				saveChunk(chunks[x][y]);
			}
		}	
	}
	
	private void saveGameObject(FileOutputStream fos, GameObject object){
		if(object instanceof GameBlock){
			GameBlock gameBlock = (GameBlock) object;
			
			
		}else if(object instanceof LiquidGameBlock){
			LiquidGameBlock liquidBlock = (LiquidGameBlock) object;
			
			
		}else{
			// nothing, I think...
		}
	}
	
	

}
