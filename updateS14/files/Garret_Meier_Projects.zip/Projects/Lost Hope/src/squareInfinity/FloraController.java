package squareInfinity;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class FloraController {
	
	private Collection<Flora> plants;
	
	private long oldTime;
	private long timeToSleep;
	
	public FloraController(long timeToSleep){
		plants = new HashSet<Flora>();
		
		oldTime = System.currentTimeMillis();
		this.timeToSleep = timeToSleep;
	}
	
	public long getTimeToSleep(){
		return this.timeToSleep;
	}
	
	public void add(Flora f){
		plants.add(f);
	}
	
	public void remove(Flora f){
		plants.remove(f);
	}
	
	public void updateAllPlants(LostHope controller){
		Iterator<Flora> plantsIterator = plants.iterator();
		
		while(plantsIterator.hasNext()){
			Flora f = plantsIterator.next();
			
			f.grow(controller);
		}
	}
	
	public void dealWithPlants(LostHope controller){
		long newTime = System.currentTimeMillis();
		
		if(newTime - oldTime >= timeToSleep){
			updateAllPlants(controller);
			
			oldTime = System.currentTimeMillis();
		}
	}
}