package squareInfinity;

public class HandLocation {
	
	private int leftX;
	private int leftY;
	
	private int rightX;
	private int rightY;
	
	public HandLocation(int leftX, int leftY, int rightX, int rightY){
		this.leftX = leftX;
		this.leftY = leftY;
		
		this.rightX = rightX;
		this.rightY = rightY;
	}
	
	public int getLeftX(){
		return this.leftX;
	}
	
	public int getRightX(){
		return this.rightX;
	}
	
	public int getRightY(){
		return this.rightY;
	}
	
	public int getLeftY(){
		return this.leftY;
	}

}
