package squareInfinity;

public interface InteractibleObject {
	
	public void clickedOn(LostHope controller);

}
