package squareInfinity;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class HouseBlueprintDesigner implements ActionListener{
	
	private JFrame mainFrame;
	
	private HouseDesign design;
	
	private GridButton[][] buttons;
	
	private JPanel westPanel;
	
	private ArrayList<SelectorButton> selectorButtons;
	
	private JButton createButton;
	
	private byte currentValue;
	
	private int width;
	private int height;
	private byte type;
	
	public HouseBlueprintDesigner(int width, int height){
		this.width = width;
		this.height = height;
		
		GameFactory.initImages();
		
		this.currentValue = 0;
		
		this.selectorButtons = new ArrayList<SelectorButton>();
		
		design = new HouseDesign(width, height, type);
		
		buttons = new GridButton[width][height];
		
		for(int x=0; x<buttons.length; x++){
			for(int y=0; y<buttons[0].length; y++){
				buttons[x][y] = new GridButton("",x,y);
				buttons[x][y].addActionListener(this);
			}
		}
		
		setupGUI();
		
		createSelectorButton("Wood Planks", GameBlock.WOOD_PLANK);
		createSelectorButton("Stone Wall", GameBlock.STONE_WALL);
		createSelectorButton("Wood Stairs", GameBlock.WOOD_STAIRS);
		
		createButton = new JButton("Create Blueprint");
		createButton.addActionListener(this);
		westPanel.add(createButton);
		
		
		
		
		//mainFrame.pack();
	}
	
	public SelectorButton createSelectorButton(String name, byte type){
		SelectorButton temp = new SelectorButton(name, type);
		
		addSelectorButton(temp);
		
		return temp;
	}
	
	public void addSelectorButton(SelectorButton button){
		this.selectorButtons.add(button);
		westPanel.add(button);
		button.addActionListener(this);
	}
	
	public void setupGUI(){
		mainFrame = new JFrame("House Blueprint Designer");
		
		JPanel centerPanel = new JPanel();		
		centerPanel.setLayout(new GridLayout(width, height));
		
		for(int x=0; x<buttons.length; x++){
			for(int y=0; y<buttons.length; y++){
				centerPanel.add(buttons[x][y],y,x);
			}
		}
		
		westPanel = new JPanel();
		westPanel.setLayout(new BoxLayout(westPanel, BoxLayout.Y_AXIS));
		
		
		Container mainContainer = mainFrame.getContentPane();
		
		mainContainer.add(BorderLayout.CENTER, centerPanel);
		mainContainer.add(BorderLayout.WEST, westPanel);
		
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.setSize(800,600);
		mainFrame.setLocationRelativeTo(null);
		mainFrame.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent ae){
		
		
		JButton source = (JButton) ae.getSource();
		
		if(!(source instanceof SelectorButton)){
			if(this.currentValue != 0){
				GridButton gButton = (GridButton) source;
				
				ImageIcon icon = new ImageIcon(GameFactory.blocks[currentValue]);
				
				gButton.setIcon(icon);
			}
		}else if(source instanceof SelectorButton){
			SelectorButton sButton = (SelectorButton) source;
			
			this.currentValue = sButton.getSelection();
		}else if(source == createButton){
			this.createBlueprint();
		}
		
	}
	
	public void createBlueprint(){
		for(int x=0; x<buttons.length; x++){
			for(int y=0; y<buttons[0].length; y++){
				design.set(x, y, buttons[x][y].getValue());
			}
		}
		
		
	}
	
	
	
	public static void setupNewWindow(){
		JFrame mainFrame = new JFrame("Select Size");
		
		JTextField widthField = new JTextField(5);
		JTextField heightField = new JTextField(5);
		JPanel widthPanel = new JPanel();
		JPanel heightPanel = new JPanel();
		JLabel widthLabel = new JLabel("Width:");
		JLabel heightLabel = new JLabel("Height:");
		
		JButton createButton = new JButton("Create Blank Blueprint");
		createButton.addActionListener(new BlueprintCreationListener(widthField, heightField, mainFrame));
		
		widthPanel.add(widthLabel);
		widthPanel.add(widthField);
		heightPanel.add(heightLabel);
		heightPanel.add(heightField);
		
		Container mainContainer = mainFrame.getContentPane();
		
		mainContainer.add(BorderLayout.NORTH, widthPanel);
		mainContainer.add(BorderLayout.CENTER, heightPanel);
		mainContainer.add(BorderLayout.SOUTH,createButton);
		
		mainFrame.setSize(300,150);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.setLocationRelativeTo(null);
		mainFrame.setVisible(true);
	}
	
	public static class BlueprintCreationListener implements ActionListener{
		
		JTextField widthField;
		JTextField heightField;
		
		JFrame frameToClose;
		
		public BlueprintCreationListener(JTextField widthField, JTextField heightField, JFrame frameToClose){
			this.widthField = widthField;
			this.heightField = heightField;
			
			this.frameToClose = frameToClose;
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			int width = Integer.parseInt(widthField.getText());
			int height = Integer.parseInt(heightField.getText());
			
			frameToClose.dispose();
			
			HouseBlueprintDesigner hbd = new HouseBlueprintDesigner(width,height);
		}
		
	}
	
	
	
	public static void main(String[] args){
		HouseBlueprintDesigner.setupNewWindow();
	}

}
