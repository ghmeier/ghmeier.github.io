package squareInfinity.kdtree;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.Set;

public class KDTree<T> implements Iterable<T>{
	private int dimensions;
	private int bucketSize=50;
	private KDNode root;
	private int size=0;
	private boolean rectangular;
	
	public KDTree(int dimensions, boolean rectangular){
		this.rectangular=rectangular;
		if(rectangular && dimensions%2!=0) 
			throw new IllegalArgumentException("Dimensions must be even for rectangles!");
		this.dimensions=dimensions;
		root=new KDNode(0);
	}
	
	public void add(int[] key, T value){
		root.add(key, value);
		size++;
	}
	
	public void addAll(Collection<KDEntry> vals){
		root.addAll(vals);
		size+=vals.size();
	}
	
	public void addAll(Map<List<Integer>, Collection<T>> vals){
		Set<KDNode> leaves=new HashSet<KDNode>();
		for(List<Integer> i:vals.keySet()) for(T val:vals.get(i))leaves.add(root.addNoSplit(new KDEntry(i, val)));
		for(KDNode n:leaves) n.splitIfNecessary();
		size+=vals.size();
	}
	
	public boolean contains(int[] key){
		return root.contains(key);
	}
	
	public T get(int[] key){
		return root.get(key);
	}
	
	public T remove(int[] key){
		T val=root.remove(key);
		if(val!=null) size--;
		return val;
	}
	
	//Search for points contained within the range if point-based
	//Search for rectangles intersecting with the range if rectangle-based
	public Collection<T> searchRange(int[] start, int[] end){
		if((rectangular&&(start.length!=dimensions/2||end.length!=dimensions/2))||(!rectangular&&(start.length!=dimensions||end.length!=dimensions))) 
			throw new IllegalArgumentException("Wrong dimensions!");
		if(size==0) return new ArrayDeque<T>();
		if(rectangular) return root.searchRangeRect(new ArrayDeque<T>(), start, end);
		else return root.searchRange(new ArrayDeque<T>(), start, end);
	}
	
	//Same as get() if point-based, since a point only contains itself
	//Search for rectangles containing the point if rectangle-based
	public Collection<T> searchContaining(int[] point){
		if(rectangular){
			if(point.length!=dimensions/2) 
				throw new IllegalArgumentException("Wrong dimensions!");
			if(size==0) return new ArrayDeque<T>();
			return root.searchContaining(new ArrayDeque<T>(), point);
		}
		else{
			ArrayDeque<T> a=new ArrayDeque<T>();
			a.add(get(point));
			return a;
		}
	}
	
	
	public int size(){
		return size;
	}
	
	@Override
	public Iterator<T> iterator() {
		return root.iterator();
	}
	
	public int maxHeight(KDNode n){
		if(n.leaf) return 0;
		return Math.max(maxHeight(n.left), maxHeight(n.right))+1;
	}
	
	public int minHeight(KDNode n){
		if(n.leaf) return 0;
		return Math.min(minHeight(n.left), minHeight(n.right))+1;
	}
	
	public int maxHeight(){
		if(root.leaf) return 0;
		return Math.max(maxHeight(root.left), maxHeight(root.right))+1;
	}
	
	public int minHeight(){
		if(root.leaf) return 0;
		return Math.min(minHeight(root.left), minHeight(root.right))+1;
	}
	
	private class KDNode{
		private boolean leaf;
		private ArrayDeque<KDEntry> entries;
		private double slice;
		private int sliceDimension;
		private KDNode left;
		private KDNode right;
		
		private double[] entriesMean = null, entriesSumSqDev = null;
		// Optimisation when sub-tree contains only duplicates
		private boolean singularity = true;
		// Optimisation for searches. This lets us skip a node if its
		// scope intersects with a search hypersphere but it doesn't contain
		// any points that actually intersect.
		private int[] contentMax = null, contentMin = null;
		
		private KDNode(int dim){
			entries=new ArrayDeque<KDEntry>(bucketSize);
			leaf=true;
			sliceDimension=dim;
		}
		
		private void addAll(Collection<KDEntry> vals){
			Set<KDNode> leaves=new HashSet<KDNode>();
			for(KDEntry e:vals) leaves.add(addNoSplit(e));
			for(KDNode n:leaves) n.splitIfNecessary();
		}
		
		private void add(int[] key, T value){
			addNoSplit(new KDEntry(key, value)).splitIfNecessary();
		}
		
		private KDNode addNoSplit(KDEntry e){
			updateBounds(e);
			if(leaf){
				if(singularity && entries.size()>0 && !e.keyEquals(entries.peek())) singularity=false;
				entries.add(e);
				
				if (entries.size() == 1) {
					entriesMean = new double[dimensions];
					for(int i=0; i<dimensions; i++) entriesMean[i]=e.key[i];
					entriesSumSqDev = new double[dimensions];
				} else {
					for(int d = 0; d < dimensions; d++) {
						final double coord = e.key[d];
						final double oldMean = entriesMean[d], newMean;
						entriesMean[d] = newMean =
							oldMean + (coord - oldMean)/entries.size();
						entriesSumSqDev[d] = entriesSumSqDev[d]
							+ (coord - oldMean)*(coord - newMean);
					}
				}
				
				return this;
			}else{
				if(e.key[sliceDimension]<slice) return left.addNoSplit(e);
				else return right.addNoSplit(e);
			}
		}
		
		private void splitIfNecessary(){
			if(!singularity && entries.size()>bucketSize) splitNode();
		}
		
		private boolean contains(int[] key){
			if(leaf){
				for(KDEntry e:entries) if(e.keyEquals(key)) return true;
				return false;
			}else{
				if(key[sliceDimension]<slice) return left.contains(key);
				else return right.contains(key);
			}
		}
		
		private T get(int[] key){
			if(leaf){
				for(KDEntry e:entries) if(e.keyEquals(key)) return e.value;
				return null;
			}else{
				if(key[sliceDimension]<slice) return left.get(key);
				else return right.get(key);
			}
		}
		
		private T remove(int[] key){
			if(leaf){
				Iterator<KDEntry> i=entries.iterator();
				while(i.hasNext()){
					KDEntry e = i.next();
					if(e.keyEquals(key)){
						i.remove();
						recalcStats();
						return e.value;
					}
				}
				return null;
			}else{
				if(key[sliceDimension]<slice){
					T val=left.remove(key);
					if(val!=null && left.leaf && left.entries.size()==0) combineChild(right);
					return val;
				}
				else{
					T val=right.remove(key);
					if(val!=null && right.leaf && right.entries.size()==0) combineChild(left);
					return val;
				}
			}
		}
		
		private Collection<T> searchRange(Collection<T> results, int[] start, int[] end){
			if(rectIntersects(contentMin, contentMax, start, end)){
				if(leaf){
					for(KDEntry e:entries) if(rectContains(start, end, e.key)) results.add(e.value);
				}else{
					left.searchRange(results, start, end);
					right.searchRange(results, start, end);
				}
			}
			return results;
		}
		
		//////////////////Functions for rectangle - based trees//////////////////////
		private Collection<T> searchRangeRect(Collection<T> results, int[] start, int[] end){
			if(rectIntersects(Arrays.copyOf(contentMin, dimensions/2), 
					Arrays.copyOfRange(contentMax, dimensions/2, dimensions), start, end)){
				if(leaf){
					for(KDEntry e:entries) if(rectIntersects(start, end, Arrays.copyOf(e.key, dimensions/2), 
							Arrays.copyOfRange(e.key, dimensions/2, dimensions))) results.add(e.value);
				}else{
					left.searchRangeRect(results, start, end);
					right.searchRangeRect(results, start, end);
				}
			}
			return results;
		}
		
		private Collection<T> searchContaining(Collection<T> results, int[] point){
			if(rectContains(Arrays.copyOf(contentMin, dimensions/2), 
					Arrays.copyOfRange(contentMax, dimensions/2, dimensions), point)){
				if(leaf){
					for(KDEntry e:entries) if(rectContains(Arrays.copyOf(e.key, dimensions/2), 
								Arrays.copyOfRange(e.key, dimensions/2, dimensions), point)) results.add(e.value);
				}else{
					left.searchContaining(results, point);
					right.searchContaining(results, point);
				}
			}
			return results;
		}
		
		/////////////////Utility stuff/////////////////////
		
		@SuppressWarnings("unchecked")
		private void splitNode() {
			// Find dimension with largest variance to split on
			double largestVar = -1;
			int splitDim = 0;
			for(int d = 0; d < dimensions; d++) {
				final double var = entriesSumSqDev[d];
				if (var > largestVar) {
					largestVar = var;
					splitDim = d;
				}
			}

			// Find mean as position for our split
			double splitValue = entriesMean[splitDim];

			// Check that our split actually splits our data. This also lets
			// us bulk load data into sub-trees, which is more likely
			// to keep optimal balance.
			final Queue<KDEntry> leftExs = new ArrayDeque<KDEntry>();
			final Queue<KDEntry> rightExs = new ArrayDeque<KDEntry>();
			for(KDEntry e : entries) {
				if (e.key[splitDim] <= splitValue)
					leftExs.add(e);
				else
					rightExs.add(e);
			}
			int leftSize = leftExs.size();
			if (leftSize == entries.size() || leftSize == 0) {
				System.err.println(
					"WARNING: Randomly splitting non-uniform tree");
				// We know the data aren't all the same, so try picking
				// an exemplar and a dimension at random for our split point

				// This might take several tries, so we copy our data to
				// an array to speed up process of picking a random point
				Object[] exs = entries.toArray();
				while (leftSize == entries.size() || leftSize == 0) {
					leftExs.clear();
					rightExs.clear();

					splitDim = (int)
						Math.floor(Math.random()*dimensions);
					final int splitPtIdx = (int)
						Math.floor(Math.random()*exs.length);
					// Cast is inevitable consequence of java's inability to
					// create a generic array
					splitValue = ((KDEntry)exs[splitPtIdx]).key[splitDim];
					for(KDEntry e : entries) {
						if (e.key[splitDim] <= splitValue)
							leftExs.add(e);
						else
							rightExs.add(e);
					}
					leftSize = leftExs.size();
				}
			}

			// We have found a valid split. Start building our sub-trees
			left = new KDNode(dimensions);
			right = new KDNode(dimensions);
			left.addAll(leftExs);
			right.addAll(rightExs);
			leaf=false;

			// Finally, commit the split
			sliceDimension = splitDim;
			slice = splitValue;

			// Let go of data (and their running stats) held in this leaf
			entries.clear();
			entriesMean = entriesSumSqDev = null;
		}
		
		
		private void combineChild(KDNode child){
			if(child.leaf){
				leaf=true;
				entries=child.entries;
				left=null;
				right=null;
				entriesMean=child.entriesMean;
				entriesSumSqDev=child.entriesSumSqDev;
				singularity=child.singularity;
				contentMax=child.contentMax;
				contentMin=child.contentMin;
			}else{
				left=child.left;
				right=child.right;
				slice=child.slice;
				sliceDimension=child.sliceDimension;
			}
		}
		
		private void updateBounds(KDEntry e) {
			if (contentMax == null) {
				contentMax = Arrays.copyOf(e.key, dimensions);
				contentMin = Arrays.copyOf(e.key, dimensions);
			} else {
				for(int d=0; d<dimensions; d++) {
					if (e.key[d] > contentMax[d]) contentMax[d] = e.key[d];
					else if (e.key[d] < contentMin[d]) contentMin[d] = e.key[d];
				}
			}
		}
		
		private void recalcStats(){
			if (entries.size() > 0) {
				ArrayDeque<KDEntry> a = new ArrayDeque<KDEntry>(entries);
				entriesMean = new double[dimensions];
				entriesSumSqDev = new double[dimensions];
				for(int i=1; i<=entries.size(); i++){
					KDEntry e=a.poll();
					for(int d = 0; d < dimensions; d++) {
						final double coord = e.key[d];
						final double oldMean = entriesMean[d], newMean;
						entriesMean[d] = newMean =
							oldMean + (coord - oldMean)/i;
						entriesSumSqDev[d] = entriesSumSqDev[d]
							+ (coord - oldMean)*(coord - newMean);
					}
				}
			}
		}
		
		private Iterator<T> iterator(){
			if(leaf){
				ArrayDeque<T> a=new ArrayDeque<T>();
				for(KDEntry e:entries) a.add(e.value);
				return a.iterator();
			}
			return new KDIterator(this);
		}
	}
	
	// check if this hyper rectangle contains a give hyper-point
	private static boolean rectContains(int[] lower, int[] upper, int[] point) {
		for (int i = 0; i < point.length; ++i) {
			if (point[i] > upper[i] || point[i] < lower[i]) return false;
		}
		return true;
	}
 
	// checks if two hyper-rectangles intersect
	private static boolean rectIntersects(int[] low0, int[] up0, int[] low1, int[] up1) {
		for (int i = 0; i < up0.length; ++i) {
			if (up1[i] < low0[i] || low1[i] > up0[i]) return false;
		}
		return true;
	}
	
	public class KDEntry{
		public int[] key;
		T value;
		public KDEntry(int[] key, T value){
			this.key=key;
			this.value=value;
		}
		public KDEntry(List<Integer> k, T value) {
			this.key=new int[k.size()];
			int i=0;
			for(int j:k) this.key[i++]=j;
			this.value=value;
		}
		private boolean keyEquals(int[] key){
			return Arrays.equals(key, this.key);
		}
		private boolean keyEquals(KDEntry e){
			return Arrays.equals(e.key, this.key);
		}
	}
	
	private class KDIterator implements Iterator<T>{
		private Iterator<T> toRemove;
		private Iterator<T> leftIterator;
		private Iterator<T> rightIterator;
		
		private KDIterator(KDNode root){
			if(!root.leaf){
				leftIterator=root.left.iterator();
				rightIterator=root.right.iterator();
			}else leftIterator=rightIterator=root.iterator();
		}

		@Override
		public boolean hasNext() {
			return (leftIterator.hasNext()||rightIterator.hasNext());
		}

		@Override
		public T next() {
			if(leftIterator.hasNext()){
				toRemove=leftIterator;
				return leftIterator.next();
			}
			else if(rightIterator.hasNext()){
				toRemove=rightIterator;
				return rightIterator.next();
			}
			else throw new NoSuchElementException();
		}

		@Override
		public void remove() {
			if(toRemove!=null) toRemove.remove();
		}
		
	}
	
	/*public static void main(String[] args){
		KDTree<Integer> kd=new KDTree<Integer>(4, true);
		TreeMap<Integer[], Integer> tree=new TreeMap<Integer[], Integer>(new Comparator<Integer[]>() {
			@Override
			public int compare(Integer[] o1, Integer[] o2) {
				return o1[0]-o2[0];
			}
		});
		Set<Integer[]> keys=new HashSet<Integer[]>();
		Random rng=new Random();
		//int[][] arr=new int[10000][10000];
		for(int i=0; i<1000000; i++){
			Integer[] key=new Integer[]{rng.nextInt(1000000),rng.nextInt(1000000),rng.nextInt(1000000),rng.nextInt(1000000)};
			keys.add(key);
		}
		long time1=System.currentTimeMillis();
		for(Integer[] key:keys){
			kd.add(new int[]{key[0],key[1],key[2],key[3]}, rng.nextInt(100));
		}
		System.out.println("KD Add: "+(System.currentTimeMillis()-time1));
		System.out.println("KD Balance: "+kd.maxHeight(kd.root)+" "+kd.minHeight(kd.root));
		time1=System.currentTimeMillis();
		for(Integer[] key:keys){
			tree.put(key, rng.nextInt(100));
		}
		System.out.println("TreeMap Add: "+(System.currentTimeMillis()-time1));
		time1=System.currentTimeMillis();

		for(Integer[] k:keys){
			if(!kd.contains(new int[]{k[0],k[1],k[2],k[3]})) System.out.println("KD Contains fail");
		}
		System.out.println("KD Contains: "+(System.currentTimeMillis()-time1));
		time1=System.currentTimeMillis();
		for(Integer[] k:keys){
			if(!tree.containsKey(k)) System.out.println("TreeMap Contains fail");
		}
		System.out.println("TreeMap Contains: "+(System.currentTimeMillis()-time1));
		time1=System.currentTimeMillis();
		
		for(Integer[] k:keys){
			kd.remove(new int[]{k[0],k[1],k[2],k[3]});
		}
		System.out.println("KD Remove: "+(System.currentTimeMillis()-time1));
		time1=System.currentTimeMillis();
		for(Integer[] k:keys){
			tree.remove(k);
		}
		System.out.println("TreeMap Remove: "+(System.currentTimeMillis()-time1));
		time1=System.currentTimeMillis();
		
		HashSet<KDTree<Integer>.KDEntry> s=new HashSet<KDTree<Integer>.KDEntry>();
		for(Integer[] k:keys){
			s.add(kd.new KDEntry(new int[]{k[0],k[1],k[2],k[3]}, rng.nextInt(100)));
		}
		time1=System.currentTimeMillis();
		kd.addAll(s);
		System.out.println("KD Addall: "+(System.currentTimeMillis()-time1));
		System.out.println("KD Balance: "+kd.maxHeight(kd.root)+" "+kd.minHeight(kd.root));
		
		HashMap<Integer[], Integer> m=new HashMap<Integer[], Integer>();
		for(Integer[] k:keys){
			m.put(k, rng.nextInt(100));
		}
		time1=System.currentTimeMillis();
		tree.putAll(m);
		System.out.println("TreeMap Addall: "+(System.currentTimeMillis()-time1));
		
	}*/
}
