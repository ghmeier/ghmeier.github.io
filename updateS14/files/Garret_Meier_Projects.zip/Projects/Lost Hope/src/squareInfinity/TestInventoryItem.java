package squareInfinity;

import java.awt.Graphics;

public class TestInventoryItem extends InventoryItem{
	
	public TestInventoryItem(String name, int weight){
		super(name, weight);
	}

	@Override
	public void drawSelf(Graphics g, int x, int y) {
		g.drawImage(this.icon, x, y, null);
	}

}
