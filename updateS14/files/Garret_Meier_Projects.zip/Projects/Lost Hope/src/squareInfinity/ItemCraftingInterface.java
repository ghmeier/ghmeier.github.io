package squareInfinity;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Iterator;

import squareInfinity.gui.GUIActionListener;
import squareInfinity.gui.GUIAlignment;
import squareInfinity.gui.GUIButton;
import squareInfinity.gui.GUIElement;
import squareInfinity.gui.GUIElementController;

public class ItemCraftingInterface implements MouseListener,GUIActionListener{
	
	private int x;
	private int y;
	
	private int width;
	private int height;
	
	private int mouseX;
	private int mouseY;
	private int oldMouseX;
	private int oldMouseY;
	
	private boolean mouseDown;
	private boolean oldMouseDown;
	
	private LostHope controller;
	
	private String debugName = "iteminterface";
	
	private ItemCraftingHolder selectedHolder = null;
	
	private ArrayList<ItemCraftingHolder> itemsInUse;
	//private HashMap<Dimension, Boolean> allSnapPoints;
	
	SnapPointController snapPointController;
	
	////////
	
	private GUIButton craftButton;
	private GUIButton closeButton;
	
	public ItemCraftingInterface(int x, int y, LostHope controller){
		this.x = x;
		this.y = y;
		
		this.mouseX = -1;
		this.mouseY = -1;
		
		this.controller = controller;
		this.controller.addMouseListener(this);
		
		this.itemsInUse = new ArrayList<ItemCraftingHolder>();
		//this.allSnapPoints = new HashMap<Dimension, Boolean>();
		this.snapPointController = new SnapPointController();
		
		GUIElementController elementController = controller.elementController;
		GUIAlignment alignment = elementController.getCurrentAlignment();
		
		craftButton = new GUIButton(this.x + this.width - 30, this.y + this.height - 13, "Craft!");
		craftButton.addActionListener(this);
		closeButton = new GUIButton(this.x + this.width - 30, this.y + this.height + 2, "Close");
		closeButton.addActionListener(this);
		alignment.addElement(craftButton);
		alignment.addElement(closeButton);
		
		this.width = 300;
		this.height = 100;
		
		if(!LostHope.debugManager.hasProfile(debugName)){
			LostHope.debugManager.addProfile(debugName);
			LostHope.debugManager.setProfile(debugName, false); // TODO: debugging toggle
		}
	}
	
	public void close(){
		GUIElementController elementController = controller.elementController;	
		GUIAlignment alignment = elementController.getCurrentAlignment();
		
		alignment.removeElement(craftButton);
		alignment.removeElement(closeButton);
	}
	
	public int getX(){
		return this.x;
	}
	
	public int getY(){
		return this.y;
	}
	
	public void setMouseX(int mouseX){
		this.oldMouseX = this.mouseX;
		this.mouseX = mouseX;
	}
	
	public void setMouseY(int mouseY){
		this.oldMouseY = this.mouseY;
		this.mouseY = mouseY;
	}
	
	public void setMouseDown(boolean mouseDown){
		this.oldMouseDown = this.mouseDown;
		this.mouseDown = mouseDown;
	}
	
	public void addItemToUse(ItemCraftingHolder item){
		itemsInUse.add(item);
		
		PrimitiveItem pi = item.getItem();
		
		Iterator<Dimension> snapIterator = pi.getAllSnapPoints().iterator();
		
		while(snapIterator.hasNext()){
			Dimension currentDimension = snapIterator.next();
			
			//this.allSnapPoints.put(currentDimension, false);
			this.snapPointController.addSnapPoint(currentDimension, item, this);
			
			LostHope.debugManager.printDebug(debugName, "adding snap point");
		}
	}
	
	public void removeItemToUse(ItemCraftingHolder item){
		itemsInUse.remove(item);
		
		PrimitiveItem pi = item.getItem();
		
		Iterator<Dimension> snapIterator = pi.getAllSnapPoints().iterator();
		
		while(snapIterator.hasNext()){
			Dimension currentDimension = snapIterator.next();
			
			//this.allSnapPoints.remove(currentDimension);
			this.snapPointController.removeSnapPoint(currentDimension);
		}
	}
	
	public boolean mouseIsWithin(int x, int y, int endX, int endY){
		return mouseX >= x && mouseX <= endX && mouseY >= y && mouseY <= endY;
	}
	
	public boolean containsItem(InventoryItem item){
		for(int x=0; x<itemsInUse.size(); x++){
			if(itemsInUse.get(x).getItem() == item){
				return true;
			}
		}
		
		return false;
	}
	
	public int lockToGrid(int gridsize, int number){
		return (number / gridsize) * gridsize;
	}
	
	public void drawSelf(int mouseX, int mouseY, boolean mouseDown, Graphics g){
		this.setMouseX(mouseX);
		this.setMouseY(mouseY);
		this.setMouseDown(mouseDown);
		
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(this.x, this.y, this.width, this.height);
		g.setColor(Color.DARK_GRAY);
		g.drawRect(this.x + 1, this.y + 1, this.width - 3, this.height - 3);
		
		// draw all items
		
		for(int x=0; x<itemsInUse.size(); x++){
			ItemCraftingHolder currentHolder = itemsInUse.get(x);
			PrimitiveItem item = currentHolder.getItem();
			
			//currentHolder.setX(lockToGrid(16, currentHolder.getX()));
			//currentHolder.setY(lockToGrid(16, currentHolder.getY()));
			
			Image icon = item.getIcon();
			
			int drawX = currentHolder.getX() + this.x;
			int drawY = currentHolder.getY() + this.y;
			
			int width = currentHolder.getItem().getIcon().getWidth(null) * 3;
			int height = currentHolder.getItem().getIcon().getHeight(null) * 3;
			
			// manually drawing for scale
			//g.drawImage(icon, drawX, drawY, 16,32, null);
			g.drawImage(icon, drawX, drawY,width, height, null);
			
//			Iterator<Dimension> snapPoints = this.allSnapPoints.keySet().iterator();
//			
//			while(snapPoints.hasNext()){
//				Dimension currentPoint = snapPoints.next();
//				
//				boolean value = this.allSnapPoints.get(currentPoint);
//				
//				if(value){
//					g.setColor(Color.GREEN);
//				}else{
//					g.setColor(Color.RED);
//				}
//				int pointDrawX = (int) (currentPoint.getWidth() * 3) + drawX;
//				int pointDrawY = (int) (currentPoint.getHeight() * 3) + drawY;
//				
//				g.drawRect(pointDrawX, pointDrawY, 3, 3);
//			}
			
			this.snapPointController.drawSelf(g);
			
			if(mouseIsWithin(drawX, drawY,drawX + width, drawY + height)){
				g.setColor(Color.YELLOW);
				g.drawRect(drawX, drawY,width,height);
				g.setColor(Color.BLACK);
				g.drawString(item.getName(), drawX, drawY);
				
				if(this.mouseDown && oldMouseDown){
					//mouseWasOver = true;
					if(selectedHolder != null){
						int xDif = this.mouseX - this.oldMouseX;
						int yDif = this.mouseY - this.oldMouseY;
						
						selectedHolder.setX(selectedHolder.getX() + xDif);
						selectedHolder.setY(selectedHolder.getY() + yDif);
					}else{
						int xDif = this.mouseX - this.oldMouseX;
						int yDif = this.mouseY - this.oldMouseY;
						
						currentHolder.setX(currentHolder.getX() + xDif);
						currentHolder.setY(currentHolder.getY() + yDif);
						
						selectedHolder = currentHolder;
					}
				}
			}else{
				selectedHolder = null;
				updateSnapPoints();
				LostHope.debugManager.printDebug(debugName, "updating snap points");
				//mouseWasOver = false;
			}
		}
	}
	
	public void updateSnapPoints(){ // I realize its O(x^2), will fix later
		//Iterator<Dimension> snapPointsIterator = this.allSnapPoints.keySet().iterator();
		
		Iterator<SnapPointHolder> snapPointsIterator = this.snapPointController.iterator();
		
		while(snapPointsIterator.hasNext()){
			SnapPointHolder holder = snapPointsIterator.next();
			Dimension mainSnapPoint = holder.getDimension();
			
			//Iterator<Dimension> snapPointsIterator2 = this.allSnapPoints.keySet().iterator();
			
			Iterator<SnapPointHolder> snapPointsIterator2 = this.snapPointController.iterator();
			
			while(snapPointsIterator2.hasNext()){
				SnapPointHolder holder2 = snapPointsIterator2.next();
				
				Dimension secondarySnapPoint = holder2.getDimension();
				
				if(!(mainSnapPoint == secondarySnapPoint)){
					boolean valueToPut = false;
					if(/*mainSnapPoint.getWidth() == secondarySnapPoint.getWidth() && 
							mainSnapPoint.getHeight() == secondarySnapPoint.getHeight()*/
							holder.getTrueX() == holder2.getTrueX() && holder.getTrueY() == holder2.getTrueY()){
						valueToPut = true;
					}
					
					//this.allSnapPoints.put(mainSnapPoint, valueToPut);
					//this.allSnapPoints.put(secondarySnapPoint, valueToPut);
					
					holder.setGood(valueToPut);
					holder2.setGood(valueToPut);
				}
			}
		}
	}
	
	public void craft(){////////////////CRAAAAAAAAAAAAFFFFFFFFFTING SKILLS HHHHAACTIVATE
		Player currentPlayer = controller.getCurrentPlayer();
		
		int smallestX = 1000;
		int smallestY = 1000;
		int largestX = -1;
		int largestY = -1;
		Image largestImage = null;
		Dimension handRotationPoint = new Dimension(0,0);
		ItemCraftingHolder pointHolder = null;
		
		Iterator<ItemCraftingHolder> itemsIterator = itemsInUse.iterator();
		
		while(itemsIterator.hasNext()){
			ItemCraftingHolder currentHolder = itemsIterator.next();
			PrimitiveItem item = currentHolder.getItem();
			Image image = item.getIcon();
			
			if(currentHolder.getX() < smallestX){
				smallestX = currentHolder.getX();
			}else if(currentHolder.getX() > largestX){
				largestX = currentHolder.getX();
				largestImage = image;
				pointHolder = currentHolder;
			}
			if(currentHolder.getY() < smallestY){
				smallestY = currentHolder.getY();
			}else if(currentHolder.getY() > largestY){
				largestY = currentHolder.getY();
				largestImage = image;
				pointHolder = currentHolder;
			}
			
			if(item.getHandPoint() != null){
				handRotationPoint = item.getHandPoint();
			}
		}
		
		// now figure out true dimensions
		
		largestX = largestX + largestImage.getWidth(null);
		largestY = largestY + largestImage.getHeight(null);
		
		// make the image for the item
		
		int width = Math.abs(largestX - smallestX);
		int height = Math.abs(largestY - smallestY);
		
		LostHope.debugManager.printDebug(debugName, "hand x:" + (int)handRotationPoint.getWidth());
		LostHope.debugManager.printDebug(debugName, "hand y:" + (int)handRotationPoint.getHeight());
		
		int relativeX = (int)handRotationPoint.getWidth() + (pointHolder.getX() - smallestX);
		int relativeY = (int)handRotationPoint.getHeight() + (pointHolder.getY() - smallestY);
		
		handRotationPoint = new Dimension(relativeX / 3, relativeY / 3);
		
		BufferedImage finalImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics imageGraphics = finalImage.getGraphics();
		
		Iterator<ItemCraftingHolder> holdersIterator = itemsInUse.iterator();
		
		while(holdersIterator.hasNext()){
			ItemCraftingHolder currentHolder = holdersIterator.next();
			PrimitiveItem item = currentHolder.getItem();
			Image icon = item.getIcon();
			
			imageGraphics.drawImage(icon, (currentHolder.getX() - smallestX) / 3, (currentHolder.getY() - smallestY) / 3, null);
		}
		
		// woo now for items
		
		UseableItem finalItem = LostHope.factory.createUseableItem("Final Item", 1, 2, handRotationPoint, finalImage, true);
		currentPlayer.addItemToInventory(finalItem);
		
	}
	
	///////// MOUSE STUFF ///////////

	@Override
	public void mouseClicked(MouseEvent arg0) {
		setMouseX(arg0.getX());
		setMouseY(arg0.getY());
		
		this.mouseDown = true;
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO: this does nothing
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO this does nothing
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		setMouseX(arg0.getX());
		setMouseY(arg0.getY());
		
		this.mouseDown = true;
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		setMouseX(arg0.getX());
		setMouseY(arg0.getY());
		
		this.mouseDown = false;
	}

	@Override
	public void elementClicked(GUIElement element) {
		if(element == craftButton){
			this.craft(); // CRAAAAAAAAAAAAFFFFFFFTTTTTTTTTT MACARONI!!
		}else if(element == closeButton){
			controller.closeCraftingInterface();
		}
	}

}
