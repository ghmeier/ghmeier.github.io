package squareInfinity;

public class Tree extends Flora {
	protected byte type;
	
	public Tree(int x, int y, int width, int height, byte type) {
		super(x,y,width,height);
		this.type=type;
	}
	@Override
	public void grow(LostHope controller) {		
		// TODO Add stuff to look for growth and junk		
	}

}
