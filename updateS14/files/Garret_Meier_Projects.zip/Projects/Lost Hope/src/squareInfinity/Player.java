package squareInfinity;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
//import java.awt.Toolkit;

public class Player extends PhysicsObject{
	
	protected final static int TIME_TO_WAIT = 75;
	
	protected static BufferedImage[] frames;
	
	protected static BufferedImage[] attackingFrames;
	
	protected static HandLocation[] attackingHandLocations;
	
	//protected double turn = 0.0;
	protected double speedLimit = 10;
	protected double vSpeedLimit = 25;
	
	
	private boolean forward = true;
	protected boolean oldDirection = true;
	
	private boolean attacking = false;
	protected int attackingFramesCounter;
	
	
	protected byte quickReferenceWeapon = -1;
	protected boolean launch = true;
//	protected String weapon = "Pic/DefaultWeapons/LongBow.png";
//	protected String weaponL = "Pic/DefaultWeapons/LongBowL.png";
	
	protected double maxHealth = 100;
	protected int drawHealth = 100;
	protected int health = 100;
	
	protected int maxPowerPoints = 50;
	protected int drawPowerPoints = 50;
	protected int powerPoints = 50;
	
	protected int maxHunger = 100;
	protected int drawHunger = 100;
	protected int hunger = 100;
	protected long hungerOldTime;
	protected int hungerWait = 5000;
	
	protected int maxWater = 100;
	protected int drawWater = 100;
	protected int water = 100;
	
	public boolean hasSwung = false;
	protected int reach = 0;
	protected int damage = 10;
	
	protected long oldTime;
	protected int frameCounter;
	
	protected UseableItem equippedItem;
	protected BufferedImage playerImage;
	
	protected ArrayList<InventoryItem> inventory;
	
	protected boolean moving;
	
	protected int handX;
	protected int handY;
	
	protected int handXOffset;
	protected int handYOffset;

	public Player(double x, double y, int width, int height, double friction){
		super(x,y,width,height, friction);
		
		hungerOldTime = System.currentTimeMillis();
		
		try {
			this.playerImage = ImageIO.read(new File("Pic/Characters/Hero.png"));
		} catch (IOException e) {
			System.err.println("Could not load player image");
		}
		
		inventory = new ArrayList<InventoryItem>();
		
		this.oldTime = System.currentTimeMillis();
		
		if(frames == null){
			loadFrames();
		}
		
		this.frameCounter = 0;
		
		this.playerImage = frames[frameCounter];
		
	}
	
	public int getWater(){
		return this.water;
	}
	
	public void setWater(int water){
		this.water = water;
		
		if(this.water > this.maxWater){
			this.water = this.maxWater;
		}else if(this.water < 0){
			this.water = 0;
		}
	}
	
	public int getHealth(){
		return this.health;
	}
	
	public void setHealth(int amount){
		this.health = amount;
		
		if(this.health > this.maxHealth){
			this.health = (int) this.maxHealth;
		}
	}
	
	public void increaseHealth(int amount){
		this.setHealth(this.health + amount);
	}
	
	public int getHunger(){
		return this.hunger;
	}
	
	public void setHunger(int hunger){
		this.hunger = hunger;
		
		if(this.hunger > this.maxHunger){
			this.hunger = this.maxHunger;
		}
	}
	
	public int getMaxHunger(){
		return this.maxHunger;
	}
	
	public int getPowerPoints(){
		return this.powerPoints;
	}
	
	public boolean setPowerPoints(int amount){
		int oldPowerPoints = this.powerPoints;
		
		if(amount > this.maxPowerPoints){
			this.powerPoints = this.maxPowerPoints;
		}else{
			this.powerPoints = amount;
		}
		
		if(this.powerPoints < 0){
			this.powerPoints = oldPowerPoints;
			return false;
		}else{
			return true;
		}
	}
	
	public int getMaxPowerPoints(){
		return this.maxPowerPoints;
	}
	
	public void hasAttacked(){
		this.attacking = true;
		this.attackingFramesCounter = 0;
	}
	
	public void setForward(boolean forward){
		this.oldDirection = this.forward;
		
		if(forward){
			this.handXOffset = 10;
			this.handYOffset = 23;
		}else{
			this.handXOffset = 5;
			this.handYOffset = 23;
		}
		
		this.forward = forward;
	}
	
	public int getHandXOffset(){
		return this.handXOffset;
	}
	
	public int getHandYOffset(){
		return this.handYOffset;
	}
	
	public boolean isForward(){
		return this.forward;
	}
	
	public boolean getOldDirection(){
		return this.oldDirection;
	}
	
	public static void loadFrames(){
		frames = new BufferedImage[2];
		
		attackingFrames = new BufferedImage[2];
		
		try {
			frames[0] = ImageIO.read(new File("Pic/Characters/CharacterAnimated/frame0.png"));
			frames[1] = ImageIO.read(new File("Pic/Characters/CharacterAnimated/frame1.png"));
			
			attackingFrames[0] = ImageIO.read(new File("Pic/Characters/CharacterAnimated/handup.png"));
			attackingFrames[1] = ImageIO.read(new File("Pic/Characters/CharacterAnimated/handdown.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// setup hand stuff
		
		attackingHandLocations = new HandLocation[2];
		
		attackingHandLocations[0] = new HandLocation(4,17, 14,17);
		attackingHandLocations[1] = new HandLocation(8,22, 14,22);
	}
	
	public void setMoving(boolean moving){
		this.moving = moving;
	}
	
	public void setHandX(int handX){
		this.handX = handX;
	}
	
	public int getHandX(){
		return this.handX;
	}
	
	public void setHandY(int handY){
		this.handY = handY;
	}
	
	public int getHandY(){
		return this.handY;
	}
	
	public ArrayList<InventoryItem> getInventory(){
		return this.inventory;
	}
	
	public UseableItem getEquippedItem(){
		return this.equippedItem;
	}
	
	public void setEquippedItem(UseableItem item){
		this.equippedItem = item;
		this.damage = this.equippedItem.getDamage();
	}
	
	private void dealWithTiming(){
		if(!attacking){
			if(moving){
				long newTime = System.currentTimeMillis();
				
				if(newTime - oldTime >= TIME_TO_WAIT){
					oldTime = System.currentTimeMillis();
					
					frameCounter = frameCounter + 1;
					
					if(!(frameCounter < frames.length)){
						frameCounter = 0;
					}
					
					this.playerImage = frames[frameCounter];
				}
			}else{
				
			}
		}else{
			if(attackingFramesCounter == 0){
				oldTime = System.currentTimeMillis();
				
				this.playerImage = attackingFrames[attackingFramesCounter];
				
				HandLocation handLocation = attackingHandLocations[0];
				
				if(forward){
					handXOffset = (int)handLocation.getRightX();
					handYOffset = handLocation.getRightY();
				}else{
					handXOffset = (int)handLocation.getLeftX();
					handYOffset = handLocation.getLeftY();
				}
				
				attackingFramesCounter = attackingFramesCounter + 1;
			}else if(attackingFramesCounter < attackingFrames.length){
				long newTime = System.currentTimeMillis();
				
				if(newTime - oldTime >= TIME_TO_WAIT){
					oldTime = System.currentTimeMillis();
					
					this.playerImage = attackingFrames[attackingFramesCounter];
					
					HandLocation handLocation = attackingHandLocations[0];
					
					if(forward){
						handXOffset = (int)handLocation.getRightX();
						handYOffset = handLocation.getRightY();
					}else{
						handXOffset = (int)handLocation.getLeftX();
						handYOffset = handLocation.getLeftY();
					}
					
					attackingFramesCounter = attackingFramesCounter + 1;
				}
			}else{
				this.frameCounter = 0;
				
				this.playerImage = frames[frameCounter];
				
				if(forward){
					this.handXOffset = 10;
					this.handYOffset = 23;
				}else{
					this.handXOffset = 5;
					this.handYOffset = 23;
				}
				
				this.attacking = false;
			}
		}
	}

	public void drawSelf(Graphics g){
		dealWithTiming();
		
		if(this.forward){
			g.drawImage(playerImage, (int)x, (int)y, null);
			
			//g.drawImage(Toolkit.getDefaultToolkit().getImage(weapon), (int)x-15, (int)y-17, null);

		}else{
			//g.drawImage(Toolkit.getDefaultToolkit().getImage("Pic/Characters/HeroL.png"), (int)x-15, (int)y-15, null);
			
			
			// FLIP THE PLAYER IMAGE
			AffineTransform at = AffineTransform.getScaleInstance(-1, 1);
			at.translate(-playerImage.getWidth(), 0);
			AffineTransformOp op = new AffineTransformOp(at, AffineTransformOp.TYPE_NEAREST_NEIGHBOR);
			
			BufferedImage image = op.filter(playerImage, null);
			
			g.drawImage(image, (int) x, (int) y, null);
			
			//g.drawImage(Toolkit.getDefaultToolkit().getImage(weaponL), (int)x-15, (int)y-17, null);

		}
		
		drawStatusBars(x, y, g);
		dealWithCalcs();
		
		//movementPhysics();
		
		if(this.xSpeed > this.speedLimit){
			this.xSpeed = this.speedLimit;
		}else if(this.xSpeed < -this.speedLimit){
			this.xSpeed = -this.speedLimit;
		}
		
		if(this.ySpeed > vSpeedLimit){
			this.ySpeed = vSpeedLimit;
		}else if(this.ySpeed < -vSpeedLimit){
			this.ySpeed = -vSpeedLimit;
		}

	}
	
	public void drawStatusBars(double drawX, double drawY, Graphics g){
		drawX = drawX - 10;
		drawY = drawY - 15;
		
		g.setColor(Color.BLACK);
		g.drawRect((int) drawX - 1, (int) drawY - 1, 33,3);
		g.setColor(new Color(200,0,0));
		g.fillRect((int)drawX, (int)drawY, 32, 2);
		g.setColor(Color.green);
		g.fillRect((int)drawX, (int)drawY, (int)(32 * (drawHealth/maxHealth)),2);
		
		drawY = drawY + 5;
		
		g.setColor(Color.BLACK);
		g.drawRect((int) drawX - 1, (int) drawY - 1, 33,3);
		g.setColor(new Color(100,100,100));
		g.fillRect((int) drawX, (int) drawY, 32, 2);
		g.setColor(Color.CYAN);
		g.fillRect((int) drawX, (int) drawY, (int)(32 * ((double)drawPowerPoints/(double)maxPowerPoints)),2);
		
		drawY = drawY + 5;
		
		g.setColor(Color.BLACK);
		g.drawRect((int) drawX - 1, (int) drawY - 1, 33,3);
		g.setColor(new Color(100,100,100));
		g.fillRect((int) drawX, (int) drawY, 32, 2);
		g.setColor(new Color(255,128,0));
		g.fillRect((int) drawX, (int) drawY, (int)(32 * ((double)drawHunger/(double)maxHunger)),2);
		
		drawY = drawY + 5;
		
		g.setColor(Color.BLACK);
		g.drawRect((int) drawX - 1, (int) drawY - 1, 33,3);
		g.setColor(new Color(100,100,100));
		g.fillRect((int) drawX, (int) drawY, 32, 2);
		g.setColor(Color.BLUE);
		g.fillRect((int) drawX, (int) drawY, (int)(32 * ((double)drawWater/(double)maxWater)),2);
	}
	
	public void dealWithCalcs(){
		if(drawPowerPoints > powerPoints){
			drawPowerPoints = drawPowerPoints - 1;
		}else if(drawPowerPoints < powerPoints){
			drawPowerPoints = drawPowerPoints + 1;
		}
		if(drawHealth > health){
			drawHealth = drawHealth - 1;
		}else if(drawHealth < health){
			drawHealth = drawHealth + 1;
		}
		if(drawHunger > hunger){
			drawHunger = drawHunger - 1;
		}else if(drawHunger < hunger){
			drawHunger = drawHunger + 1;
		}
		if(drawWater > water){
			drawWater = drawWater - 1;
		}else if(drawWater < water){
			drawWater = drawWater + 1;
		}
		
		long hungerNewTime = System.currentTimeMillis();
		if(hungerNewTime - hungerOldTime >= hungerWait){
			hungerOldTime = System.currentTimeMillis();
			
			this.hunger = this.hunger - 4;
			this.water = this.water - 2;
			
			if(this.hunger < 0){
				this.hunger = 0;
			}
			
			if(this.water < 0){
				this.water = 0;
			}
		}
	}
	
	public void changeWeapon(byte wSign){

//		if(wSign == Weapons.LONGBOW){
//			this.weapon = "Pic/DefaultWeapons/LongBow.png";
//			this.weaponL = "Pic/DefaultWeapons/LongBowL.png";
//			this.quickReferenceWeapon = Weapons.LONGBOW;
//			this.launch = true;
//			this.damage = 5;
//			this.reach = 0;
//		}else if(wSign == Weapons.IRONSWORD){
//			this.weapon = "Pic/DefaultWeapons/IronSword.png";
//			this.weaponL = "Pic/DefaultWeapons/IronSwordL.png";
//			this.quickReferenceWeapon = Weapons.IRONSWORD;
//			this.launch = false;
//			this.damage = 5;
//			this.reach = 40;
//
//		}else if(wSign == Weapons.AXE){
//			this.weapon = "Pic/DefaultWeapons/Axe.png";
//			this.weaponL = "Pic/DefaultWeapons/AxeL.png";
//			this.quickReferenceWeapon = Weapons.AXE;
//			this.launch = false;
//			this.damage = 15;
//			this.reach = 50;
//		}else if(wSign == Weapons.WOODSTAFF){
//			this.weapon = "Pic/DefaultWeapons/WoodenStaff.png";
//			this.weaponL = "Pic/DefaultWeapons/WoodenStaffL.png";
//			this.quickReferenceWeapon = Weapons.WOODSTAFF;
//			this.launch = true;
//			this.damage = 5;
//			this.reach = 30;
//		}
	}
	
	public int getDamage(){
		return this.damage;
	}
	

	//        MOVED INTO Projectile.java now does nothing         \\
	/*public void drawProjectile(Graphics g, Player currentPlayer, int wPivotPoint){
		if(currentPlayer.launch){
			//System.out.println("Shooting Arrow"); //arrow stopped working for some reason :(
			//drawing of an arrow
			g.setColor(new Color(100,50,50));
			g.fillRect((int)x, (int)y, width, height);
			g.setColor(Color.gray);
			g.fillRect((int)x + width , (int)y , 5, 2);
			g.setColor(Color.LIGHT_GRAY);
			g.fillRect((int) x - 3, (int) y, 2, 2);
			//

			movementPhysics();
		}else{
			//rotates weapon images that are not projectiles when attacking

			Graphics2D g2d = (Graphics2D)g;
			if(currentPlayer.forward){
				//System.out.println("rotating " + turn); 
				g2d.rotate(turn,wPivotPoint, currentPlayer.y);  // Rotate the image by turn radians.
				turn += .5;
				g2d.drawImage(Toolkit.getDefaultToolkit().getImage(currentPlayer.weapon), (int)currentPlayer.x-15, (int)currentPlayer.y-17, null);
			}else{
				//System.out.println("rotating " + turn); 
				g2d.rotate(turn,wPivotPoint, currentPlayer.y);  // Rotate the image by turn radians.
				turn -= .5;
				g2d.drawImage(Toolkit.getDefaultToolkit().getImage(currentPlayer.weaponL), (int)currentPlayer.x-15, (int)currentPlayer.y-17, null);
			}
		}
	}*/
	public void movementPhysics(){
		this.x = this.x + this.xSpeed;
		this.y = this.y + this.ySpeed;

		xSpeed = xSpeed * LostHope.AIRDRAG;
		/*if(isTouchingGround()){ //check to see if on the ground 
			xSpeed = xSpeed * LostHope.FRICTION;
		}*/

		if(Math.abs(xSpeed) < .01){
			xSpeed = 0;
		}
		
		if(Math.abs(ySpeed) < .01){
			ySpeed = 0;
		}

		if(xSpeed > speedLimit){
			xSpeed = speedLimit;
		}
		if(xSpeed < speedLimit * -1){
			xSpeed = speedLimit * -1;
		}
	}
	
	public void hurt(int amount){
		this.health = this.health - amount;

		if(this.health <= 0){
			//System.out.println("YOU DIED!");
			this.health=(int) maxHealth;
			//System.exit(0);
		}
	}

	public void checkWeaponCollision(Location location){
		// first rule out all enemies that are too far away

		//Iterator<NPC> targetsIterator = location.getNPCs().iterator();
		
		ArrayList<NPC> npcs = location.getNPCs();

		//System.out.println("reach: " + equippedItem.getReach());
		
		for(int x=0; x<npcs.size(); x++){
			NPC tempNPC = npcs.get(x);

			double distance = PhysicsObject.getDistanceBetweenTwoPoints(this.oldX, this.oldY, tempNPC.getX(), tempNPC.getY());

			
			//System.out.println("distance:" + distance);
			
			if(distance <= equippedItem.getReach()){ // for now, will change to the actual length of pic at some point
				
				//System.err.println("Weapons have collided");
				
				if(forward){
					if(this.getOldX() < tempNPC.getX()){
						tempNPC.hurt(this.damage,!forward);
					}

				}else{
					if(this.getOldX() < tempNPC.getX()){
						tempNPC.hurt(this.damage,!forward);
					}				
				}
				
				tempNPC.setLastAttacker(this);
			}
		}
	}
	
	public void addItemToInventory(InventoryItem item){
		if(item instanceof InventoryPeicesHolder){
			InventoryPeicesHolder temp = (InventoryPeicesHolder) item;
			
			InventoryPeicesHolder temp2 = getHolderFromInventory(temp.getType());
			
			if(temp2 != null){
				temp2.setCount(temp2.getCount() + temp.getCount());
			}else{
				inventory.add(temp);
			}
			
		}else{
			inventory.add(item);
		}
	}
	
	public InventoryPeicesHolder getHolderFromInventory(byte type){
		for(int x=0; x<inventory.size(); x++){
			if(inventory.get(x) instanceof InventoryPeicesHolder){
				InventoryPeicesHolder temp = (InventoryPeicesHolder) inventory.get(x);
				
				if(temp.getType() == type){
					return temp;
				}
			}
		}
		
		return null;
	}
	
	public void removeItemFromInventory(InventoryItem item){
		this.inventory.remove(item);
	}

	@Override
	public void setPower(int power) {
		// TODO set power does nothing
	}

	@Override
	public void magicExplode(LostHope controller, int power) {
		// TODO magic explod edoes nothing
	}

	@Override
	public MagicPrimitive createCopyOfSelf() {
		// TODO create copy returns null
		return null;
	}

}