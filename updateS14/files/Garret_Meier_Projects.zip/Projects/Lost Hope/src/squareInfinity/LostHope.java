package squareInfinity;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingWorker.StateValue;

import squareInfinity.gui.GUIActionListener;
import squareInfinity.gui.GUIAlignment;
import squareInfinity.gui.GUIButton;
import squareInfinity.gui.GUIElement;
import squareInfinity.gui.GUIElementController;
import squareInfinity.kdtree.KDTree;

@SuppressWarnings("serial")
public class LostHope extends JPanel implements MouseListener, MouseMotionListener, 
KeyListener, ComponentListener, GUIActionListener{

	class Struggle{
		public final boolean WAR = true;//war, what is it good for?
	} 
	private static final String VERSION = "pre-alpha v0.43101";
	public static final int BLOCKSIDE = 16;
	public static final int SEED = 9001;
	public static final int WIDTH = 9216;//2048;//9216;
	
	private SettingsProfile profile;
	
	public static DebugManager debugManager = new DebugManager();
	
	private JFrame mainFrame;
	
	public GUIElementController elementController;
	
	private int frameWidth;// the window's size
	private int frameHeight;
	
	protected double gravity = 0.08;
	//private Graphics g;
	public static final double AIRDRAG = 0.999;
	//public static final double FRICTION = 0.9;
	
	private int airTemperature = 0;

	// stuff for particles getting attracted to objects
	private final double RADIUS_OF_EFFECT = 100.0;
	private final boolean particleSphere=false;
	
	// inventory item stuff...

	public InventoryItem selectedInventoryItem;
	public InventoryItem itemMouseIsOver;

	// location weird stuff
	
	public double drawXModifier = 0;
	public double drawYModifier = 0;
	
	// frame count ////
	
	
	private int currentFrameCount = 0;
	private int averageFrameCount = 0;
	private long oldTime = 0;
	
	public FloraController plantController;
	
	////MINING
	
	private int miningStartX;
	private int miningStopX;
	private int miningStartY;
	private int miningStopY;
	
	////////

	private int mouseX;
	private int mouseY;

	private boolean isInventoryOpen = false;

	private PrimitiveCraftingInterface craftingInterface = null;
	private ItemCraftingInterface itemCraftingInterface = null;
	
	private MagicEditor currentMagicEditor = null;

	public boolean attacking = false;
	public boolean firstPress = true;
	public int wPivotPoint;

	private boolean running=false;
	private RunnerThread runner;

	//For dealing with key events
	private boolean[] keys=new boolean[525];//524 is the highest keycode I've seen, it's the windows key
	private long[] keyReleased=new long[525];
	private char[] onePress={'V','I','C','Q','M'}; //Keys that should be single press/immediate release, not held down
	private boolean mouseDown=false;
	
	//private NPC skelly;

	public static GameFactory factory; // ONLY ONE TO RULE THEM ALL
	public static MagicController magicController;
	
	private WorldGenerator worldGenerator;
	private Location[] locations=new Location[4];
	public Location currentLocation;
	private int currentLocationIndex=0;
	private Player currentPlayer;
	private double currentRotation;

	private boolean levelDesignerMode;
	

	private boolean machineGun=false;

	//private ArrayList<GameButton> buttons = new ArrayList<GameButton>();
	private boolean useImage;
	private Color backgroundColor;
	
	private BufferedImage screenBuffer;
	int done=0;
	public LostHope(int width, int height, boolean levelDesignerMode, boolean createStandaloneWindow, 
			JFrame mainFrame, SettingsProfile profile){
		this.frameWidth = width;
		this.frameHeight = height;
		
		this.profile=profile;
		
		plantController = new FloraController(1000);

		try {
			ObjectData.initImages();
			NPC.initImages();//I think this will work to initialize the NPC images....
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		
		this.backgroundColor = new Color(0,0,0);
		useImage=true;
		
		elementController = new GUIElementController(width, height);
		
		GUIButton button = new GUIButton(650,15, "Exit Game");
		button.addActionListener(this);
		//GUINumberInputBox inputBox = new GUINumberInputBox(650, 50, 20, 20, this);
		
		GUIAlignment overlayAlignment = new GUIAlignment(0,0,width,height);
		
		overlayAlignment.addElement(button);
		//overlayAlignment.addElement(inputBox);
		
		elementController.setCurrentAlignment(overlayAlignment);
		
		magicController = new MagicController(this);

		//GameObjectInfo.loadGameObjectInfo("Information/blockConverter.txt", "Information/conversionTable.txt");

		TileData.data.add(new TileData(ObjectData.STONE, Color.GRAY));



		this.levelDesignerMode = levelDesignerMode;

		//locations = new ArrayList<Location>();

		if(this.levelDesignerMode){ // setup level design GUI
			setupLevelDesignGUI();
		}else{
			if(createStandaloneWindow){
				setupGameGUI();
			}
		}
		
		//setupGameGUI();
		
		if(mainFrame != null){
			this.mainFrame = mainFrame;
		}else{
			//setupGameGUI();
		}
		
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		this.addKeyListener(this);
		this.mainFrame.addKeyListener(this);
		this.mainFrame.addMouseListener(this);
		this.mainFrame.addKeyListener(this);
		
		this.requestFocus();
		
		//currentPlayer = new Player(120,0,21,27, .75);
		
		currentPlayer = new Player(120, 0, 16, 32, .75);
		
		currentPlayer.addItemToInventory(new Consumable(10, Consumable.HEALTH_POTION));
		currentPlayer.addItemToInventory(new Consumable(10, Consumable.FOOD));
		currentPlayer.addItemToInventory(new Consumable(10, Consumable.MAGIC_POTION));
		currentPlayer.addItemToInventory(new Consumable(10, Consumable.WATER));
		
		BufferedImage image = null;
		
		image = GameFactory.getOptimizedImage("Pic/Logo/Splash Screen.jpg");
			
		Graphics g = this.getGraphics();
		
		if(g!=null){
			g.drawImage(image, 0, 0, null);
		}
		
		factory = new GameFactory(this); // USE THIS TO CREATE OBJECTS, IT WILL MAKE YOUR LIFE EASIER

		//currentLocation = new Location(700,1400,"Fred", "fred", this);
		NPC.initBaseStats();
		//GameFactory.loadingImage = GameFactory.getOptimizedImage("Pic/Logo/LoadingScreen_Small.png");
		worldGenerator = new WorldGenerator(WIDTH, this);
		worldGenerator.generateWorld();//************************************This will generate a nice world automatically :)
		worldGenerator.addPropertyChangeListener(new PropertyChangeListener(){
			public void propertyChange(PropertyChangeEvent evt) {
				if(evt.getNewValue()==StateValue.DONE){
					System.out.println("Starting game");
					start();
				}
			}
		});
		//Don't add any more code dealing with Location or GameFactory in the constructor below this point - 
		//it will execute while the world is generating, which can lead to inconsistent thread states.
		//Do anything that needs to happen after generating in start() instead.
	}
	
	public void playMusic(String filename){
		Sequence musicSequence = null;
		
		try {
			musicSequence = MidiSystem.getSequence(new File("Music/" + filename));
		} catch (InvalidMidiDataException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			Sequencer musicPlayer = MidiSystem.getSequencer();
			musicPlayer.open();
			
			musicPlayer.setSequence(musicSequence);
			musicPlayer.setLoopStartPoint(0);
			musicPlayer.setLoopEndPoint(-1);
			musicPlayer.setLoopCount(Sequencer.LOOP_CONTINUOUSLY);
			
			musicPlayer.start();
			
		} catch (MidiUnavailableException e) {
			e.printStackTrace();
		} catch (InvalidMidiDataException e) {
			e.printStackTrace();
		}
	}
	
	public void setBackgroundPic(BufferedImage image){
		GameFactory.backgroundImage = image;
		this.useImage = true;
	}
	
	public void setBackgroundPic(Color color){
		this.useImage = false;
		this.backgroundColor = color;
	}

	//TODO////////////////////SETUP STUFF/////////////////////////////
	
	public void start(){
		mainFrame.setSize(801,600);
		mainFrame.setSize(800,600);
		locations = worldGenerator.getLocations();
		currentLocation=locations[0];
		factory.resetLocationToEdit();
		for(Location l:locations) l.currentWeather = new ClearWeather(this);
		initPlayer();
		//currentLocation.saveAndUnloadAll();
		//currentLocation.loadAll();
		//currentLocation.dealWithFileIO((int)currentPlayer.getX(), (int)currentPlayer.getY());

		//currentLocation.saveAndUnloadAll();
		//currentLocation.loadAll();
		if(profile.isMusicOn()){
			playMusic("Everyday Life.mid");
		}
		runner=new RunnerThread(this);
		runner.start();
	}
	
	private void initPlayer(){
		currentLocation.addPhysicsObject(currentPlayer);

		for(int x=0; x<100; x++){
			currentPlayer.addItemToInventory(new InventoryPeicesHolder("Clay", ObjectData.CLAY, 1));
		}

		UseableItem tempItem = factory.createUseableItem("Iron Sword", 1,5, new Dimension(2,16), 
				GameFactory.getOptimizedImage("Pic/DefaultWeapons/BetterIronSword.png"), true);

		UseableItem tempAxeItem = factory.createUseableItem("Axe!", 1, 10, new Dimension(4,18),
				GameFactory.getOptimizedImage("Pic/DefaultWeapons/BetterAxe.png"), true);

		UseableItem tempStaff = factory.createUseableItem("Wooden Staff", 1,50, new Dimension(2,15), 
				GameFactory.getOptimizedImage("Pic/DefaultWeapons/BetterWoodenStaff.png"), true);
		
		
		UseableItem tempBow = factory.createUseableItem("Wooden Bow", 1,3, new Dimension(30,16), 
				GameFactory.getOptimizedImage("Pic/DefaultWeapons/LongBow.png"), false);

		if(tempItem != null){
			tempItem.setReach(40);

			tempItem.setCanMine(true);
			
			currentPlayer.addItemToInventory(tempItem);
			currentPlayer.setEquippedItem(tempItem);
			
		}

		if(tempAxeItem != null){
			tempAxeItem.setReach(40);

			currentPlayer.addItemToInventory(tempAxeItem);
		}

		if(tempStaff != null){
			tempStaff.setReach(20);

			tempStaff.setProjectile(new Projectile(Projectile.FIREBALL, 15, 5, 5));
			tempStaff.setProjectileSpawnPoint(new Dimension(0,-7));

			currentPlayer.addItemToInventory(tempStaff);
		}
		if(tempBow != null){
			tempBow.setReach(20);

			tempBow.setProjectile(new Projectile(Projectile.ARROW, 15, 15, 5));
			tempBow.setProjectileSpawnPoint(new Dimension(0,-7));

			currentPlayer.addItemToInventory(tempBow);
		}
		
	}

	private void setupGameGUI(){
		mainFrame = new JFrame("Lost Hope " + VERSION + " is loading, please wait");

		mainFrame.getContentPane().add(this);

		mainFrame.addKeyListener(this);

		mainFrame.setSize(frameWidth, frameHeight);
		mainFrame.setLocationRelativeTo(null);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.setVisible(true);
	}

	private void setupLevelDesignGUI(){
		JFrame mainWindow = new JFrame("Lost Hope Level Designer");

		JPanel centerPanel = new JPanel();

		JButton createNewAreaButton = new JButton("Create New Area");
		createNewAreaButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// what to do if the user clicks "Create New Area"

				//MapEditor fred = new MapEditor(MapEditor.NEW_AREA);

			}
		});
		JButton editExistingAreaButton = new JButton("Modify Existing Area");

		centerPanel.add(createNewAreaButton);
		centerPanel.add(editExistingAreaButton);

		Container windowContainer = mainWindow.getContentPane();

		windowContainer.add(BorderLayout.CENTER, centerPanel);

		mainWindow.setSize(this.frameWidth, this.frameHeight);
		mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainWindow.setLocationRelativeTo(null); // ironically places the window in center of screen
		mainWindow.setVisible(true);
	}


	
	//TODO/////////////////////////FRAME UPDATING AND DRAWING///////////////////////////////
	
	@Override 
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.drawImage(screenBuffer, 0,0,null);
	}

	public void showLoading(int percent, String message){
		BufferedImage buffer=GameFactory.getBufferedImage(frameWidth, frameHeight);
		Graphics g=buffer.getGraphics();
		
		g.setColor(Color.BLACK);
		g.fillRect(0,0,frameWidth,frameHeight);
		g.setColor(Color.WHITE);
		int trueWidth = (int)(650 * (((double)percent) / 100.0));
		g.fillRect(50, 0, trueWidth, frameHeight);
		g.drawImage(GameFactory.loadingImage,0,0,frameWidth, frameHeight, null);
		
		FontMetrics fm = g.getFontMetrics();
		int stringWidth = fm.stringWidth(message);
		g.drawString(message, frameWidth/2 - (stringWidth / 2) - 40, frameHeight/2+100);
		mainFrame.setTitle(message+", "+ percent + "% complete");
		mainFrame.getGraphics().drawImage(buffer, 0, 0, null);
	//	mainFrame.repaint();
	}
	
	private void drawGame(Graphics2D g){
		frameWidth = getWidth();
		frameHeight = getHeight();
		//currentLocation.dealWithFileIO((int)currentPlayer.getX(), (int)currentPlayer.getY());
		if(useImage){
			if(GameFactory.backgroundImage.getWidth()!=frameWidth||GameFactory.backgroundImage.getHeight()!=frameHeight)
				GameFactory.backgroundImage=GameFactory.getOptimizedImage(frameWidth, frameHeight, "Pic/Misc/Background.png");
			g.drawImage(GameFactory.backgroundImage, 0, 0, null);
		}else{
			g.setColor(this.backgroundColor);
			g.fillRect(0,0,frameWidth,frameHeight);
		}
		updateOffset();
		double tempX=drawXModifier;
		double tempY=drawYModifier;
		double playerX=currentPlayer.getX()+tempX, playerY=currentPlayer.getY()+tempY;
		
		currentRotation-=currentRotation<0?Math.max(-.05, currentRotation*.05):
			Math.min(.05, currentRotation*.05);
		if(Math.abs(currentRotation)<.005) currentRotation=0;
		currentRotation=((currentRotation+Math.PI)%(Math.PI*2))-Math.PI;
		if(currentRotation!=0) g.rotate(currentRotation, playerX+currentPlayer.getWidth()/2, 
				playerY+currentPlayer.getHeight()/2);
		
		for(currentLocationIndex=0; currentLocationIndex<4; currentLocationIndex++){
			int i=currentLocationIndex;
			currentLocation=locations[i];
			factory.resetLocationToEdit();
			int startX=0, startY=0;
			if(i==1){
				drawXModifier=tempY+currentLocation.height/4;
				drawYModifier=-tempX-currentLocation.width-currentLocation.height/4;
				startY -= frameWidth;
			}else if(i==2){
				drawXModifier=-tempX-currentLocation.width;
				drawYModifier=-tempY-currentLocation.height*2;
				startX -= frameWidth;
				startY -= frameHeight;
			}else if(i==3){
				drawXModifier=-tempY-currentLocation.height*7/4;
				drawYModifier=tempX-currentLocation.height/4;
				startX -= frameHeight;
			}
			startX-=drawXModifier;
			startY-=drawYModifier;
			int endX=startX+(i%2==0?frameWidth:frameHeight);
			int endY=startY+(i%2==0?frameHeight:frameWidth);
			if(currentRotation!=0){
				startX-=(i%2==0?frameWidth:frameHeight);
				endX+=(i%2==0?frameWidth:frameHeight);
				startY-=(i%2==0?frameHeight:frameWidth);
				endY+=(i%2==0?frameHeight:frameWidth);
			}
			Collection<GameObject> objectsToDraw = currentLocation.getObjectsBetween(startX, startY, endX, endY);
			for(GameObject o:objectsToDraw) o.drawSelf(g, (int)(drawXModifier+.5d), (int)(drawYModifier+.5d));
			drawPhysicsObjects(currentLocation.getPhysicsObjects(), g, startX, startY, endX, endY);
			updateLiquidBlocks(currentLocation.getLiquidBlocks());
			currentLocation.currentWeather.drawWeather(g, (int)(drawXModifier+.5d), (int)(drawYModifier+.5d), this);
			//The player has switched sides, redo this frame to avoid flicker
			if(i!=currentLocationIndex){
				tempX=playerX-currentPlayer.getX(); 
				tempY=playerY-currentPlayer.getY();
				drawXModifier=tempX;
				drawYModifier=tempY;
				currentLocationIndex=-1;
				g.setTransform(new AffineTransform());
				if(useImage){
					if(GameFactory.backgroundImage.getWidth()!=frameWidth||GameFactory.backgroundImage.getHeight()!=frameHeight)
						GameFactory.backgroundImage=GameFactory.getOptimizedImage(frameWidth, frameHeight, "Pic/Misc/Background.png");
					g.drawImage(GameFactory.backgroundImage, 0, 0, null);
				}else{
					g.setColor(this.backgroundColor);
					g.fillRect(0,0,frameWidth,frameHeight);
				}
				playerX=currentPlayer.getX()+tempX;
				playerY=currentPlayer.getY()+tempY;
				g.rotate(currentRotation, playerX+currentPlayer.getWidth()/2, playerY+currentPlayer.getHeight()/2);
				g.rotate(-Math.PI/2);
			}
			g.rotate(Math.PI/2);
		}
		g.rotate(-currentRotation, playerX+currentPlayer.getWidth()/2, playerY+currentPlayer.getHeight()/2);
		
		currentLocation=locations[0];
		currentLocationIndex=0;
		factory.resetLocationToEdit();
		drawXModifier=tempX;
		drawYModifier=tempY;

		if(currentPlayer!=null) drawPlayer(g);
		
		plantController.dealWithPlants(this);

		if(this.craftingInterface != null){ // dealing with crafting
			craftingInterface.drawSelf(g, mouseX, mouseY);
		}
		if(this.itemCraftingInterface != null) this.itemCraftingInterface.drawSelf(mouseX, mouseY, mouseDown, g);

		if(this.isInventoryOpen){
			this.drawInventory(10, 10, g);
		}
		
		elementController.drawElements(g);
		
		//FPS Calculation
		long currentTime = System.currentTimeMillis();
		currentFrameCount++;
		if(currentTime >= oldTime + 1000){
			averageFrameCount = currentFrameCount;
			currentFrameCount = 0;
			mainFrame.setTitle(VERSION + "  FPS: " + (int)(averageFrameCount*(1000d/(currentTime-oldTime))));
			oldTime = System.currentTimeMillis();
		}
	}
	
	
	private void drawPhysicsObjects(Collection<PhysicsObject> objects, Graphics2D g, int startX, int startY, int endX, int endY){
		KDTree<PhysicsObject> copy=new KDTree<PhysicsObject>(4,true);
		for(PhysicsObject o:objects) copy.add(new int[]{(int) o.x, (int) o.y, 
				(int) (o.x+o.width), (int) (o.y+o.height)}, o);
		Iterator<PhysicsObject> iterator=copy.iterator();
		while(iterator.hasNext()){
			PhysicsObject tempPObject=iterator.next();
			if(tempPObject==null) continue;
			
			checkLocationBounds(tempPObject);

			if(Math.abs(tempPObject.getXSpeed()) < gravity && Math.abs(tempPObject.getYSpeed()) < gravity && tempPObject.isTouchingGround()){
				tempPObject.setXSpeed(0);
				tempPObject.setYSpeed(0);
				tempPObject.stopped=true;
			}else tempPObject.stopped=false;

			if(!tempPObject.isHeld){
				tempPObject.increaseYSpeed(gravity);

				tempPObject.increaseY(tempPObject.getYSpeed());
				tempPObject.increaseX(tempPObject.getXSpeed());
			}

			tempPObject.setIsTouchingGround(false);
			
			if(tempPObject instanceof Projectile){
				Projectile fred = (Projectile) tempPObject;
				fred.checkWeaponCollision(currentLocation);
			}else if(tempPObject instanceof Particle){
				Particle particle = (Particle) tempPObject;
				if(particle.x >= currentPlayer.getX() && particle.y >= currentPlayer.getY() &&
						particle.x + particle.width <= currentPlayer.getX() + currentPlayer.getWidth() &&
						particle.y + particle.height <= currentPlayer.getY() + currentPlayer.getHeight()){
					
					factory.addPeiceToInventory(currentPlayer, particle);
					factory.destroyParticle(particle);
				}else if(particle.stopped){
					factory.convertParticleToStaticObject(particle);
				}else{
					double centerX=currentPlayer.getX()+currentPlayer.getWidth()/2;
					double centerY=currentPlayer.getY()+currentPlayer.getHeight()/2;
					double dist=PhysicsObject.getDistanceBetweenTwoPoints(centerX, centerY, 
							particle.getX(), particle.getY());
					if(dist <= RADIUS_OF_EFFECT && dist>=currentPlayer.getWidth()/2){
						particle.collides=false;
						double sin=100*(centerY-particle.getY())/(dist*dist);
						double cos=100*(centerX-particle.getX())/(dist*dist);
						if(particleSphere){
							sin=.0002*(centerY-particle.getY())*(dist*dist);
							cos=.0002*(centerX-particle.getX())*(dist*dist);
						}
						particle.increaseX(cos);
						particle.increaseY(sin);
					}else particle.collides=true;
				}
			}else if(tempPObject instanceof NPC){
				NPC theNPC = (NPC) tempPObject;
				
				if(PhysicsObject.areObjectsColliding(theNPC, currentPlayer)){
					currentPlayer.hurt(theNPC.getDamage());
				}
			}
			
			if((tempPObject instanceof Particle)){
				checkParticleCollisions(tempPObject, copy);
			}
			
			if(tempPObject.getHeat() > this.airTemperature){
				tempPObject.increaseHeat(-1);
			}
			iterator.remove();
		}
		Collection<PhysicsObject> copy2=new LinkedHashSet<PhysicsObject>(objects);
		for(PhysicsObject tempPObject:copy2){
			checkBlockCollisions(tempPObject);
			
			applyCollisionForce(tempPObject);
			
			tempPObject.setOldX(tempPObject.getX());
			tempPObject.setOldY(tempPObject.getY());
		
			if(tempPObject.x+tempPObject.width>startX&&tempPObject.x<endX&&
					tempPObject.y+tempPObject.height>startY&&tempPObject.y<endY)
				tempPObject.drawWithTransform(g, (int)drawXModifier, (int)drawYModifier);
		}
	}

	static int c=0;
	protected static void updateLiquidBlocks(Collection<LiquidGameBlock> blocks){
		Collection<LiquidGameBlock> copy=new HashSet<LiquidGameBlock>(blocks.size());
		for(LiquidGameBlock b:blocks){
			b.updatePressure();
			if(!b.central && b.getLiquidAmount()>0)copy.add(b);
		}
		if(c++%20==0) for(LiquidGameBlock b:blocks) b.hasUpdatedPressure=false;
		for(LiquidGameBlock b:copy) b.flow();
	}
	
	private void updateOffset(){
		double relativeX=currentPlayer.getX()+drawXModifier;
		double relativeY=currentPlayer.getY()+drawYModifier;
		if(relativeX + currentPlayer.getWidth() > frameWidth/4*3){
			this.drawXModifier = this.drawXModifier - ((relativeX-frameWidth/4*3)/20);
		}else if(relativeX < frameWidth/4){
			this.drawXModifier = this.drawXModifier - ((relativeX-frameWidth/4)/20);
		}
		
		if(relativeY + currentPlayer.getHeight() > frameHeight/4*3){
			this.drawYModifier = drawYModifier - ((relativeY+currentPlayer.getHeight())-frameHeight/4*3)/20;
		}else if(relativeY < frameHeight/4){
			this.drawYModifier = drawYModifier - (relativeY-frameHeight/4)/20;
		}
		this.drawYModifier=Math.max(-currentPlayer.getY(), Math.min(drawYModifier, frameHeight-currentPlayer.getY()-currentPlayer.getHeight()-47));
		this.drawXModifier=Math.max(-currentPlayer.getX(), Math.min(drawXModifier, frameWidth-currentPlayer.getX()-currentPlayer.getWidth()-20));
	}
	
	private void drawPlayer(Graphics g){
		g.setColor(Color.CYAN);
		g.fillRect((int)(currentPlayer.getOldX()+drawXModifier), (int)(currentPlayer.getOldY()+drawYModifier), 1,1);
	
		/// mining
		if(mouseX > currentPlayer.getX() + currentPlayer.getWidth() + drawXModifier){
			miningStartX = lockToGrid(16, (int) currentPlayer.getX() + 32);
			miningStopX = lockToGrid(16, (int) currentPlayer.getX() + 64);
		}else if(mouseX < currentPlayer.getX() + drawXModifier){
			miningStartX = lockToGrid(16, (int) currentPlayer.getX() - 32);
			miningStopX = lockToGrid(16, (int) currentPlayer.getX());
		}else{
			miningStartX = lockToGrid(16, (int) currentPlayer.getX());
			miningStopX = lockToGrid(16, (int) currentPlayer.getX() + 32);
		}
		if(mouseY > currentPlayer.getY() + currentPlayer.getHeight() + drawYModifier){
			miningStartY = lockToGrid(16, (int) currentPlayer.getY() + 32);
			miningStopY = lockToGrid(16, (int) currentPlayer.getY() + 64);
		}else if(mouseY < currentPlayer.getY() + drawYModifier){
			miningStartY = lockToGrid(16, (int) currentPlayer.getY() - 32);
			miningStopY = lockToGrid(16, (int) currentPlayer.getY());
		}else{
			miningStartY = lockToGrid(16, (int) currentPlayer.getY());
			miningStopY = lockToGrid(16, (int) currentPlayer.getY() + 32);
		}
		
		Weapons.drawWeapon(currentPlayer,this, g, (int)drawXModifier, (int)drawYModifier);
		
		g.setColor(new Color(180,180,180,120));
		g.drawRect(miningStartX + (int)drawXModifier, miningStartY + (int)drawYModifier, 
				miningStopX - miningStartX, miningStopY - miningStartY);
	}
	
	public int getFrameCount(){
		return this.averageFrameCount;
	}
	
	private void checkLocationBounds(PhysicsObject tempPObject){
		if(tempPObject.getY()-currentLocation.height/4>tempPObject.getX()&&tempPObject.getX()<currentLocation.width/2){
			currentLocation.removePhysicsObject(tempPObject);
			locations[currentLocationIndex==0?3:currentLocationIndex-1].addPhysicsObject(tempPObject);
			double tmpXSpeed=tempPObject.getXSpeed();
			tempPObject.setXSpeed(-tempPObject.getYSpeed());
			tempPObject.setYSpeed(tmpXSpeed);
			double xDif=tempPObject.getOldX()-tempPObject.getX();
			double yDif=tempPObject.getOldY()-tempPObject.getOldX();
			double tmpX=tempPObject.getX();
			tempPObject.setX(currentLocation.getWidth()-tempPObject.getY()+currentLocation.getHeight()/4-tempPObject.height/2-tempPObject.width/2);
			tempPObject.setY(tmpX+currentLocation.getHeight()/4-tempPObject.height/2+tempPObject.width/2);
			tempPObject.setOldX(tempPObject.getX()-yDif);
			tempPObject.setOldY(tempPObject.getY()+xDif);
			if(!tempPObject.overrideRotation) tempPObject.currentRotation+=Math.PI/2;
			if(tempPObject instanceof Player){
				tmpX=drawXModifier;
				drawXModifier=currentLocation.getWidth()-drawYModifier+currentLocation.getHeight()/4;
				drawYModifier=tmpX+currentLocation.getHeight()/4;
				Location tmp = locations[3];
				for(int i=3; i>0; i--) locations[i]=locations[i-1];
				locations[0]=tmp;
				currentLocationIndex=(currentLocationIndex+1)%4;
				currentRotation-=Math.PI/2;
			}
		}
		else if(tempPObject.getY()-currentLocation.height/4>currentLocation.width-tempPObject.getX()&&tempPObject.getX()>currentLocation.width/2){
			currentLocation.removePhysicsObject(tempPObject);
			locations[(currentLocationIndex+1)%4].addPhysicsObject(tempPObject);
			double tmpXSpeed=tempPObject.getXSpeed();
			tempPObject.setXSpeed(tempPObject.getYSpeed());
			tempPObject.setYSpeed(-tmpXSpeed);
			double xDif=tempPObject.getOldX()-tempPObject.getX();
			double yDif=tempPObject.getOldY()-tempPObject.getOldX();
			double tmpX=tempPObject.getX();
			tempPObject.setX(tempPObject.getY()-currentLocation.getHeight()/4+tempPObject.height/2-tempPObject.width/2);
			tempPObject.setY(currentLocation.width-tmpX+currentLocation.getHeight()/4-tempPObject.height/2-tempPObject.width/2);
			tempPObject.setOldX(tempPObject.getX()+yDif);
			tempPObject.setOldY(tempPObject.getY()-xDif);
			if(!tempPObject.overrideRotation) tempPObject.currentRotation-=Math.PI/2;
			if(tempPObject instanceof Player){
				Location tmp = locations[0];
				for(int i=0; i<3; i++) locations[i]=locations[i+1];
				locations[3]=tmp;
				currentLocationIndex=currentLocationIndex==0?3:currentLocationIndex-1;
				currentRotation+=Math.PI/2;
			}
		}
	}
	
	private void applyCollisionForce(PhysicsObject object){
		double dx=0;
		double dy=0;
		double[] force=object.CForce;
		dy+=force[GameBlock.TOP_COLLISION];
		dy+=force[GameBlock.BOTTOM_COLLISION];
		dx+=force[GameBlock.LEFT_COLLISION];
		dx+=force[GameBlock.RIGHT_COLLISION];
		if(dx==0&&dy==0){
			if(Math.abs(object.getXSpeed())>=Math.abs(object.getYSpeed())){
				dy+=force[GameBlock.TOP_LEFT_COLLISION];
				dy+=force[GameBlock.TOP_RIGHT_COLLISION];
				dy+=force[GameBlock.BOTTOM_LEFT_COLLISION];
				dy+=force[GameBlock.BOTTOM_RIGHT_COLLISION];
			}else{
				dx+=force[GameBlock.TOP_LEFT_COLLISION];
				dx+=force[GameBlock.TOP_RIGHT_COLLISION];
				dx+=force[GameBlock.BOTTOM_LEFT_COLLISION];
				dx+=force[GameBlock.BOTTOM_RIGHT_COLLISION];
			}
		}
		object.increaseX(dx);
		object.increaseY(dy);
		Arrays.fill(object.CForce, 0);

		if(!Double.isNaN(object.xBounceSpeed)) object.setXSpeed(object.xBounceSpeed);
		if(!Double.isNaN(object.yBounceSpeed)) object.setYSpeed(object.yBounceSpeed);
		object.xBounceSpeed=object.yBounceSpeed=Double.NaN;
	}

	public void handleKeys(){
		currentPlayer.setMoving(false);
		
		long time=System.currentTimeMillis();
		for(int i=0; i<keyReleased.length; i++){
			if(keyReleased[i]>0 && time-keyReleased[i]>10){
				keys[i]=false;
				keyReleased[i]=0;
			}
		}
		
		if(mouseDown){
			for(GameObject o:getBlocksAtRelativePosition(mouseX, mouseY)){
				if(o instanceof GameBlock) ((GameBlock) o).explode(this, .5);
			}
			
			for(GameObject possibleObject:getBlocksAtRelativePosition(mouseX, mouseY)){
				if(possibleObject instanceof InteractibleObject){
					InteractibleObject io = (InteractibleObject) possibleObject;
					
					io.clickedOn(this);
				}
			}
		}

		if(keys['D']){
			currentPlayer.setForward(true);
			if(currentPlayer.isTouchingGround()){ //check to see if on the ground
				if(currentPlayer.xSpeed<2.5) currentPlayer.increaseXSpeed(.7);
				currentPlayer.setMoving(true);
			}else{
				if(currentPlayer.xSpeed<1.5) currentPlayer.increaseXSpeed(.2);
			}
		}
		if(keys['A']){
			currentPlayer.setForward(false);
			if(currentPlayer.isTouchingGround()){ //check to see if on the ground
				if(currentPlayer.xSpeed>-2.5) currentPlayer.increaseXSpeed(-.7);
				currentPlayer.setMoving(true);
			}else{
				if(currentPlayer.xSpeed>-1.5) currentPlayer.increaseXSpeed(-.2);
			}
		}
		if(keys['W']){
			if(currentPlayer.isTouchingGround()){ //check to see if on the ground
				currentPlayer.setYSpeed(-2.9);
				currentPlayer.setMoving(true);
			}
		}
		if(keys['S']){
			if(gravity == 0.0){
				currentPlayer.increaseYSpeed(.5);
				currentPlayer.setMoving(true);
			}
		}
		if(keys['T']){
			factory.createPlasmaParticle(currentPlayer.getHandX(), currentPlayer.getHandY());
		}
		if(keys['Q']){
			if(currentPlayer.isTouchingGround()){
				int startX=(int)currentPlayer.getX();
				int endX= startX+currentPlayer.getWidth();
				int startY=(int)currentPlayer.getY();
				int endY=startY+currentPlayer.getHeight();
				for(GameObject o:currentLocation.getObjectsBetween(startX, startY, endX, endY)){
					if(o != null && o instanceof GameBlock && o.collides) ((GameBlock) o).explode(this, 3);
				}
			}
		}
		if(keys['R']){
			int startX = (int)Math.max(currentPlayer.getX() - currentPlayer.getWidth() - 32,0);
			int startY = (int)Math.max(currentPlayer.getY() - currentPlayer.getHeight() - 32,0);
			int endX = (int)Math.min(currentPlayer.getX() + (2 * currentPlayer.getWidth()) + 32,currentLocation.getWidth() - 1);
			int endY = (int)Math.min(currentPlayer.getY() + (2 * currentPlayer.getHeight()) + 32,currentLocation.getHeight() - 1);
			
			for(GameObject o:currentLocation.getObjectsBetween(startX, startY, endX, endY)){
					if(o != null && o instanceof GameBlock){
						GameBlock block = (GameBlock) o;
						
						if(block.canPickUp){
							byte type = block.getPrimaryType();
							int x=block.getX(), y=block.getY();
							factory.destroyGameObject(block);
							block.canPickUp=false;
							factory.createParticle(x, y, type);
						}
					}
			}
			
		}
		if(keys['1']){
			equipItem(0);
		}else if(keys['2']){
			equipItem(1);
		}else if(keys['3']){
			equipItem(2);
		}else if(keys['4']){
			equipItem(3);
		}else if(keys['5']){
			equipItem(4);
		}else if(keys['6']){
			equipItem(5);
		}else if(keys['7']){
			equipItem(6);
		}else if(keys['8']){
			equipItem(7);
		}else if(keys['9']){
			equipItem(8);
		}else if(keys['0']){
			equipItem(9);
		}
		if(keys['E']){
			currentPlayer.increaseYSpeed(-0.5);
		}
		if(keys['V']){
//			if(this.craftingInterface != null){
//				this.craftingInterface.close();
//				this.craftingInterface = null;
//			}
		}
		if(keys['I']){
			// open inventory
			this.isInventoryOpen = !isInventoryOpen;
		}

		if(keys['C']){
			if(this.craftingInterface == null){
				this.craftingInterface = new PrimitiveCraftingInterface(30, 30, this);
			}else{
				this.craftingInterface.close();
				this.craftingInterface = null;
			}
		}else if(keys['M']){ // open the magic interface to make maaagggiiiic
			if(this.currentMagicEditor == null){
				this.currentMagicEditor = new MagicEditor(this.currentPlayer, this, 600, 400);
			}
		}

		if(keys[' ']){
			
			currentPlayer.hasAttacked();

			if(!attacking){
				if(!machineGun) attacking = true;
				if(currentPlayer.isForward()){
					wPivotPoint = (int)currentPlayer.getX() + 9;
				}else{
					wPivotPoint = (int)currentPlayer.getX() - 7;
				}
				if(currentPlayer.getEquippedItem().createsProjectile){
					// if creates projectile, create projectile!
					factory.createProjectileFromUseableItem(currentPlayer.getEquippedItem(), currentPlayer);
				}

				if(currentPlayer.getEquippedItem() instanceof MagicScroll){
					MagicScroll scroll = (MagicScroll) currentPlayer.getEquippedItem();
					
					scroll.useScroll(this);
				}else if(currentPlayer.getEquippedItem().canMine()){
					
					for(GameObject o:currentLocation.getObjectsBetween(miningStartX+1, miningStartY+1, 
							miningStopX-1, miningStopY-1)){
						if(o!=null&&o instanceof GameBlock){
							((GameBlock)o).explode(this, .25);
						}
					}
				}else{
					currentPlayer.checkWeaponCollision(currentLocation);
				}
			}
		}else attacking=false;

		if(!machineGun) for(char c:onePress) keys[c]=false;
	}

	private void drawInventory(int x, int y, Graphics g){
		ArrayList<InventoryItem> inventory = currentPlayer.getInventory();

		int height = (inventory.size() * 16) + 6;
		int width = 16 + 6;

		g.setColor(new Color(157,157,157));
		g.fillRect(x, y, width, height);

		g.setColor(Color.DARK_GRAY);
		g.drawRect(x + 1, y + 1, width - 3, height - 3);

		for(int count = 0; count<inventory.size(); count++){
			int locX = x+3;
			int locY = (count * 16) + y + 3;

			if(isMouseOver(locX, locY, 16,16)){
				InventoryItem item = inventory.get(count);

				item.drawSelfInInventory(g, locX, locY, true);
				this.itemMouseIsOver = item;
			}else{
				inventory.get(count).drawSelfInInventory(g, locX, locY, false);
			}
		}

		if(selectedInventoryItem != null){
			selectedInventoryItem.drawSelfInInventory(g, mouseX, mouseY, false);
		}
	}
	
	//TODO//////////////////////////OTHER///////////////////////////////////////

	public void equipItem(int index){
		for(InventoryItem item:currentPlayer.getInventory()){
			if(item instanceof UseableItem) if(index--==0) currentPlayer.setEquippedItem((UseableItem)item);
		}
	}

	public boolean isMouseOver(int x, int y, int width, int height){
		return (mouseX >= x && mouseY >= y && mouseX <= width + x && mouseY<=height + y);
	}
	
	public int lockToGrid(int gridSize, int value){
		return ((int) (value / gridSize)) * gridSize;
	}


	//TODO//////////////GETTERS AND SETTERS////////////////////////
	
	public void setItemMouseIsOver(InventoryItem item){
		this.itemMouseIsOver = item;
	}
	
	public MagicController getMagicController(){
		return magicController;
	}

	public Location getCurrentLocation(){
		return this.currentLocation;
	}

	public Player getCurrentPlayer(){
		return this.currentPlayer;
	}

	public void setInventoryItemMouseIsOver(InventoryItem item){
		this.itemMouseIsOver = item;
	}
	
	public void closeMagicCreationWindow(){
		this.currentMagicEditor.close();
		this.currentMagicEditor = null;
	}

	//TODO///////////////////////////COLLISION////////////////////////////////
	private void checkParticleCollisions(PhysicsObject p, KDTree<PhysicsObject> objects){
		if(!p.collides) return;
		int x1=(int)Math.min(p.x, p.oldX);
		int x2=(int)Math.max(p.x, p.oldX)+p.width;
		int y1=(int)Math.min(p.y, p.oldY);
		int y2=(int)Math.max(p.y, p.oldY)+p.height;
		for(PhysicsObject o:objects.searchRange(new int[]{x1,y1}, new int[]{x2,y2})){
			if(!o.collides) continue;
			byte status = p.isObjectWithin(o);
			if(status != GameBlock.NO_COLLISION){
				hasCollidedWithObject(p, o, status);
			}
		}
	}
	
	private void checkBlockCollisions(PhysicsObject p){
		final int maxStep=4;
		double jump=0;
		
		int x1=(int)Math.min(p.x, p.oldX);
		int x2=(int)Math.max(p.x, p.oldX)+p.width;
		int y1=(int)Math.min(p.y, p.oldY);
		int y2=(int)Math.max(p.y, p.oldY)+p.height;
		Collection<GameObject> objectsCollidedWith = currentLocation.getCollidingObjectsBetween(x1, y1, x2, y2);
		
		if((p instanceof Player || p instanceof NPC) && 
				!objectsCollidedWith.isEmpty()&&Math.abs(p.getXSpeed())>.01){
			//touching ground, not inside ground (avoid bouncing), against an obstacle
			if(!currentLocation.getCollidingObjectsBetween(x1+2, y2, x2-2, y2).isEmpty()&&
					currentLocation.getCollidingObjectsBetween(x1+2, y2-1, x2-2, y2-1).isEmpty()&&
						!currentLocation.getCollidingObjectsBetween(x1, y2-/*maxStep*/33, x2, y2-1).isEmpty()){
				//Check min distance needed to jump up
				for(int d=1; d<=maxStep; d++){
					if(currentLocation.getCollidingObjectsBetween(x1, y1-d+1, x2, y2-d).isEmpty()){
						p.setY(y1-d);
						objectsCollidedWith.clear();
						break;
					}
				}
				if(!objectsCollidedWith.isEmpty()){
					if(currentLocation.getCollidingObjectsBetween(x1, y1-8, x2, y2-9).isEmpty()) jump=-1.4;
					else if(currentLocation.getCollidingObjectsBetween(x1, y1-16, x2, y2-17).isEmpty()) jump=-1.8;
					else if(currentLocation.getCollidingObjectsBetween(x1, y1-32, x2, y2-33).isEmpty()) jump=-2.55;
				}
			}
		}
		
		for(GameObject object:objectsCollidedWith){
			if(object.collides){
				byte returnStatement = object.isObjectWithin(p);	
				this.hasCollidedWithObject(p, object, returnStatement);
			}
		}
		if(jump!=0 && !keys['S']) p.yBounceSpeed=jump;
	}

	//Handle Listener Events
	public void hasCollidedWithObject(PhysicsObject object1,
			PhysicsObject object2, byte collisionInfo) {
		if(object2 instanceof Player && object1 instanceof Particle) return;
		double reflection = .2;
		if(collisionInfo == GameBlock.BOTTOM_COLLISION){
			double y1=object1.getYSpeed(), y2=object2.getYSpeed();
			object1.setY(object1.getY()+(object2.getY() - object1.getHeight()-object1.getY())/2);
			object2.setY(object2.getY()+(object1.getY() + object1.getHeight()-object2.getY())/2);
			object1.setYSpeed(( ((y1-y2)/2) * -reflection ) + ((y1+y2)/2 ));
			object2.setYSpeed(( ((y2-y1)/2) * -reflection ) + ((y1+y2)/2 ));
			
		}if(collisionInfo == GameBlock.TOP_COLLISION){
			double y1=object1.getYSpeed(), y2=object2.getYSpeed();
			object1.setY(object1.getY()+(object2.getY() + object2.getHeight()-object1.getY())/2);
			object2.setY(object2.getY()+(object1.getY() - object2.getHeight()-object2.getY())/2);
			object1.setYSpeed(( ((y1-y2)/2) * -reflection ) + ((y1+y2)/2 ));
			object2.setYSpeed(( ((y2-y1)/2) * -reflection ) + ((y1+y2)/2 ));

		}if(collisionInfo == GameBlock.RIGHT_COLLISION){
			double x1=object1.getXSpeed(), x2=object2.getXSpeed();
			object1.setX(object1.getX()+(object2.getX() - object1.getWidth()-object1.getX())/2);
			object2.setX(object2.getX()+(object1.getX() + object1.getWidth()-object2.getX())/2);
			object1.setXSpeed(( ((x1-x2)/2) * -reflection ) + ((x1+x2)/2 ));
			object2.setXSpeed(( ((x2-x1)/2) * -reflection ) + ((x1+x2)/2 ));

		}if(collisionInfo == GameBlock.LEFT_COLLISION){
			double x1=object1.getXSpeed(), x2=object2.getXSpeed();
			object1.setX(object1.getX()+(object2.getX() + object2.getWidth()-object1.getX())/2);
			object2.setX(object2.getX()+(object1.getX() - object2.getWidth()-object2.getX())/2);
			object1.setXSpeed(( ((x1-x2)/2) * -reflection ) + ((x1+x2)/2 ));
			object2.setXSpeed(( ((x2-x1)/2) * -reflection ) + ((x1+x2)/2 ));
		}

		//System.out.println(object1.getYSpeed()+" "+object2.getYSpeed());
	}

	public void hasCollidedWithObject(PhysicsObject physicsObject, GameObject object, byte collisionInfo) {
		double reflection = physicsObject.bounce;
		
		if(physicsObject instanceof PlasmaParticle){
			PlasmaParticle pParticle = (PlasmaParticle) physicsObject;
			pParticle.touchedGround();
		}
		
		boolean diag=collisionInfo>4;

		if(collisionInfo == GameBlock.TOP_COLLISION||collisionInfo == GameBlock.TOP_LEFT_COLLISION||collisionInfo == GameBlock.TOP_RIGHT_COLLISION){
			double d=object.getY() - physicsObject.height - physicsObject.getY();
			if(!diag || Math.abs(physicsObject.getXSpeed())>=Math.abs(physicsObject.getYSpeed())) physicsObject.CForce[collisionInfo]=Math.min(d,physicsObject.CForce[collisionInfo]);

			if(!diag) object.forceApplied(physicsObject.getYSpeed() * .75, this);
			if(!diag || Math.abs(physicsObject.getXSpeed())>=Math.abs(physicsObject.getYSpeed())) 
				physicsObject.yBounceSpeed=(physicsObject.getYSpeed() * -reflection);

			// FRICTION
			if(!diag){
				if(!(physicsObject instanceof Player) || !currentPlayer.moving)
					physicsObject.setXSpeed(physicsObject.getXSpeed() * physicsObject.getFriction());
				physicsObject.setIsTouchingGround(true);
			}

		}if(collisionInfo == GameBlock.BOTTOM_COLLISION||collisionInfo == GameBlock.BOTTOM_LEFT_COLLISION||collisionInfo == GameBlock.BOTTOM_RIGHT_COLLISION){
			double d=object.getY() + object.getHeight() - physicsObject.getY();
			if(!diag || Math.abs(physicsObject.getXSpeed())>=Math.abs(physicsObject.getYSpeed())) physicsObject.CForce[collisionInfo]=Math.max(d,physicsObject.CForce[collisionInfo]);
			
			if(!diag) object.forceApplied(physicsObject.getYSpeed() * .75, this);
			if(!diag || Math.abs(physicsObject.getXSpeed())>=Math.abs(physicsObject.getYSpeed()))
				physicsObject.yBounceSpeed=(physicsObject.getYSpeed() * -reflection);

		}if(collisionInfo == GameBlock.LEFT_COLLISION||collisionInfo == GameBlock.TOP_LEFT_COLLISION||collisionInfo == GameBlock.BOTTOM_LEFT_COLLISION){
			double d=object.getX() - physicsObject.width - physicsObject.getX();
			if(!diag || Math.abs(physicsObject.getYSpeed())>Math.abs(physicsObject.getXSpeed())) physicsObject.CForce[collisionInfo]=Math.min(d,physicsObject.CForce[collisionInfo]);
			
			if(!diag) object.forceApplied(physicsObject.getXSpeed() * .75, this);
			if(!diag || Math.abs(physicsObject.getYSpeed())>Math.abs(physicsObject.getXSpeed()))
				physicsObject.xBounceSpeed=(physicsObject.getXSpeed() * -reflection);

		}if(collisionInfo == GameBlock.RIGHT_COLLISION||collisionInfo == GameBlock.TOP_RIGHT_COLLISION||collisionInfo == GameBlock.BOTTOM_RIGHT_COLLISION){
			double d=object.getX() + object.getWidth() - physicsObject.getX();
			if(!diag || Math.abs(physicsObject.getYSpeed())>Math.abs(physicsObject.getXSpeed())) physicsObject.CForce[collisionInfo]=Math.max(d,physicsObject.CForce[collisionInfo]);
			
			if(!diag) object.forceApplied(physicsObject.getXSpeed() * .75, this);
			if(!diag || Math.abs(physicsObject.getYSpeed())>Math.abs(physicsObject.getXSpeed()))
				physicsObject.xBounceSpeed=(physicsObject.getXSpeed() * -reflection);
		}
		
		

	}
	
	
	public Collection<GameObject> getBlocksAtRelativePosition(int x, int y){		
		return currentLocation.getObjectsAt((int) (x - this.drawXModifier), (int) (y - this.drawYModifier));
	}

	
	//TODO///////////////////////////// MOUSE/KEYBOARD LISTENERS ////////////////////////////

	@Override
	public void mouseClicked(MouseEvent arg0) {
		elementController.mouseChanged(arg0.getX(), arg0.getY(), true);
		this.mouseDown = true;
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		elementController.mouseChanged(arg0.getX(), arg0.getY(), false);
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		elementController.mouseChanged(arg0.getX(), arg0.getY(), false);
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		mouseDown = true;
		elementController.mouseChanged(arg0.getX(), arg0.getY(), true);

		int button = arg0.getButton();
		//System.out.println("mouse button pressed: " + button);

		if(itemMouseIsOver != null){
			if(button == MouseEvent.BUTTON1){ // left mouse button
				this.selectedInventoryItem = itemMouseIsOver;
				selectedInventoryItem.setIsBeingDragged(true);
			}else if(button == MouseEvent.BUTTON3){ // right mouse button
				if(itemMouseIsOver instanceof UseableItem){

					UseableItem tempItem = (UseableItem) itemMouseIsOver;

					currentPlayer.setEquippedItem(tempItem);
				}else if(itemMouseIsOver instanceof InventoryPeicesHolder){
					InventoryPeicesHolder particles = (InventoryPeicesHolder) itemMouseIsOver;

					if(particles.getCount() > 1){
						particles.setCount(particles.getCount() - 1);
					}else{
						currentPlayer.removeItemFromInventory(particles);
					}

					int handX = currentPlayer.getHandX();
					int handY = currentPlayer.getHandY();

					Particle particle = null;

					if(currentPlayer.isForward()){
						particle = factory.createParticle(handX + 10, handY, particles.getType());
						particle.setXSpeed(10);
					}else{
						particle = factory.createParticle(handX - 10, handY, particles.getType());
						particle.setXSpeed(-10);
					}

					particle.setYSpeed(1);
				}else if(itemMouseIsOver instanceof PrimitiveItem){
					PrimitiveItem pi = (PrimitiveItem) itemMouseIsOver;
					
					if(this.itemCraftingInterface == null){
						this.itemCraftingInterface = new ItemCraftingInterface(100, 50, this);
						int xToPlace = itemCraftingInterface.getX() + 5;
						int yToPlace = itemCraftingInterface.getY() + 5;
						
						itemCraftingInterface.addItemToUse(new ItemCraftingHolder(xToPlace, yToPlace, pi));
					}else{
						if(itemCraftingInterface.containsItem(pi)){
							// nothing, or maybe remove for now
						}else{
							int xToPlace = itemCraftingInterface.getX() + 5;
							int yToPlace = itemCraftingInterface.getY() + 5;
							itemCraftingInterface.addItemToUse(new ItemCraftingHolder(xToPlace, yToPlace, pi));
						}
					}
				}else if(itemMouseIsOver instanceof Consumable){
					Consumable c = (Consumable) itemMouseIsOver;
					
					c.useConsumeable(this);
				}
			}
		}
	}
	
	public void closeCraftingInterface(){
		if(this.itemCraftingInterface != null){
			this.itemCraftingInterface.close();
			this.itemCraftingInterface = null;
		}
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		mouseDown = false;
		if(this.selectedInventoryItem !=null){

//			if(this.craftingInterface != null){
//				this.craftingInterface.potentiallyAddInventoryItem(this.selectedInventoryItem, this.currentPlayer); 
//			}

			this.selectedInventoryItem.setIsBeingDragged(false);
			this.selectedInventoryItem = null;
			itemMouseIsOver = null;
		}
	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		mouseDown = true;
		this.mouseX = arg0.getX();
		this.mouseY = arg0.getY();
		
		elementController.mouseChanged(arg0.getX(), arg0.getY(), true);
	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		mouseDown = false;
		this.mouseX = arg0.getX();
		this.mouseY = arg0.getY();
		
		elementController.mouseChanged(arg0.getX(), arg0.getY(), false);

		//System.out.println("Mouse moved.");

		//this.repaint();
	}

	//The weird code in here dealing with keyReleased[] 
	//is for the weird linux glitch where a held key 
	//sends constant keyreleased and keypressed events
	//instead of just keypressed
	@Override
	public void keyPressed(KeyEvent e) {	
		int code=e.getKeyCode();
		if(keyReleased[code]==0){
			keys[code]=true;
			keyReleased[code]=-1;
		}
		keyReleased[code]=-1;
	}
	
	@Override 
	public void keyReleased(KeyEvent e) {
		keyReleased[e.getKeyCode()]=System.currentTimeMillis();
	}
	
	@Override
	public void keyTyped(KeyEvent e) {}

	@Override
	public void componentResized(ComponentEvent e) {
		//if(getWidth()>0) this.frameWidth=getWidth();
		//if(getHeight()>0) this.frameHeight=this.getHeight();
	}

	@Override
	public void componentMoved(ComponentEvent e) {}

	@Override
	public void componentShown(ComponentEvent e) {}

	@Override
	public void componentHidden(ComponentEvent e) {}
	
	@Override
	public void elementClicked(GUIElement element) {
		this.mainFrame.dispose();
		System.exit(0);
	}
	

	private class RunnerThread extends Thread{
		private LostHope game;

		public RunnerThread(LostHope l){
			game=l;
		}

		@Override
		public void run() {
			game.setIgnoreRepaint(true);
			game.mainFrame.setIgnoreRepaint(true);
			game.running=true;
			int tickTime = 15;
			long nextTick = System.currentTimeMillis();
			int loops;
			
			while(running) {
				loops = 0;
				while( System.currentTimeMillis() > nextTick && loops < 5) {
					handleKeys();
					if(keys['O']) tickTime=5000;
					else if(keys['P']) tickTime=500;
					else tickTime=15;
					BufferedImage buffer=GameFactory.getBufferedImage(frameWidth, frameHeight);
					game.drawGame(buffer.createGraphics());
					game.screenBuffer=buffer;
					game.repaint();
					nextTick += tickTime;
					loops++;
				}
				if(loops>=5) nextTick=System.currentTimeMillis();
				try{Thread.sleep(Math.max(nextTick-System.currentTimeMillis()-2,0));}catch(Exception e){}
			}
		}

	}


	public static void main(String[] args){
		//new LostHope(800,500,false,true, null).start();
		
		new GameMenu(800, 600, true);
		//KDTree.main(args);
	}
	

	

}
