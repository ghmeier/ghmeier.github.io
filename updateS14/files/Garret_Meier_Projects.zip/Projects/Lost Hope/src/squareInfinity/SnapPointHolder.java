package squareInfinity;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

public class SnapPointHolder {
	
	private int x;
	private int y;
	
	private ItemCraftingHolder item;
	
	private boolean inGoodPosition;
	
	private ItemCraftingInterface controller;
	
	public SnapPointHolder(int x, int y, ItemCraftingHolder item, ItemCraftingInterface controller){
		this.x = x;
		this.y = y;
		
		this.controller = controller;
		
		this.inGoodPosition = false;
		
		this.item = item;
	}
	
	public Dimension getDimension(){
		return new Dimension(this.x, this.y);
	}
	
	public void drawSelf(Graphics g, int xScale, int yScale){
		if(inGoodPosition){
			g.setColor(Color.GREEN);
		}else{
			g.setColor(Color.RED);
		}
		
		g.drawRect((this.x * xScale) + item.getX() + controller.getX(), 
				(this.y * yScale) + item.getY() + controller.getY(), xScale, yScale);
	}
	
	public void setGood(boolean good){
		this.inGoodPosition = good;
	}
	
	public boolean getGood(){
		return this.inGoodPosition;
	}
	
	public int getX(){
		return this.x;
	}
	
	public int getY(){
		return this.y;
	}
	
	public int getTrueX(){
		return (this.x * 3) + item.getX() + controller.getX();
	}
	
	public int getTrueY(){
		return (this.y * 3) + item.getY() + controller.getY();
	}
	
	public ItemCraftingHolder getItem(){
		return this.item;
	}

}
