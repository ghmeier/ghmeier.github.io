package squareInfinity;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class Projectile extends PhysicsObject implements MagicPrimitive{

	/// PROJECTILE TYPES

	public static final byte ARROW = -1;
	public static final byte FIREBALL = -2;
	protected boolean magic = false; 
	///

	protected int damage;

	protected byte type;

	protected double turn;
	
	private int duration;
	private int durationLeft;
	
	private double oldXSpeed, oldYSpeed;
	
	protected boolean damageWhenStopped=true;
	
	public Projectile(byte type, int damage, double x, double y){
		super(x,y,0,0, 1); // just to satisfy the compiler lol

		if(type == ARROW){ // or whatever an arrow looks like
		//	this.width = 5;
		//	this.height = 2;
			this.width = 2;
			this.height = 2;
			this.magic =false;
			this.duration=this.durationLeft=10000;
			
			this.bounce=0;
			this.friction = .6;
			damageWhenStopped=false;
			overrideRotation=true;
		}else if (type == FIREBALL){
			this.width = 5;
			this.height = 5;
			this.magic = true;
			this.duration=this.durationLeft=100;
			
			this.bounce=.3;
			this.friction = .9;
		}

		this.damage = damage;
		this.type = type;
		this.turn = 0.0;
	}

	public Projectile(byte type, int damage, double x, double y, int width, int height, double friction){
		super(x,y,width,height, friction);

		this.type = type;

		this.damage = damage;
		this.turn = 0.0;
	}
	
	public byte getType(){
		return this.type;
	}

	@Override
	public void drawSelf(Graphics g) {
	//	System.out.println(xSpeed+" "+ySpeed+" "+oldXSpeed+" "+oldYSpeed);
		
		if(this.type == ARROW){
			double tmpX=xSpeed; //For determining the angle to draw the arrow
			double tmpY=ySpeed;
			if(Math.abs(xSpeed)<.1&&Math.abs(ySpeed)<.1){
				tmpX=oldXSpeed;
				tmpY=oldYSpeed;
			}
			if(tmpX==0) tmpX=.01;
			if(tmpY==0) tmpY=.01;
			oldXSpeed=Math.abs(tmpX)>.01?tmpX:.01;
			oldYSpeed=Math.abs(tmpY)>.01?tmpY:0;
			
			Graphics2D g2 = (Graphics2D) g;//These 2 lines allow it to draw a thick line
	        g2.setStroke(new BasicStroke(2));
	        
			g2.setColor(Color.gray);
	        double dist=(Math.sqrt(tmpX*tmpX+tmpY*tmpY));
	        g2.drawLine((int)x+1, (int)y+1,(int)(x-12*tmpX/dist), (int)(y-12*tmpY/dist));
	        g2.setColor(Color.lightGray);
	        g2.drawLine((int)( x-12*tmpX/dist), (int)(y-12*tmpY/dist), (int)(x-11*tmpX/dist), (int)(y-11*tmpY/dist));
		}else if(this.type ==  FIREBALL){
			g.drawImage(Toolkit.getDefaultToolkit().getImage("Pic/Projectiles/FireBall.png"), (int)x, (int)y, null);
			//this.setYSpeed(-0.1);
		}
	}

	/*public void drawProjectile(Graphics g, Player currentPlayer, int wPivotPoint){
		// DON'T NEED THIS CODE HERE ANY MORE \\
		if(currentPlayer.launch){
			//System.out.println("Shooting Arrow"); //arrow stopped working for some reason :(
			//drawing of an arrow
			g.setColor(new Color(100,50,50));
			g.fillRect((int)x, (int)y, width, height);
			g.setColor(Color.gray);
			g.fillRect((int)x + width , (int)y , 5, 2);
			g.setColor(Color.LIGHT_GRAY);
			g.fillRect((int) x - 3, (int) y, 2, 2);
			//
		}else{
			//rotates weapon images that are not projectiles when attacking

			Graphics2D g2d = (Graphics2D)g;
			if(currentPlayer.forward){
				System.out.println("rotating " + turn); 
				g2d.rotate(turn,wPivotPoint, currentPlayer.y);  // Rotate the image by turn radians.
				turn += .5;
				g2d.drawImage(Toolkit.getDefaultToolkit().getImage(currentPlayer.weapon), (int)currentPlayer.x-15, (int)currentPlayer.y-17, null);
			}else{
				System.out.println("rotating " + turn); 
				g2d.rotate(turn,wPivotPoint, currentPlayer.y);  // Rotate the image by turn radians.
				turn -= .5;
				g2d.drawImage(Toolkit.getDefaultToolkit().getImage(currentPlayer.weaponL), (int)currentPlayer.x-15, (int)currentPlayer.y-17, null);
			}
		//}
	}*/
	
	
	public void checkWeaponCollision(Location location){
		if(stopped&&duration>0) durationLeft--;
		else durationLeft=duration;
		if(durationLeft==0){
			location.removePhysicsObject(this);
			LostHope.magicController.removeVariable(this);
		}
		if(stopped && !damageWhenStopped) return;
		//System.out.println("checking weapon collision");

		//Iterator<NPC> targetsIterator = location.getNPCs().iterator();
		
		ArrayList<NPC> targets = location.getNPCs();
		
		int counter = 0;
		
		boolean miss = true;
		while(counter < targets.size() && miss){
			
			//System.out.println("in the while");
			
			NPC tempNPC = targets.get(counter);
			
			double distance = PhysicsObject.getDistanceBetweenTwoPoints(tempNPC.getX(), tempNPC.getY(), this.x, this.y);
			
			//System.out.println(distance);
			
			if(distance < 50){
				//System.out.println("the if succeeded");
				
				if(this.getXSpeed() < 0){
					tempNPC.hurt((int)(this.damage), true);
				}else{
					tempNPC.hurt((int)(this.damage), false);
				}
				
				location.removePhysicsObject(this);
			}
			
			counter = counter + 1;
		}
	}
	public void checkWeaponCollision(Location location, LostHope controller){


		Iterator<NPC> targetsIterator = location.getNPCs().iterator();
		boolean miss = true;
		while(targetsIterator.hasNext() && miss){
			NPC tempNPC = targetsIterator.next();
			if(this.type == FIREBALL){
				double distance = PhysicsObject.getDistanceBetweenTwoPoints(this.x, this.y, tempNPC.getX(), tempNPC.getY());
				if(distance < 1000){
					if(this.x < tempNPC.getX()){
						this.setXSpeed(10);
					}else{
						this.setXSpeed(-10);
					}
					if(this.y < tempNPC.getY()){
						this.setYSpeed(10);
					}else{
						this.setYSpeed(-10);
					}
				}
			}
			//double distance = PhysicsObject.getDistanceBetweenTwoPoints(this.x, this.y, tempNPC.getX(), tempNPC.getY());
			if(PhysicsObject.areObjectsColliding(this, tempNPC)){ // for now, will change to the actual length of pic at some point
				if(this.getXSpeed() < 0){
					tempNPC.hurt((int)(this.damage * Math.abs(this.getXSpeed())/15.0), true);
					miss = false;
					this.setXSpeed(0.0);
				}else{
					tempNPC.hurt((int)(this.damage * Math.abs(this.getXSpeed())/15.0), false);
					miss = false;
					this.setXSpeed(0.0);
				}

				if(controller.getCurrentPlayer().isForward()){
					tempNPC.increaseXSpeed(.001);
				}else{
					tempNPC.increaseXSpeed(-.001);  
				}

				tempNPC.setLastAttacker(controller.getCurrentPlayer());

				LostHope.factory.destroyProjectile(this);
			}
		}

	}

	@Override
	public void setPower(int power) {
		this.damage = power;
	}

	@Override
	public void magicExplode(LostHope controller, int power) {
		// TODO: figure out what a projectile would do when exploding
		
	}

	@Override
	public void toggleHold(boolean isHeld) {
		if(isHeld){
			this.setXSpeed(0);
			this.setYSpeed(0);
		}
		
		this.isHeld = isHeld;
	}

	@Override
	public MagicPrimitive createCopyOfSelf() {
		Projectile copy = LostHope.factory.createProjectile(type, damage, x, y);
		
		Random r = new Random();
		
		copy.increaseYSpeed(r.nextInt(10) - 5);
		copy.increaseXSpeed(r.nextInt(10) - 5);
		
		return copy;
	}
}




