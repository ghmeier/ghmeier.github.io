package squareInfinity.npc;

import java.util.Random;

import squareInfinity.NPC;
import squareInfinity.Player;

public class AngryEnemyAI extends AI {
	
	double speed;
	
	long pastTime;
	
	public AngryEnemyAI(){
		pastTime = System.nanoTime();
		
		this.speed = 1;
	}

	@Override
	public void doSomething(NPC npc) {
		Player attacker = npc.getLastAttacker();
		
		if(attacker != null){ // angry
			if(npc.getX() > attacker.getX()){
				this.moveLeft(npc);
			}else{
				this.moveRight(npc);
			}
		}else{ // calm
			Random r = new Random();
			
			int choice = r.nextInt(2);
			
			if(choice == 1){
				this.moveLeft(npc);
			}else{
				this.moveRight(npc);
			}
		}
	}

	@Override
	public void moveLeft(NPC npc) {
		double currentTime = System.nanoTime();
		
		double dif = currentTime - pastTime;
		
		if(dif >= 500.0){
			npc.increaseXSpeed(-speed);
			//System.err.println("jumping");
			npc.setXSpeed(-speed);
			
			pastTime = System.nanoTime();
		}
	}
	
	@Override
	public void moveRight(NPC npc) {
		double currentTime = System.nanoTime();
		
		double dif = currentTime - pastTime;
		
		if(dif >= 500.0){
			npc.increaseXSpeed(speed);
			//System.err.println("jumping");
			npc.setXSpeed(1);
			pastTime = System.nanoTime();
		}
	}

	@Override
	public void jump(NPC npc) {
		double currentTime = System.nanoTime();
		
		double dif = currentTime - pastTime;
		
		if(dif >= 1000000000.0){
			npc.setYSpeed(-3);
			//System.err.println("jumping");
			
			pastTime = System.nanoTime();
		}
	}

}
