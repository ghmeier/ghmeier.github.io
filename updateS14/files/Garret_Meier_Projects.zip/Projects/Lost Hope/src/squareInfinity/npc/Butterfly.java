package squareInfinity.npc;

import java.awt.Graphics;

import squareInfinity.Location;
import squareInfinity.NPC;

public class Butterfly extends Animal{	
	
	public static final int[] BASESTATS = new int[] {0,6,5,6,1,1,1};//order is damage, dexterity, health, size, stamina, strength 
	
	public Butterfly(String name, int x, int y, Location holder) {
		super(name,NPC.BUTTERFLY,x,y,2*BASESTATS[3],BASESTATS[3],holder);
		this.setAI(new ButterflyAI());
		this.isAggressive = false;	
		this.width  = this.size;
		this.height = this.size;
	}
	
	@Override
	public void trueDraw(Graphics g) {
		if(isRight){
			g.drawImage(NPCImage[BUTTERFLY],(int)x,(int)y,this.width,this.height, null);
		}else{
			g.drawImage(NPCImageFlipped[BUTTERFLY], (int)x, (int)y, this.width, this.height, null);
		}
	}

}
