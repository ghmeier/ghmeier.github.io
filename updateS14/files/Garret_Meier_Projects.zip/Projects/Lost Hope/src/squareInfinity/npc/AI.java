package squareInfinity.npc;

import squareInfinity.LostHope;
import squareInfinity.NPC;

public abstract class AI {

	public enum State{
		left, right, runFromEnemy, attackEnemy, jump, stationary
		}
	
	public abstract void doSomething(NPC npc);
	public abstract void moveLeft(NPC npc);
	public abstract void moveRight(NPC npc);
	public abstract void jump(NPC npc);
	//private Graphics g;
	
	public boolean enemyIsNear(NPC npc) {
		//TODO find enemies near
		return false;
	}
	
	public boolean isOnGround(NPC check) {//checks to be sure the animal isn't flying
		if (LostHope.factory.getCollidingGameObject((int)(check.getX()), (int)(check.getY()+check.getHeight())+1, check.getWidth(), 1)!=null) {
			return true;
		}
		return false;
	}

	public boolean againstWall(NPC check, int side) {
		if (side == 0) {
			if (LostHope.factory.getCollidingGameObject((int)(check.getX()-1-LostHope.BLOCKSIDE), (int)(check.getY()), LostHope.BLOCKSIDE, check.getHeight())!=null 
					&& LostHope.factory.getCollidingGameObject((int)(check.getX()-1), (int)(check.getY()+check.getHeight()),LostHope.BLOCKSIDE,check.getHeight())==null) {
				return true;
			}
		} else {
			if (LostHope.factory.getCollidingGameObject((int)(check.getX()+check.getWidth()+1),(int)(check.getY()),LostHope.BLOCKSIDE,check.getHeight())!=null
					&& LostHope.factory.getCollidingGameObject((int)(check.getX()+check.getWidth()+1), (int)(check.getY()+check.getHeight()),LostHope.BLOCKSIDE,check.getHeight())==null) {
				return true;
			}
		}
		return false;
	}

}
