package squareInfinity.npc;

import java.awt.Graphics;

import squareInfinity.Location;
import squareInfinity.NPC;


public class Wolf extends Animal{
	
	public static final int[] BASESTATS = new int[] {12,7,15,20,10,12,2};//order is damage, dexterity, health, size, stamina, strength, variability
	private int damage;
	
	public Wolf(String name, int x, int y, Location holder) {
		super(name,NPC.WOLF,x,y,BASESTATS[3],BASESTATS[3],holder);
		this.setAI(new WolfAI());
		this.width  = this.size*2;
		this.height = this.size;
	}
	
	@Override
	public void trueDraw(Graphics g) {
		if(isRight){
			g.drawImage(NPCImage[WOLF],(int)x,(int)y,this.width,this.height, null);
		}else{
			g.drawImage(NPCImageFlipped[WOLF], (int)x, (int)y, this.width,this.height, null);
		}
	}
	
}
