package squareInfinity.npc;

import squareInfinity.NPC;

public class BlockAI extends AI{
	
	protected double pastTime;
	
	public BlockAI(){
		pastTime = System.nanoTime();
	}

	@Override
	public void doSomething(NPC npc) {
		double currentTime = System.nanoTime();
		
		double dif = currentTime - pastTime;
		
		if(dif >= 1000000000.0){ // hop once a second
			npc.increaseYSpeed(-1.0);
			//System.err.println("jumping");
			
			pastTime = System.nanoTime();
		}
	}

	@Override
	public void moveLeft(NPC npc) {
		double currentTime = System.nanoTime();
		
		double dif = currentTime - pastTime;
		
		if(dif >= 1000000000.0){
			npc.setXSpeed(-1);
			//System.err.println("jumping");
			
			pastTime = System.nanoTime();
		}
	}

	@Override
	public void moveRight(NPC npc) {
		double currentTime = System.nanoTime();
		
		double dif = currentTime - pastTime;
		
		if(dif >= 1000000000.0){
			npc.setXSpeed(1);
			//System.err.println("jumping");
			
			pastTime = System.nanoTime();
		}
	}

	@Override
	public void jump(NPC npc) {
		double currentTime = System.nanoTime();
		
		double dif = currentTime - pastTime;
		
		if(dif >= 1000000000.0){
			npc.setYSpeed(-3);
			//System.err.println("jumping");
			
			pastTime = System.nanoTime();
		}
	}

}
