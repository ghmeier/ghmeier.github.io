package squareInfinity.npc;

import java.util.Random;

import squareInfinity.LostHope;
import squareInfinity.NPC;

public class ButterflyAI extends AI{
	
	private long oldTime;
	private long scaredTime;
	private int dex;
	private State currentState;
	
	public ButterflyAI(){
		oldTime = System.currentTimeMillis();
		currentState = State.stationary;
	}

	@Override
	public void doSomething(NPC npc) {
		long newTime = System.currentTimeMillis();
			if(npc instanceof Butterfly){
				Animal a = (Animal) npc;
				dex = a.getDexterityModifier();
				switch(currentState) {
					case left:
						if (newTime - scaredTime >1000) {
							currentState = State.stationary;
						}else if (isOnGround(a) || newTime - oldTime >=(Math.random()*200) + 400) {
							oldTime = System.currentTimeMillis();
							jump(a);
						}
						moveLeft(a);
						
						break;
					case right:
						if (newTime - scaredTime >1000) {
							currentState = State.stationary;
						}else if (isOnGround(a) || newTime - oldTime >=(Math.random()*200) + 400) {
							oldTime = System.currentTimeMillis();
							jump(a);
						}
						moveRight(a);
						break;
					case stationary:
						double distance = LostHope.factory.getDistanceBetweenPhysicsObjectAndPlayer(a);
						if (distance<=175 && distance>=0) {
							currentState = State.right;
							scaredTime = System.currentTimeMillis();
						} else if (distance>=-175 && distance<0) {
							currentState = State.left;
							scaredTime = System.currentTimeMillis();
						} else if (newTime - oldTime > 10000) {
							oldTime = System.currentTimeMillis();
							Random r= new Random();
							int mod = r.nextInt(10);
							if (mod <=1) {
								currentState = State.right;
							} else if(mod<=2) {
								currentState = State.left;
							}
						}
						break;
				
				}
				
				
		}
			
	}

	

	@Override
	public void moveLeft(NPC npc) {
		npc.setXSpeed(-dex/2-1);
		
	}

	@Override
	public void moveRight(NPC npc) {
		npc.setXSpeed(dex/2+1);
		
	}

	@Override
	public void jump(NPC npc) {
		npc.setYSpeed(-dex-1);
		
	}

}
