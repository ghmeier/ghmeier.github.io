package squareInfinity.npc;

import java.awt.Color;
import java.awt.Graphics;

import squareInfinity.Location;
import squareInfinity.NPC;

public abstract class Animal extends NPC {

	protected boolean isChild;
	
	public Animal(String name, byte type, double x, double y, int width,int height, Location holder) {
		super(name, type, x, y, width, height, holder);
		
		this.width = width;
		this.height = height;
	}
	
	@Override
	public void drawSelf(Graphics g){
		
		if(this.xSpeed >= 0){
			this.isRight= true;
		}else{
			this.isRight = false;
		}
		
		// calls individual drawing method:
		this.trueDraw(g);
		
		if(this.health < this.maxHealth){
			g.setColor(new Color(200,0,0));
			g.fillRect((int)x - 3,(int)y-3, this.size, 2);
			g.setColor(Color.green);
			g.fillRect((int)x -3,(int)y - 3,this.size * (health/maxHealth),2);
		}
		
		if(this.ai != null){
			this.ai.doSomething(this);
		}
	}
	
	public abstract void trueDraw(Graphics g);
	
	public int getStrengthModifier() {
		return this.strengthModifier;
	}
	
	public int getStaminaModifier() {
		return this.staminaModifier;
	}
	
	public int getDexterityModifier() {
		return this.dexterityModifier;
	}
	
	public int getSize() {
		return this.baseSize;
	}
	
	public int getHealth() {
		return this.health;
	}
	
	public boolean getIsChild() {
		return this.isChild;
	}
	
		
}
