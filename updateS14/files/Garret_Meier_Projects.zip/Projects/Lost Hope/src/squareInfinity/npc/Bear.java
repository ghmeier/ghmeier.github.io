package squareInfinity.npc;

import java.awt.Graphics;

import squareInfinity.Location;
import squareInfinity.NPC;

public class Bear extends Animal {
	
	public static final int[] BASESTATS = new int[] {15,4,25,40,17,20,3};//order is damage, dexterity, health, size, stamina, strength 
	private int damage;

	public Bear(String name, int x, int y, Location holder) {
		super(name,NPC.BEAR,x,y,BASESTATS[3],BASESTATS[3],holder);
		this.setAI(new WolfAI());	
		this.width  = (int)(this.size*1.3);
		this.height = this.size;
	}

	@Override
	public void trueDraw(Graphics g) {
		
		if(isRight){
			g.drawImage(NPCImage[BEAR],(int)x,(int)y,2*this.width,this.height, null);
		}else{
			g.drawImage(NPCImageFlipped[BEAR], (int)x, (int)y, 2*this.width, this.height, null);
		}
	}

}
