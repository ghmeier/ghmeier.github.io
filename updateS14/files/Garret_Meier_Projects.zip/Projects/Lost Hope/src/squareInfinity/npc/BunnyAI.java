package squareInfinity.npc;

import java.util.Random;

import squareInfinity.LostHope;
import squareInfinity.NPC;

public class BunnyAI extends AI {
	private long oldTime;
	
	public BunnyAI() {
		oldTime = System.currentTimeMillis();
	}
	@Override
	public void doSomething(NPC npc) {
		long newTime = System.currentTimeMillis();
		
		if(newTime - oldTime >= 500 && LostHope.factory.getCollidingGameObject((int)(npc.getX()), (int)(npc.getY()+LostHope.BLOCKSIDE), 1, 1)!=null){
			oldTime = System.currentTimeMillis();
			
			if(npc instanceof Bunny){
				Bunny b = (Bunny) npc;
				
				double dex = b.getDexterityModifier();
				
				Random r = new Random();
				
				int mod = r.nextInt(2);
				
				double totalX = 0;
				
				if(mod == 1){
					totalX = -dex;
				}else{
					totalX = dex;
				}
				
				if (b.getX()>0 && b.getX()<LostHope.WIDTH) {
					b.setXSpeed(totalX);
				} else {
					b.setXSpeed(0);
				}
				
				b.setYSpeed(-(Math.abs(dex)));
			}
		}

	}
	
	@Override
	public void moveLeft(NPC npc) {
		// TODO Auto-generated method stub

	}

	@Override
	public void moveRight(NPC npc) {
		// TODO Auto-generated method stub

	}

	@Override
	public void jump(NPC npc) {
		// TODO Auto-generated method stub

	}

}
