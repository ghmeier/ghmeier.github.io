package squareInfinity.npc;

import java.util.Random;

import squareInfinity.LostHope;
import squareInfinity.NPC;

public class WolfAI extends AI {
	private final boolean debug=false;
	
	private long oldTime;
	private int dex;

	private State currentState;
	
	private boolean facingRight;
	
	public WolfAI(){
		Random r = new Random();
		this.currentState = State.stationary;
		
		if(!LostHope.debugManager.hasProfile("wolfai")){
			LostHope.debugManager.addProfile("wolfai");
			LostHope.debugManager.setProfile("wolfai", false); // change to true to have debugging text
		}
	}

	@Override
	public void doSomething(NPC npc) {
		long newTime = System.currentTimeMillis();
		Random r = new Random();
		if(npc instanceof Animal){
			Animal a = (Animal) npc;
			
			int dex = a.getDexterityModifier();
			
			switch(currentState){
				case left:
					if (!againstWall(a,0)) {
						moveLeft(a);
						
					} else if(enemyIsNear(a)){
						currentState = State.right;
					} else {
						jump(a);
						//if(debug) System.out.println("Jump Left");
						LostHope.debugManager.printDebug("wolfai", "Jump Left");
						moveLeft(a);
					}
					
					if (r.nextDouble()>.99){
						//if(debug) System.out.println("Random change right");
						LostHope.debugManager.printDebug("wolfai", "Random Change Right");
						currentState = State.right;
					}
					break;
				case right:
					if (!againstWall(a,0)) {
						moveRight(a);
						
					} else if(enemyIsNear(a)){
						currentState = State.left;
					} else {
						jump(a);
						//if(debug) System.out.println("Jump Right");
						LostHope.debugManager.printDebug("wolfai", "Jump Right");
						moveRight(a);
					}
					
					if (r.nextDouble()>.99){
						//if(debug) System.out.println("Random change left");
						LostHope.debugManager.printDebug("wolfai", "Random Change Left");
						currentState = State.left;
					}
					break;
				case jump:
					jump(a);
					break;
				case runFromEnemy:
					//if(enemyIsLeft()) moveRight(a);
					//else moveLeft(a);
					//if(!enemyIsNear) currentState=State.left;
					break;
				case attackEnemy:
					//if(enemyIsLeft()) moveLeft(a);
					//else moveRight(a);
					//if(!enemyIsNear(a)) currentState=State.left;
					break;
				case stationary:
					if(newTime - oldTime >=r.nextInt(1000)+1000) {
						//if(debug) System.out.println("This code should not be called");
						LostHope.debugManager.printDebug("wolfai", "This code should not be called");
						oldTime = System.currentTimeMillis();
						int mod = r.nextInt(3);
						if (mod == 0) {
							currentState = State.left;
						} else if (mod == 1) {
							currentState = State.right;
						} else {
							currentState = State.stationary;
						}						
					}
					break;
			}
		}
		
		

		/*if (newTime - oldTime >= 2000) {
			oldTime = System.currentTimeMillis();
						
			int mod = r.nextInt(4);
			
			if(mod == 0){
				currentState = State.left;
			}else if(mod == 1){
				currentState = State.right;
			} else if(mod==2){
				currentState = State.stationary;
			} else if(mod==3) {
				currentState = State.jump;
			}			
		}*/
	}


	@Override
	public void moveLeft(NPC npc) {
		npc.setXSpeed(-1.5*dex-1);
		// TODO Auto-generated method stub

	}

	@Override
	public void moveRight(NPC npc) {
		npc.setXSpeed(1.5*dex+1);
		// TODO Auto-generated method stub

	}

	@Override
	public void jump(NPC npc) {
		if (isOnGround(npc)) {
			npc.setYSpeed(2*dex);
		}
		// TODO Auto-generated method stub

	}

}
