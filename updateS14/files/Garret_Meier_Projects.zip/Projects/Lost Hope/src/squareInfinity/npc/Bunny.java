package squareInfinity.npc;

import java.awt.Graphics;

import squareInfinity.Location;
import squareInfinity.NPC;

public class Bunny extends Animal {
	
	public static final int[] BASESTATS = new int[] {1,5,7,10,4,3,1};//order is damage, dexterity, health, size, stamina, strength, variability
	
	public Bunny(String name, int x, int y, Location holder) {
		super(name,NPC.BUNNY,x,y,BASESTATS[3],BASESTATS[3],holder);
		this.setAI(new BunnyAI());
		this.width  = this.size;
		this.height = this.size;
	}
	
	@Override
	public void trueDraw(Graphics g) {
		
		if(isRight){
			g.drawImage(NPCImage[BUNNY],(int)x,(int)y,this.width,this.height, null);
		}else{
			g.drawImage(NPCImageFlipped[BUNNY], (int)x, (int)y, this.width, this.height, null);
		}
	}

}
