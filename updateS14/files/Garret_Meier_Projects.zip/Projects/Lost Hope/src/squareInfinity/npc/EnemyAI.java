package squareInfinity.npc;

import java.util.Random;

import squareInfinity.NPC;

public class EnemyAI extends AI {
	protected double pastTime;

	@Override
	public void doSomething(NPC npc) {
		Random r = new Random();
		int i = r.nextInt(10);
		if(i == 0){
			this.moveLeft(npc);
		}else if(i == 1){
			this.moveRight(npc);
		}else if(i == 2){
			this.jump(npc);
		}
	}

	@Override
	public void moveLeft(NPC npc) {
		double currentTime = System.nanoTime();
		
		double dif = currentTime - pastTime;
		
		if(dif >= 1000000000.0){
			npc.increaseXSpeed(-1);
			//System.err.println("jumping");
			npc.setXSpeed(-1);
			
			pastTime = System.nanoTime();
		}
	}

	@Override
	public void moveRight(NPC npc) {
		double currentTime = System.nanoTime();
		
		double dif = currentTime - pastTime;
		
		if(dif >= 1000000000.0){
			npc.increaseXSpeed(1);
			//System.err.println("jumping");
			npc.setXSpeed(1);
			pastTime = System.nanoTime();
		}
	}

	@Override
	public void jump(NPC npc) {
		double currentTime = System.nanoTime();
		
		double dif = currentTime - pastTime;
		
		if(dif >= 1000000000.0){
			npc.setYSpeed(-3);
			//System.err.println("jumping");
			
			pastTime = System.nanoTime();
		}
	}

}
