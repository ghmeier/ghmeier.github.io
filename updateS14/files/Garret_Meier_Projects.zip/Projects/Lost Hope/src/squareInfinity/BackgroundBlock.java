package squareInfinity;


@SuppressWarnings("serial")
public class BackgroundBlock extends GameBlock {

	public BackgroundBlock(byte type, int x, int y, int width, int height) {
		super(type, x, y, width, height);
		collides=false;
	}

	public BackgroundBlock(byte type, int x, int y){
		super(type, x, y);
		collides=false;
	}

}
