package squareInfinity;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Iterator;

import squareInfinity.kdtree.KDTree;

public class Chunk{
	
	public static final int CHUNKSIZE = 1024;
	
	
	private KDTree<GameObject> tree;
	
	private int x;
	private int y;
	
	private boolean generating;
	private ArrayWrapper tempArr;
	
	public Chunk(int x, int y){
		
		this.x = x;
		this.y = y;
		
		tree = new KDTree<GameObject>(4, true);
	}
	
	public int getX(){
		return this.x;
	}
	
	public int getY(){
		return this.y;
	}
	
	public void add(GameObject object){
		if(generating) tempArr.add(object);
		else tree.add(getRect(object), object);
	}
	
	public void remove(GameObject object){
		if(generating) tempArr.remove(object);
		else tree.remove(getRect(object));
	}
	
	//Remove all blocks containing the point
	public void remove(int x, int y){
		if(generating) tempArr.remove(x, y);
		else{
			Iterator<GameObject> i = tree.searchContaining(new int[]{x, y}).iterator();
			while(i.hasNext()) tree.remove(getRect(i.next()));
		}
	}
	
	public GameObject get(int x, int y){
		if(generating){
			Collection<GameObject> l=tempArr.get(x, y);
			return l.isEmpty()?null:l.iterator().next();
		}
		return tree.get(new int[]{x, y, x+LostHope.BLOCKSIDE, y+LostHope.BLOCKSIDE});
	}
	
	public Collection<GameObject> getObjectsAt(int x, int y){
		if(generating){
			Collection<GameObject> objects=new ArrayDeque<GameObject>(64);
			for(int a=x-LostHope.BLOCKSIDE+1; a<=x; a++) for(int b=y-LostHope.BLOCKSIDE+1; b<=y; b++){
				Collection<GameObject> l=tempArr.get(a, b);
				if(l!=null&&!l.isEmpty()) objects.addAll(l);
			}
			return objects;
		}
		/*Collection<GameObject> r=new ArrayDeque<GameObject>();
		for(GameObject o:tree){
			if(x>=o.x&&x<=o.x+o.width&&y>=o.y&&y<=o.y+o.height) r.add(o);
		}
		return r;*/
		return tree.searchContaining(new int[]{x,y});
	}
	
	public boolean contains(int x, int y){
		if(generating) return tempArr.get(x, y)!=null;
		else return !tree.searchContaining(new int[]{x, y}).isEmpty();
	}
	
	public Collection<GameObject> getObjectsBetween(int startX, int startY,
			int stopX, int stopY) {
		if(generating){
			Collection<GameObject> objects=new ArrayDeque<GameObject>(64);
			for(int x=startX-LostHope.BLOCKSIDE+1; x<=stopX; x++) for(int y=startY-LostHope.BLOCKSIDE+1; y<=stopY; y++){
				Collection<GameObject> l=tempArr.get(x, y);
				if(l!=null&&!l.isEmpty()) objects.addAll(l);
			}
			return objects;
		}else return tree.searchRange(new int[]{startX, startY}, new int[]{stopX, stopY});
	}
	
	public void finishGenerating(){
		if(generating){
			generating=false;
			tree.addAll(tempArr.getKDCollection(tree));
			tempArr=null;
		}
	}
	
	public void startGenerating(){
		generating=true;
		tempArr=new ArrayWrapper();
	}
	
	public int treeBalance(){
		return tree.maxHeight()-tree.minHeight();
	}
	
	private int[] getRect(GameObject o){
		return new int[]{o.x, o.y, o.x+o.width, o.y+o.height};
	}
	
	private class ArrayWrapper{
		private Collection<GameObject>[][] array;
		private int size;
		@SuppressWarnings("unchecked")
		private ArrayWrapper(){
			array=new Collection[CHUNKSIZE][CHUNKSIZE];
		}
		public Collection<GameObject> get(int x, int y) {
			x-=Chunk.this.x;
			y-=Chunk.this.y;
			if(GameFactory.inBounds(array, x, y))
				return array[x][y];
			return null;
		}
		private void add(GameObject o){
			final int x=o.x-Chunk.this.x;
			final int y=o.y-Chunk.this.y;
			if(GameFactory.inBounds(array, x, y)){
				if(array[x][y]==null) array[x][y]=new ArrayDeque<GameObject>(4);
				if(array[x][y].add(o)) size++;
			}
		}
		private void remove(GameObject o){
			final int x=o.x-Chunk.this.x;
			final int y=o.y-Chunk.this.y;
			if(GameFactory.inBounds(array, x, y))
				if(array[x][y]!=null) if(array[x][y].remove(o)) size--;
		}
		private void remove(int x, int y){
			x-=Chunk.this.x;
			y-=Chunk.this.y;
			if(GameFactory.inBounds(array, x, y)&&array[x][y]!=null){
				size-=array[x][y].size();
				array[x][y].clear();
			}
		}
		private Collection<KDTree<GameObject>.KDEntry> getKDCollection(KDTree<GameObject> t){
			Collection<KDTree<GameObject>.KDEntry> objects=new ArrayDeque<KDTree<GameObject>.KDEntry>(size*2);
			for(Collection<GameObject>[] x:array) for(Collection<GameObject> y:x) if(y!=null) 
				for(GameObject o:y){
					objects.add(t.new KDEntry(new int[]{o.x, o.y, o.x+o.width, o.y+o.height}, o));
				}
			return objects;
		}
	}

}
