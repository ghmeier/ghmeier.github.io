package squareInfinity;

import java.util.StringTokenizer;

public class Equasion {
	
	private String equasion;
	
	
	public Equasion(String equasion){
		this.equasion = equasion;
	}
	
	public double solveAtX(double x){
		double finalValue = 0;
		
		StringTokenizer equasionBreaker = new StringTokenizer(this.equasion, "()");
		
		// check for parenthesis first
		
		
		
		
		return finalValue;
		
	}

}
