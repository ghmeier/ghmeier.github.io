package squareInfinity;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.security.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TimeZone;

public class DebugManager {
	
	private HashMap<String, Boolean> profiles;
	
	private File logFile;
	private BufferedWriter fileWriter;
	
	private boolean override;
	
	public DebugManager(){
		this.profiles = new HashMap<String, Boolean>();
		
		this.override = false;
		
		logFile = new File("debugLog.txt");
		try {
			fileWriter = new BufferedWriter(new FileWriter(logFile));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public boolean isOverridden(){
		return this.override;
	}
	
	public void setOverride(boolean override){
		this.override = override;
	}
	
	public void printError(String profileName, String output){
		printError(profileName, output, false);
	}
	
	public void printDebug(String profileName, String output){
		printDebug(profileName, output, false);
	}
	
	public void printError(String profileName, String output, boolean log){
		if(!override){
			if(profiles.get(profileName)){
				System.err.println(output);
			}
			if(log){
				logData(output, true);
			}
		}
	}
	
	public void printDebug(String profileName, String output, boolean log){
		if(!override){
			if(profiles.get(profileName)){
				System.out.println(output);
			}
			
			if(log){
				logData(output, false);
			}
		}
	}
	
	private void logData(String output, boolean error){
		if(fileWriter != null){
			String finalOutput = "";
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd G 'at' hh:mm:ss z");
			
			String time = sdf.format(cal.getTime());
			
			if(error){
				finalOutput = time + ":ERROR: <<" + output + ">>";
			}else{
				finalOutput = time + ": <<" + output + ">>";
			}
			
		}
	}
	
	public void addProfile(String profileName){
		this.profiles.put(profileName, true);
	}
	
	public void setProfile(String profileName, boolean output){
		if(this.profiles.containsKey(profileName)){
			this.profiles.put(profileName, output);
		}
	}
	
	public void removeProfile(String profileName){
		this.profiles.remove(profileName);
	}
	
	public boolean hasProfile(String profileName){
		return this.profiles.containsKey(profileName);
	}
	
	public void setAllProfiles(boolean output){
		Set<String> keySet = profiles.keySet();
		
		Iterator<String> keysIterator = keySet.iterator();
		
		while(keysIterator.hasNext()){
			String currentKey = keysIterator.next();
			
			this.profiles.put(currentKey, output);
		}
	}

}
