package squareInfinity;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Door extends GameObject implements InteractibleObject{

	public static BufferedImage DOOR_CLOSED_IMAGE = null;
	public static BufferedImage DOOR_OPEN_IMAGE = null;
	
	private boolean isOpen;
	
	public Door(int x, int y) {
		super(x, y, (byte) 0);
		
		this.setWidth(16);
		this.setHeight(32);
		
		this.isOpen = false;
	}
	
	public static void loadDoorImages(){
		File openFile = new File("Pic/Tiles/Interacting/openDoor.png");
		File closedFile = new File("Pic/Tiles/Interacting/closedDoor.png");
		
		try{
			DOOR_CLOSED_IMAGE = ImageIO.read(closedFile);
			DOOR_OPEN_IMAGE = ImageIO.read(openFile);
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
	}
	
	@Override
	public void clickedOn(LostHope controller){
		this.isOpen = !this.isOpen;
		
		if(this.isOpen){
			this.collides = false;
		}else{
			this.collides = true;
		}
	}
	
	public boolean isOpen(){
		return this.isOpen;
	}
	
	public void setIsOpen(boolean isOpen){
		this.isOpen = isOpen;
	}

	@Override
	public void setPower(int power) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void magicExplode(LostHope controller, int power) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void toggleHold(boolean isHeld) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public MagicPrimitive createCopyOfSelf() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void drawSelf(Graphics g, int xOffset, int yOffset) {
		if(this.isOpen){
			g.drawImage(DOOR_OPEN_IMAGE, this.x + xOffset, this.y + yOffset,null);
		}else{
			g.drawImage(DOOR_CLOSED_IMAGE, this.x + xOffset, this.y + yOffset, null);
		}
	}

	@Override
	public byte isObjectWithin(PhysicsObject object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void forceApplied(double force, LostHope controller) {
		// TODO Auto-generated method stub
		
	}

}
