package squareInfinity;

import java.awt.Dimension;
import java.awt.Image;
import java.util.ArrayList;

public class PrimitiveItem extends InventoryItem{

	private Dimension handPoint;
	
	private boolean rotates;
	
	private int damage;
	private int reach;
	
	private boolean[][] snapPoints;
	private ArrayList<Dimension> foundSnapPoints;
	
	public PrimitiveItem(String name, int width, int height, int weight, int damage, int reach, Dimension handPoint, Image icon, boolean rotates) {
		super(name, weight);
		
		this.snapPoints = new boolean[width][height];
		
		this.icon = icon;
		this.damage = damage;
		this.reach = reach;
		this.handPoint = handPoint;
		this.rotates = rotates;
	}
	
	public void collectSnapPoints(){
		foundSnapPoints = new ArrayList<Dimension>();
		
		for(int x=0; x<snapPoints.length; x++){
			for(int y=0; y<snapPoints[0].length; y++){
				if(snapPoints[x][y]){
					foundSnapPoints.add(new Dimension(x,y));
				}
			}
		}
	}
	
	public ArrayList<Dimension> getAllSnapPoints(){
		return this.foundSnapPoints;
	}
	
	public void finalize(){
		collectSnapPoints();
	}
	
	public int getDamage(){
		return this.damage;
	}
	
	public boolean isSnapPoint(int x, int y){
		return snapPoints[x][y];
	}
	
	public void setSnapPoint(int x, int y){
		this.snapPoints[x][y] = true;
	}
	
	public int getReach(){
		return this.reach;
	}
	
	public Dimension getHandPoint(){
		return this.handPoint;
	}
	
	public boolean doesRotate(){
		return this.rotates;
	}

}
