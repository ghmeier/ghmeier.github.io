package squareInfinity;

import java.awt.Color;
import java.awt.Graphics;


public class Particle extends PhysicsObject{
	
	protected byte type;
	
	public Particle(double x, double y, byte type){
		super(x,y,2,2, .9);
		
		this.type = type;
	}
	
	public void drawSelf(Graphics g){
		Color selectedColor = ObjectData.getColorForType(this.type);
		g.setColor(selectedColor);
		
		g.fillRect((int)x, (int)y, 2, 2);
	}
	
	public byte getType(){
		return this.type;
	}

	@Override
	public void setPower(int power) {
		// TODO set power does nothing for particle
	}

	@Override
	public void magicExplode(LostHope controller, int power) {
		// TODO explode does nothing for particle
	}

	@Override
	public MagicPrimitive createCopyOfSelf() {
		Particle p = LostHope.factory.createParticle(this.x, this.y, this.type);
		
		return p;
	}

}