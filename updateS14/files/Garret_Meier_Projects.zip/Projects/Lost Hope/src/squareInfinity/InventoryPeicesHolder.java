package squareInfinity;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;

public class InventoryPeicesHolder extends InventoryItem{

	protected byte type;
	
	protected int count;
	
	public InventoryPeicesHolder(String name, byte type, int weight) {
		super(name, weight);
		
		this.count = 1;
		this.type = type;
		this.icon = ObjectData.getImageForType(type);
	}

	public void increaseCount(){
		this.count = this.count + 1;
	}
	
	public int getCount(){
		return this.count;
	}
	
	public void setCount(int count){
		this.count = count;
	}
	
	public byte getType(){
		return this.type;
	}
	
	@Override
	public void drawSelfInInventory(Graphics g, int x, int y, boolean mouseOver){
		
		if(mouseOver){
			g.setColor(Color.YELLOW);
			g.drawRect(x, y, 16, 16); // all inventory items are drawn in 16-bit size, even on the field, at least right now
			g.setColor(Color.WHITE);
			
			String finalName = this.name + ", x" + this.count;
			
			FontMetrics fm = g.getFontMetrics();
			int length = fm.stringWidth(finalName);
			
			
			g.fillRect(x, y - 11, length + 1, 12);
			g.setColor(Color.BLACK);
			g.drawString(finalName, x + 1, y);
		}else{
			// no surrounding prettyness
			if(isBeingDragged){
				g.setColor(Color.WHITE);
				
				FontMetrics fm = g.getFontMetrics();
				int length = fm.stringWidth(this.name);
				
				
				g.fillRect(x, y - 11, length + 1, 12);
				g.setColor(Color.BLACK);
				g.drawString(this.name, x + 1, y);
			}
		}
		
		if(icon == null){
//			g.setColor(ObjectData.getColorForType(this.type));
//			g.fillRect(x + 2, y + 2, 12, 12);
			
			Image imageToDraw = ObjectData.getImageForType(this.type);
			
			if(imageToDraw == null){
				g.drawImage(ObjectData.getImageForType(this.type), x + 2, y + 2, null);
			}else{
				g.setColor(ObjectData.getColorForType(this.type));
				g.fillRect(x + 2, y + 2, ObjectData.invSize, ObjectData.invSize);
			}
			
			
		}else{
			g.drawImage(ObjectData.getImageForType(this.type),x,y,null);
		}
	}

}
