package squareInfinity;

public abstract class TerrainType {

	protected int getNegative(int input) {
		if (WorldGenerator.theRandomizer.nextDouble()<=.5) {
			return -input;
		} else {
			return input;
		}
	}
	
	public abstract int getModifier();
}
