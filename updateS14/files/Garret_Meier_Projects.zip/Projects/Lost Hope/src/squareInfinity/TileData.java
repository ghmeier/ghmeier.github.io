package squareInfinity;
import java.awt.Color;
import java.util.HashSet;
import java.util.Iterator;


public class TileData {
	
	public static HashSet<TileData> data = new HashSet<TileData>();
	public static final TileData defaultData = new TileData(0, Color.BLACK);
	
	protected int type;
	protected Color color;
	
	public TileData(int type, Color color){
		this.type = type;
		this.color = color;
	}
	
	public Color getColor(){
		return this.color;
	}
	
	public int getType(){
		return this.type;
	}
	
	public static TileData findTileDataByType(int type){
		Iterator<TileData> dataIterator = data.iterator();
		
		while(dataIterator.hasNext()){
			TileData tempData = dataIterator.next();
			
			if(tempData.getType() == type){
				return tempData;
			}
		}
		
		return defaultData;
	}

}
