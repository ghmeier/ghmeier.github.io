package squareInfinity;

import java.awt.Color;
import java.awt.Image;
import java.io.IOException;

public class ObjectData { // mostly w/ static methods, this class deals with items
	
	///// RESOURCE TYPES
	
	public static final byte DIRT = 1;
	public static final byte STONE = 2;
	public static final byte CLAY = 3;
	public static final byte IRON = 4;
	public static final byte COAL = 5;
	public static final byte GOLD = 6;
	public static final byte DIAMOND = 7;
	public static final byte MITHRIL = 8;	
	public static final byte ADAMANTINE = 9;
	public static final byte BROWN_AGATE = 10;
	public static final byte GARNET = 11;
	public static final byte COPPER = 12;
	public static final byte TIN = 13;
	public static final byte OAK = 14;
	public static final byte LEAF = 15;
	public static final byte SAND = 16;
	public static final byte MARBLE = 17;
	public static final byte GRANITE = 18;
	public static final byte SANDSTONE = 19;
	public static final byte BIRCH_WOOD = 20;
	public static final byte URANIUM = 21;
	public static final byte AMETHYST = 22;
	public static final byte ONYX = 23;
	public static final byte BERYL = 24;
	public static final byte SERAPHINITE = 25;
	public static final byte RED_FLOWER = 26;
	public static final byte YELLOW_FLOWER = 27;
	public static final byte  WORKBENCH = 28;
	public static final byte  BED = 29;
	public static final byte  CHAIR = 30;
	public static final byte  TABLE = 31;
	public static final byte  CHEST = 32;
	public static final byte  STONE_WALL = 33;
	public static final byte  STONE_BLOCK = 34;
	public static final byte  WOOD_STAIRS = 35;
	public static final byte  WOOD_PLANK = 36;
	public static final byte ANVIL = 37;
	public static final byte FURNACE = 38;
	public static final byte LADDER = 39;
	public static final byte SAPLING = 40;
	public static final byte GRASS = 41;
	public static final byte DOOR = 42;
	public static final byte CACTUS = 43;
	
	public static final byte WATER = 100;
	public static final byte LAVA = 101;
	
	/////
	public static Image[] icons;

	private static final String ICON_LOCATION = "Pic/InventoryIcons/";
	
	private static final String DIRT_FILE = ICON_LOCATION + "DirtInv.png";
	private static final String STONE_FILE = ICON_LOCATION + "StoneInv.png";
	private static final String IRON_FILE = ICON_LOCATION + "IronInv.png";
	private static final String ADAMANTINE_FILE = ICON_LOCATION + "AdamantineInv.png";
	private static final String COAL_FILE = ICON_LOCATION + "CoalInv.png";
	private static final String GOLD_FILE = ICON_LOCATION + "GoldInv.png";
	private static final String DIAMOND_FILE = ICON_LOCATION + "DiamondInv.png";
	private static final String MITHRIL_FILE = ICON_LOCATION + "MithrilInv.png";
	private static final String BROWN_AGATE_FILE = ICON_LOCATION + "BrownAgateInv.png";
	private static final String GARNET_FILE = ICON_LOCATION + "GarnetInv.png";
	private static final String OAK_FILE = ICON_LOCATION +  "OakInv.png";
	private static final String LEAF_FILE = ICON_LOCATION + "LeafInv.png";
	private static final String COPPER_FILE = ICON_LOCATION + "CopperInv.png";
	private static final String TIN_FILE = ICON_LOCATION + "TineInv.png";
	private static final String SAND_FILE = ICON_LOCATION + "SandInv.png";
	private static final String MARBLE_FILE = ICON_LOCATION + "MarbleInv.png";
	private static final String GRANITE_FILE = ICON_LOCATION + "GraniteInv.png";
	private static final String SANDSTONE_FILE = ICON_LOCATION + "SandstoneInv.png";
	private static final String BIRCH_WOOD_FILE = ICON_LOCATION + "BirchWoodInv.png";
	private static final String URANIUM_FILE = ICON_LOCATION + "UraniumInv.png";
	private static final String AMETHYST_FILE = ICON_LOCATION + "AmethystInv.png"; 
	private static final String ONYX_FILE = ICON_LOCATION + "OnyxInv.png"; 
	private static final String BERYL_FILE = ICON_LOCATION + "BerylInv.png";
	private static final String SERAPHINITE_FILE = ICON_LOCATION + "SeraphiniteInv.png";
	private static final String RED_FLOWER_FILE = "Pic/Plants/RedFlower.png";
	private static final String YELLOW_FLOWER_FILE = "Pic/Plants/YellowFlower.png";
	private static final String WORKBENCH_FILE = "Pic/Tiles/Finals/"+"WorkBench.png";
	private static final String BED_FILE = "Pic/Tiles/Finals/"+"Bed.png";
	private static final String CHAIR_FILE = "Pic/Tiles/Finals/"+"Chair.png";
	private static final String TABLE_FILE = "Pic/Tiles/Finals/"+"Table.png";
	private static final String CHEST_FILE = "Pic/Tiles/Finals/"+"Chest.png";
	private static final String STONE_WALL_FILE = "Pic/Tiles/Finals/"+"StoneWall.png";
	private static final String STONE_BLOCK_FILE = "Pic/Tiles/Finals/"+"StoneBlock.png";
	private static final String WOOD_STAIRS_FILE = "Pic/Tiles/Finals/"+"WoodStairs.png";
	private static final String WOOD_PLANK_FILE = "Pic/Tiles/Finals/"+"WoodPlank.png";
	private static final String ANVIL_FILE = "Pic/Tiles/Finals/"+"Anvil.png";
	private static final String FURNACE_FILE = "Pic/Tiles/Finals/"+"Furnace.png";
	private static final String LADDER_FILE = "Pic/Tiles/Finals/"+"Ladder.png";
	private static final String SAPLING_FILE = "Pic/Tiles/Finals/"+"Sapling.png";
	private static final String GRASS_FILE = "Pic/Tiles/Finals/" + "Grass.png";
	private static final String CACTUS_FILE = "Pic/Tiles/FInals/" + "Cactus.png";
		
	
	public static int invSize=14;
	
	public byte type;
	
	public static void initImages() throws IOException{
		icons=new Image[44];


		icons[DIRT]=GameFactory.getOptimizedImage(invSize,invSize,DIRT_FILE);
		icons[IRON]=GameFactory.getOptimizedImage(invSize,invSize,IRON_FILE);
		icons[STONE]=GameFactory.getOptimizedImage(invSize,invSize,STONE_FILE);
		icons[ADAMANTINE]=GameFactory.getOptimizedImage(invSize,invSize,ADAMANTINE_FILE);
		icons[COAL]=GameFactory.getOptimizedImage(invSize,invSize,COAL_FILE);
		icons[GOLD]=GameFactory.getOptimizedImage(invSize,invSize,GOLD_FILE);
		icons[DIAMOND]=GameFactory.getOptimizedImage(invSize,invSize,DIAMOND_FILE);
		icons[MITHRIL]=GameFactory.getOptimizedImage(invSize,invSize,MITHRIL_FILE);
		icons[BROWN_AGATE]=GameFactory.getOptimizedImage(invSize,invSize,BROWN_AGATE_FILE);
		icons[GARNET]=GameFactory.getOptimizedImage(invSize,invSize,GARNET_FILE);
		icons[OAK]=GameFactory.getOptimizedImage(invSize,invSize,OAK_FILE);
		icons[LEAF]=GameFactory.getOptimizedImage(invSize,invSize,LEAF_FILE);
		icons[COPPER]=GameFactory.getOptimizedImage(invSize,invSize,COPPER_FILE);
		icons[TIN]=GameFactory.getOptimizedImage(invSize,invSize,TIN_FILE);
		icons[SAND] = GameFactory.getOptimizedImage(invSize,invSize,SAND_FILE);
		icons[MARBLE] = GameFactory.getOptimizedImage(invSize,invSize,MARBLE_FILE);
		icons[GRANITE] = GameFactory.getOptimizedImage(invSize,invSize,GRANITE_FILE);
		icons[SANDSTONE] = GameFactory.getOptimizedImage(invSize,invSize,SANDSTONE_FILE);
		icons[BIRCH_WOOD] = GameFactory.getOptimizedImage(invSize,invSize,BIRCH_WOOD_FILE);
		icons[URANIUM] = GameFactory.getOptimizedImage(invSize,invSize,URANIUM_FILE);
		icons[AMETHYST] = GameFactory.getOptimizedImage(invSize,invSize,AMETHYST_FILE);
		icons[ONYX] = GameFactory.getOptimizedImage(invSize,invSize,ONYX_FILE);
		icons[BERYL] = GameFactory.getOptimizedImage(invSize,invSize,BERYL_FILE);
		icons[SERAPHINITE] = GameFactory.getOptimizedImage(invSize,invSize,SERAPHINITE_FILE);
		icons[RED_FLOWER] = GameFactory.getOptimizedImage(invSize,invSize,RED_FLOWER_FILE);
		icons[YELLOW_FLOWER] = GameFactory.getOptimizedImage(invSize,invSize,YELLOW_FLOWER_FILE);
		icons[WORKBENCH] = GameFactory.getOptimizedImage(invSize,invSize,WORKBENCH_FILE);
		icons[BED] = GameFactory.getOptimizedImage(invSize,invSize,BED_FILE);
		icons[TABLE] = GameFactory.getOptimizedImage(invSize,invSize,TABLE_FILE);
		icons[CHEST] = GameFactory.getOptimizedImage(invSize,invSize,CHEST_FILE);
		icons[CHAIR] = GameFactory.getOptimizedImage(invSize,invSize,CHAIR_FILE);
		icons[STONE_WALL] = GameFactory.getOptimizedImage(invSize,invSize,STONE_WALL_FILE);
		icons[STONE_BLOCK] = GameFactory.getOptimizedImage(invSize,invSize,STONE_BLOCK_FILE);
		icons[WOOD_STAIRS] = GameFactory.getOptimizedImage(invSize,invSize,WOOD_STAIRS_FILE);
		icons[WOOD_PLANK] = GameFactory.getOptimizedImage(invSize,invSize,WOOD_PLANK_FILE);
		icons[ANVIL] = GameFactory.getOptimizedImage(invSize,invSize,ANVIL_FILE);
		icons[FURNACE] = GameFactory.getOptimizedImage(invSize,invSize,FURNACE_FILE);
		icons[LADDER] = GameFactory.getOptimizedImage(invSize,invSize,LADDER_FILE);
		icons[SAPLING] = GameFactory.getOptimizedImage(invSize,invSize,SAPLING_FILE);
		icons[GRASS] = GameFactory.getOptimizedImage(invSize,invSize,GRASS_FILE);
		icons[CACTUS] = GameFactory.getOptimizedImage(invSize,invSize,CACTUS_FILE);

	}
	
	public ObjectData(byte type){
		this.type = type;
	}
	
	//// STATIC METHODS
	
	public static Color getColorForType(byte type){ // will eventually read from some file...
		if(type == DIRT){
			return new Color(128,64,0);
		}else if(type == STONE){
			return new Color(160,160,160);
		}else if(type == CLAY){
			return new Color(255, 128, 64);
		}else if(type == IRON){
			return new Color(140,109,44);
		}else if(type == ADAMANTINE){
			return new Color(0,128,78);
		}else if(type == COAL) {
			return Color.BLACK;
		}else if(type == GOLD) {
			return new Color(255,216,0);
		}else if(type==DIAMOND) {
			return new Color(15,242,242);
		}else if(type==MITHRIL) {
			return new Color(51,62,127);
		}else if(type == COPPER) {
			return new Color(142,66,15);
		}else if(type== TIN) {
			return new Color(192,192,192);
		}else if(type == WATER){
			return new Color(0,0,100);
		}else if(type== BROWN_AGATE) {
			return new Color(188,98,37);
		}else if(type==GARNET){
			return new Color(239,43,0);
		}else if(type==OAK) {
			return new Color(135,72,0);
		}else if(type==LEAF) {
			return new Color(21,125,79);
		}else if(type==SAND) {
			return new Color(255,180,95);
		}else if(type==MARBLE){
			return new Color(255,255,255);
		}else if(type==GRANITE) {
			return new Color(255,162,105);
		}else if (type== SANDSTONE){
			return new Color(255,208,131);
		}else if (type== BIRCH_WOOD) {
			return new Color(204,204,204);
		}else if(type==URANIUM) {
			return new Color(117,255,96);
		}else if(type==AMETHYST) {
			return new Color (178,0,255);
		}else if(type==ONYX) {
			return new Color (53,53,53);	
		}else if(type==BERYL) {
			return new Color (35,255,141);
		}else if(type==SERAPHINITE) {
			return new Color (0,127,84);
		}else if(type==RED_FLOWER) {
			return new Color(255,0,0);
		}else if(type==YELLOW_FLOWER) {
			return new Color(255,216,0);
		}else if(type==WORKBENCH) {
			return new Color(125,66,27);
		}else if(type==BED) {
			return new Color(125,66,27);
		}else if(type==CHAIR) {
			return new Color(125,66,27);
		}else if(type==TABLE) {
			return new Color(125,66,27);
		}else if(type==CHEST) {
			return new Color(125,66,27);
		}else if(type==STONE_WALL) {
			return new Color(160,160,160);
		}else if(type==STONE_BLOCK) {
			return new Color(160,160,160);
		}else if(type==WOOD_STAIRS) {
			return new Color(125,66,27);
		}else if(type==WOOD_PLANK) {
			return new Color(125,66,27);
		}else if(type==ANVIL) {
			return new Color(118,118,118);
		}else if(type==FURNACE) {
			return new Color(48,48,48);
		}else if(type==LADDER) {
			return new Color(125,66,27);
		}else if(type==SAPLING) {
			return new Color(21,125,79);
		}else if(type==CACTUS) {
			return new Color(31,150,22);
		}else{
			
			return Color.PINK;
		}
	}
	
	public static Image getImageForType(byte type){ // will eventually read from some file...
		if(!(type >= icons.length) &&icons[type] != null){
			return icons[type];
		}else{
			return null;
		}
	}
	
	public static String getNameForType(byte type){
		if(type == DIRT){
			return "Dirt";
		}else if(type == STONE){
			return "Stone Piece";
		}else if(type == CLAY){
			return "Clay Piece";
		}else if(type == IRON){
			return "Iron Piece";
		}else if(type == COAL){
			return "Coal Chunk";
		}else if(type == GOLD){
			return "Gold Nugget";
		}else if(type == DIAMOND){
			return "Diamond Chunk";
		}else if(type == MITHRIL){
			return "Mithril Chunk";
		}else if(type == BROWN_AGATE){
			return "Brown Agate Shard";
		}else if(type == GARNET){
			return "Garnet Shard";
		}else if(type == ADAMANTINE){
			return "Adamantine Shard";
		}else if(type==COPPER) {
			return "Copper Chunk";
		}else if(type==TIN){
			return "Tin Chunk";
		}else if(type == WATER){
			return "Water";
		}else if(type==OAK) {
			return "Oak Wood Piece";
		}else if(type==LEAF) {
			return "Leaf";
		}else if(type==SAND) {
			return "Sand Pile";
		}else if(type==MARBLE){
			return "Marble Chunk";
		}else if(type==GRANITE) {
			return "Granite Chunk";
		} else if (type==SANDSTONE) {
			return "Sandstone Chunk";
		} else if (type==BIRCH_WOOD) {
			return "Birch Wood Piece";
		}else if(type==URANIUM) {
			return "Uranium Chunk";
		}else if(type==AMETHYST) {
			return "Amethyst Shard";
		}else if(type==ONYX) {
			return "Onyx Shard";
		}else if(type==BERYL) {
			return "Beryl Shard";
		}else if(type == SERAPHINITE) {
			return "Seraphinite Shard";
		}else if(type==RED_FLOWER) {
			return "Red Flower Petal";
		}else if(type==YELLOW_FLOWER) {
			return "Yellow Flower Petal";
		}else if(type==WORKBENCH) {
			return"Workbench";
		}else if(type==BED) {
			return"Bed";
		}else if(type==CHAIR) {
			return"Chair";
		}else if(type==TABLE) {
			return"Table";
		}else if(type==CHEST) {
			return"Chest";
		}else if(type==STONE_WALL) {
			return"Stone Wall";
		}else if(type==STONE_BLOCK) {
			return"Stone Block";
		}else if(type==WOOD_STAIRS) {
			return"Wood Stairs";
		}else if(type==WOOD_PLANK) {
			return"Wood Plank";
		}else if(type==ANVIL) {
			return "Anvil";
		}else if(type==FURNACE) {
			return "Furnace";
		}else if(type==LADDER) {
			return "Ladder";
		}else if(type==SAPLING) {
			return "Sapling";
		}else if(type==CACTUS) {
			return "Cactus Lump";
		}else{
			return "Nothing"; // return nothing. ha. haha.
		}
	}
	
	public static int lockToGameGrid(double number){
		return (int) ((number / LostHope.BLOCKSIDE) * LostHope.BLOCKSIDE);
	}
	
	public static GameObject getTopObjectAbove(GameObject block, Chunk chunk){
		GameObject currentBlock = block;
		
		int possibleX = lockToGameGrid(currentBlock.getX() + 1);
		int possibleY = lockToGameGrid(currentBlock.getY() - 15);
		
		while(possibleX >= 0 && possibleY >=0 &&
				possibleX < Chunk.CHUNKSIZE && possibleY < Chunk.CHUNKSIZE && chunk.get(possibleX,possibleY) != null){
			currentBlock = chunk.get(possibleX,possibleY);
			
			possibleX = lockToGameGrid(currentBlock.getX() + 1);
			possibleY = lockToGameGrid(currentBlock.getY() - 15);
		}
		
		
		return currentBlock;
	}
	
	public static GameObject getMostLeftBlock(GameObject block, Chunk chunk){
		GameObject currentBlock = block;
		
		int possibleX = lockToGameGrid(currentBlock.getX() - 15);
		int possibleY = lockToGameGrid(currentBlock.getY() + 1);
		
		while(possibleX >= 0 && possibleY >=0 &&
				possibleX < Chunk.CHUNKSIZE && possibleY < Chunk.CHUNKSIZE && chunk.get(possibleX, possibleY) != null){
			currentBlock = chunk.get(possibleX, possibleY);
			
			possibleX = lockToGameGrid(currentBlock.getX() + 1);
			possibleY = lockToGameGrid(currentBlock.getY() - 15);
		}
		
		
		return block;
	}
	
	public static GameObject getMostRightBlock(GameObject block, Chunk chunk){
		GameObject currentBlock = block;
		
		int possibleX = lockToGameGrid(currentBlock.getX() + 15);
		int possibleY = lockToGameGrid(currentBlock.getY() + 1);
		
		while(possibleX >= 0 && possibleY >=0 &&
				possibleX < Chunk.CHUNKSIZE && possibleY < Chunk.CHUNKSIZE && chunk.get(possibleX,possibleY) != null){
			currentBlock = chunk.get(possibleX, possibleY);
			
			possibleX = lockToGameGrid(currentBlock.getX() + 15);
			possibleY = lockToGameGrid(currentBlock.getY() + 1);
		}
		
		
		return currentBlock;
	}

}
