package squareInfinity;

public class SemiFlat extends TerrainType {
	public int getModifier() {
		double randomNumber = WorldGenerator.theRandomizer.nextDouble();		
		if (randomNumber<=.7) {
			return 0;
		} else if (randomNumber<=.9) {
			return getNegative(1);
		} else {
			return getNegative(2);
		}
	}
}
