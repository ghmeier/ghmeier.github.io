package squareInfinity;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class Location {
	
	private static final int CHUNKS_TO_LOAD_EXTRA = 10; // this should be at least like 4 or so
	
	protected int width;
	protected int height;
	
	protected String name;
	protected String refName;
	
	protected LostHope controller;
	
	protected boolean generating;
	
	protected FileManager fm;
	
	protected Weather currentWeather;
	protected int seaLevel=0;
	
	//GameObject[][] currentObjects;
	//LiquidGameBlock[][] liquidBlocks;
	private Chunk[][] chunks;
	
	private int startChunkX;
	private int startChunkY;
	
	private ArrayList<Particle> particles;
	private Collection<PhysicsObject> physicsObjects;
	private ArrayList<NPC> npcs;
	private Collection<LiquidGameBlock> liquidBlocks;
	
	public Collection<Flora> flowersAndTrees = new HashSet<Flora>();
	public Collection<Grass> grass = new HashSet<Grass>();
	
	public Location(int width, int height, String name, String refName, LostHope controller){
		this.width = width;
		this.height = height;
		
		this.controller = controller;
		
		fm = new FileManager();
		
		this.name = name;
		this.refName = refName;
		
		//currentObjects = new GameBlock[width][height];
		
		chunks = new Chunk[width / Chunk.CHUNKSIZE][height / Chunk.CHUNKSIZE];
		
		for(int x=0; x<chunks.length; x++){
			for(int y=0; y<chunks[0].length; y++){
				chunks[x][y] = new Chunk(x * Chunk.CHUNKSIZE, y * Chunk.CHUNKSIZE);
			}
		}
		
		liquidBlocks = new ArrayDeque<LiquidGameBlock>(1024);
		
		particles = new ArrayList<Particle>();
		physicsObjects = new ArrayDeque<PhysicsObject>(1024);
		npcs = new ArrayList<NPC>();
		
		//Player currentPlayer = controller.getCurrentPlayer();
		
		//int playerX = (int)currentPlayer.getX();
		//int playerY = (int)currentPlayer.getY();
		
//		fm.saveAndUnloadChunks(chunks, 0, 0, chunks.length, chunks[0].length);
//		
//		fm.loadChunks(chunks, 0, 0, chunks.length * Chunk.CHUNKSIZE, chunks[0].length * Chunk.CHUNKSIZE);
		
		//dealWithFileIO(playerX, playerY);
	}
	
//	public GameObject[][] getObjects(){
//		return this.currentObjects;
//	}
	
	public void saveAndUnloadAll(){
		fm.saveAndUnloadChunks(chunks, 0, 0, chunks.length, chunks[0].length);
	}
	
	public void loadAll(){
		fm.loadChunks(chunks, 0, 0, chunks.length * Chunk.CHUNKSIZE, chunks[0].length * Chunk.CHUNKSIZE);
	}
	
	public void setSeaLevel(int l){
		seaLevel=l;
	}
	
	public Chunk[][] getChunks(){
		return this.chunks;
	}
	
//	public LiquidGameBlock[][] getLiquidBlocks(){
//		return this.liquidBlocks;
//	}
	
//	public void addLiquidBlock(LiquidGameBlock block){
//		this.liquidBlocks[block.getX()][block.getY()] = block;
//	}
	
//	public void removeLiquidBlock(LiquidGameBlock block){
//		this.liquidBlocks[block.getX()][block.getY()] = null;
//		
//		//System.out.println("liquid block destroyed");
//	}
	
	public int getWidth(){
		return this.width;
	}
	
	public int getHeight(){
		return this.height;
	}
	
	public int lockToGrid(int gridsize, double number){
		return (int) ((int)number / gridsize) * gridsize;
	}
	
	public void removeObject(GameObject object){
		int x=object.getX();
		int y=object.getY();
		
		int chunkX = x / Chunk.CHUNKSIZE;
		int chunkY = y / Chunk.CHUNKSIZE;
		
		if(this.chunks[chunkX][chunkY] != null){
			Chunk currentChunk = this.chunks[chunkX][chunkY];
			
			currentChunk.remove(object);
		}else{
			//System.err.println("chunk was null");
		}
	}
	
	public Collection<GameObject> getObjectsBetween(int startX, int startY, int endX, int endY){
		int chunkStartX = Math.min(Math.max(startX / Chunk.CHUNKSIZE, 0), chunks.length-1);
		int chunkStartY = Math.min(Math.max(startY / Chunk.CHUNKSIZE, 0), chunks[0].length-1);
		int chunkEndX = Math.min(Math.max(endX / Chunk.CHUNKSIZE, 0), chunks.length-1);
		int chunkEndY = Math.min(Math.max(endY / Chunk.CHUNKSIZE, 0), chunks[0].length-1);

		Collection<GameObject> mainCollection = chunks[chunkStartX][chunkStartY].getObjectsBetween(startX, startY, endX, endY);

		for(int x=chunkStartX; x<=chunkEndX; x++){
			for(int y=chunkStartY; y<=chunkEndY; y++){
				mainCollection.addAll(chunks[x][y].getObjectsBetween(startX, startY, endX, endY));
			}
		}
		
		return mainCollection;
	}
	
	public Collection<GameObject> getCollidingObjectsBetween(int startX, int startY, int endX, int endY){
		
		int chunkStartX = Math.min(Math.max(startX / Chunk.CHUNKSIZE, 0), chunks.length-1);
		int chunkStartY = Math.min(Math.max(startY / Chunk.CHUNKSIZE, 0), chunks[0].length-1);
		int chunkEndX = Math.min(Math.max(endX / Chunk.CHUNKSIZE, 0), chunks.length-1);
		int chunkEndY = Math.min(Math.max(endY / Chunk.CHUNKSIZE, 0), chunks[0].length-1);
		
		//Collection<GameObject> mainCollection = chunks[chunkStartX][chunkStartY].getObjectsBetween(startX, startY, endX, endY);
		Collection<GameObject> mainCollection =new ArrayDeque<GameObject>();
		for(int x=chunkStartX; x<=chunkEndX; x++){
			for(int y=chunkStartY; y<=chunkEndY; y++){
				mainCollection.addAll(chunks[x][y].getObjectsBetween(startX, startY, endX, endY));
			}
		}
		Iterator<GameObject> i=mainCollection.iterator();
		while(i.hasNext()) if(!i.next().collides) i.remove();
		return mainCollection;
	}
	
	public Collection<GameObject> getObjectsAt(int x, int y){
		int chunkX = Math.min(Math.max(x / Chunk.CHUNKSIZE, 0), chunks.length-1);
		int chunkY = Math.min(Math.max(y / Chunk.CHUNKSIZE, 0), chunks[0].length-1);
		
		Chunk selectedChunk = chunks[chunkX][chunkY];
		
		/*int startX = lockToGrid(LostHope.BLOCKSIDE, x + 16);
		int startY = lockToGrid(LostHope.BLOCKSIDE, y + 16);
		int stopX = lockToGrid(LostHope.BLOCKSIDE, x + 32);
		int stopY = lockToGrid(LostHope.BLOCKSIDE, y + 32);
		
		Collection<GameObject> objectsAtPoint = selectedChunk.getObjectsBetween(startX, startY, stopX, stopY);*/
		Collection<GameObject> objectsAtPoint = selectedChunk.getObjectsAt(x, y);
		
		//System.err.println("Size: " + objectsAtPoint.size());
		
		//System.err.println("chunkX:" + selectedChunk.getX());
		return objectsAtPoint;
		/*Iterator<GameObject> objectsIterator = objectsAtPoint.iterator();
		
		if(objectsIterator.hasNext()){
			return objectsIterator.next();
		}else{
			return null;
		}*/
	}
	
	public void addObject(GameObject object){
		
		int x = object.getX();
		int y = object.getY();
		
		if(y-height/4+object.getHeight()>x&&x<width/2) return;
		if(y-height/4+object.getHeight()>width-x&&x>width/2) return;
		
		int chunkX = (int)(x / Chunk.CHUNKSIZE);
		int chunkY = (int)(y / Chunk.CHUNKSIZE);
		if(chunkX<0||chunkX>=chunks.length||chunkY<0||chunkY>=chunks[0].length) return;
		if(this.chunks[chunkX][chunkY] != null){
			Chunk currentChunk = this.chunks[chunkX][chunkY];
			
			currentChunk.add(object);
			if(object instanceof LiquidGameBlock) liquidBlocks.add((LiquidGameBlock)object);
		}else{
			//System.err.println("chunk was null");
			
//			Chunk nextChunk = new Chunk(chunkX * Chunk.CHUNKSIZE, chunkY * Chunk.CHUNKSIZE);
//			
//			chunks[chunkX][chunkY] = nextChunk;
//			
//			chunks[chunkX][chunkY].addObject(object);
		}
	}
	
	public Collection<LiquidGameBlock> getLiquidBlocks(){
		return liquidBlocks;
	}
	
	public void addParticle(Particle particle){
		this.particles.add(particle);
		this.physicsObjects.add(particle);
	}
	
	public ArrayList<Particle> getParticles(){
		return this.particles;
	}
	
//	public void removeGameObject(GameObject object){
//		this.currentObjects[object.getX()][object.getY()] = null;
//	}
	
	public Collection<PhysicsObject> getPhysicsObjects(){
		return this.physicsObjects;
	}
	
	/*public GameObject getObjectAt(int x, int y){
		Chunk chunk = this.getChunkForLocation(x, y);
		
		if(chunk != null){
			Collection<GameObject> c=chunk.getContaining(x, y);
			if(c!=null&&!c.isEmpty()) return c.iterator().next();
		}
		return null;
	}*/
	
	public Chunk getChunkForBlock(GameObject object){
		int x = object.getX() / Chunk.CHUNKSIZE;
		int y = object.getY() / Chunk.CHUNKSIZE;
		
		return chunks[x][y];
	}
	
	public Chunk getChunkForLocation(int x, int y){
		int trueX = x / Chunk.CHUNKSIZE;
		int trueY = y / Chunk.CHUNKSIZE;
		
		if(trueX<0||trueX>=chunks.length||trueY<0||trueY>=chunks[0].length) return null;
		return chunks[trueX][trueY];
	}
	
	public void addPhysicsObject(PhysicsObject po){
		this.physicsObjects.add(po);
	}
	public void removePhysicsObject(PhysicsObject po){
		this.physicsObjects.remove(po);
	}
	public void addNPC(NPC npc){
		this.npcs.add(npc);
		this.physicsObjects.add(npc);
	}
	
	public ArrayList<NPC> getNPCs(){
		return this.npcs;
	}
	
	public void kill(NPC npc){ // for when something dies
		this.npcs.remove(npc);
		this.physicsObjects.remove(npc);
		
		//this.controller.removePhysicsObjectMoveListener(npc);
		
	//	npc.removeObjectCollisionListener(controller);	
		
	//	npc.removeObjectCollisionListener(controller);
		
		// maybe add blood particles or something at this point?
	}
	
	public void stopProjectile(Projectile p){
	}
	
	public void destroyProjectile(Projectile projectile){
		this.physicsObjects.remove(projectile);
	}
	
	public void removeParticle(Particle particle){
		this.particles.remove(particle);
		this.physicsObjects.remove(particle);
	}
	
	public void dealWithFileIO(int playerX, int playerY){
		// TODO: if the player is close to a border
		
		//System.err.println("dealing with fileIO");
		
		if(Math.abs(playerX - (startChunkX * Chunk.CHUNKSIZE)) < 1024 || 
				Math.abs(playerY - (startChunkY * Chunk.CHUNKSIZE)) < 1024 ||
				Math.abs(playerX - ((startChunkX * Chunk.CHUNKSIZE) + (CHUNKS_TO_LOAD_EXTRA * Chunk.CHUNKSIZE))) < 1024 ||
				Math.abs(playerY - ((startChunkY * Chunk.CHUNKSIZE) + (CHUNKS_TO_LOAD_EXTRA * Chunk.CHUNKSIZE))) < 1024){
			
			//System.err.println("succeeded");
		
			startChunkX = (playerX / Chunk.CHUNKSIZE) - (CHUNKS_TO_LOAD_EXTRA / 2);
			startChunkY = (playerY / Chunk.CHUNKSIZE) - (CHUNKS_TO_LOAD_EXTRA / 2);
			int endChunkX = startChunkX + (CHUNKS_TO_LOAD_EXTRA / 2);
			int endChunkY = startChunkY + (CHUNKS_TO_LOAD_EXTRA / 2);
			
			if(startChunkX < 0){
				startChunkX = 0;
			}else if(startChunkX >= chunks.length){
				startChunkX = chunks.length - 1;
			}
			if(startChunkY < 0){
				startChunkY = 0;
			}else if(startChunkY >= chunks[0].length){
				startChunkY = chunks[0].length - 1;
			}
			if(endChunkX <0){
				endChunkX = 0;
			}else if(endChunkX >= chunks.length){
				endChunkX = chunks.length - 1;
			}
			if(endChunkY < 0){
				endChunkY = 0;
			}else if(endChunkY >= chunks[0].length){
				endChunkY = chunks[0].length;
			}
			
			fm.loadChunks(chunks, startChunkX, startChunkY, endChunkX, endChunkY);
			//unloadOtherChunks(startChunkX, startChunkY, endChunkX, endChunkY);
		
		}
	}
	
	public void unloadOtherChunks(int startX, int startY, int endX, int endY){
		for(int x=0; x<chunks.length; x++){
			for(int y=0; y<chunks[0].length; y++){
				if(x >= startX && x <= endX && y >= startY && y<= endY){
				}else{
					chunks[x][y] = null;
				}
			}
		}
	}
	
	public void startGenerating(){
		generating=true;
		for(Chunk[] x:chunks) for(Chunk y:x) y.startGenerating();
	}
	
	public void finishGenerating(){
		generating=false;
		for(Chunk[] x:chunks) for(Chunk y:x) y.finishGenerating();
	}

}
