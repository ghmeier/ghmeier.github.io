package squareInfinity;

public class MagicCommand {
	
	private String name;
	private int cost;
	
	public MagicCommand(String name, int cost){
		this.name = name;
		this.cost = cost;
	}
	
	public int getCost(){
		return this.cost;
	}
	
	public String getName(){
		return this.name;
	}

}
