package squareInfinity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.StringTokenizer;

public class MagicInterpreter {
	
	// Special words
	
	private HashSet<String> chaff = new HashSet<String>();
	private HashSet<String> referrers = new HashSet<String>();
	private HashSet<String> primitiveNames = new HashSet<String>();	
	private HashMap<String, Integer> commands = new HashMap<String, Integer>();
	
	
	/////
	
	private LostHope controller;
	
	private String debugName = "magic";
	
	private Player player;
	
	//private Magic selectedMagic;
	private MagicEditor editor;
	
	private boolean isWaiting;
	private int amountToWait;
	
	private long timerStart;	
	private long timerCurrent;
	
	//private int ppToUse = 0;
	
	public MagicInterpreter(MagicEditor editor, LostHope controller){
		this.controller = controller;
		//this.selectedMagic = selectedMagic;
		
		this.editor = editor;
		
		this.player = controller.getCurrentPlayer();
		
		this.isWaiting = false;
		
		this.amountToWait = 0;
		this.timerStart = 0;
		this.timerCurrent = 0;
		
		fillCommands();
		fillChaff();
		fillReferrers();
		
		if(!LostHope.debugManager.hasProfile(debugName)){
			LostHope.debugManager.addProfile(debugName);
			LostHope.debugManager.setProfile(debugName, false);
		}
	}
	
	private void fillCommands(){
		commands.put("duplicate", 10);
		commands.put("is", 10);
		commands.put("send", 5);
		commands.put("stop", 15);
		commands.put("hold", 15);
		commands.put("explode", 20);
		commands.put("summmon", 40);
		commands.put("place", 5);
		commands.put("move", 5);
		commands.put("transmutate", 15);
	}
	
	private void fillChaff(){
		chaff.add("a");
		chaff.add("an");
		chaff.add("times");
		chaff.add("at");
		chaff.add("with");
		chaff.add("the");
		chaff.add("to");
		chaff.add("into");
	}
	
	private void fillReferrers(){
		referrers.add("him");
		referrers.add("her");
		referrers.add("it");
	}
	
	private void fillPrimitiveNames(){
		primitiveNames.add("block");
		primitiveNames.add("fireball");
		primitiveNames.add("arrow");
		primitiveNames.add("water");
	}
	
	public Player getPlayer(){
		return this.player;
	}
	
	public int determineCommandRequirements(String line){
		StringTokenizer st = new StringTokenizer(line, " ");
		
		while(st.hasMoreTokens()){
			String currentWord = st.nextToken();
			
			if(commands.containsKey(currentWord)){
				return commands.get(currentWord);
			}
		}
		
		return -1;
	}
	
	public void parseMagicCode(String magicCode){
		int ppToUse = this.determinePowerPointConsumption(magicCode);
		
		StringTokenizer st = new StringTokenizer(magicCode, "\n");
		
		//System.err.println("parsing");
		
		Player currentPlayer = controller.getCurrentPlayer();
		
		boolean canCast = currentPlayer.setPowerPoints(currentPlayer.getPowerPoints() - ppToUse);
		
		if(canCast){
			while(st.hasMoreTokens()){
				if(!this.isWaiting){
					this.parseLine(st.nextToken());
				}else{
					this.timerCurrent = System.currentTimeMillis();
					System.out.println("waiting");
					
					//System.err.println(this.amountToWait);
					
					if(timerCurrent - timerStart >= this.amountToWait){
						this.timerCurrent = 0;
						this.timerStart = 0;
						this.amountToWait = 0;
						//System.err.println("finished");
						LostHope.debugManager.printError(debugName, "finished");
					}
				}
			}
			
			//System.err.println("parsing");
			LostHope.debugManager.printError(debugName, "parsing");
		}else{
			//System.err.println("Count not cast spell, too little PP");
			LostHope.debugManager.printError(debugName, "Count not cast spell, too little PP");
		}
		
		
		//throw new ArrayIndexOutOfBoundsException();
	}
	
	public int determinePowerPointConsumption(String code){
		StringTokenizer st = new StringTokenizer(code, "\n");
		
		int total = 0;
		
		while(st.hasMoreTokens()){
			int amount = determineLinePowerPointConsumption(st.nextToken());
			
			total = total + amount;
		}
		
		return total;
	}
	
	public int determineLinePowerPointConsumption(String code){
		int power = this.determineCommandRequirements(code);
		
		if(power >= 0){
		
			StringTokenizer st = new StringTokenizer(code, "\n ,");
			
			int total = 0;
			
			total = total + power;
			
			while(st.hasMoreTokens()){
				String currentToken = st.nextToken();
				
				try{
					int amount = Integer.parseInt(currentToken);
					total = total + amount;
				}catch(NumberFormatException nfe){
					// do nothing, as there is nothing to do.
				}
			}
			
			return total;
		}else{
			return 0;
		}
	}
	
	public void parseLine(String line){
		/// first just break it into peices
		
		StringTokenizer sentenceBreaker = new StringTokenizer(line);
		ArrayList<String> words = new ArrayList<String>();
		
		while(sentenceBreaker.hasMoreTokens()){
			words.add(sentenceBreaker.nextToken());
		}
		
		
		if(words.size() >= 2){
			String firstWord = words.get(0);
			String secondWord = words.get(1);
			
			String[] args = null;
			
			if(words.size() >= 3){
				args = new String[words.size() - 2];
				
				int argCounter = 0;
				
				for(int x=2; x<words.size(); x++){
					
					if(!chaff.contains(words.get(x))){
						args[argCounter] = words.get(x);
						
						argCounter = argCounter + 1;
					}
					
				}
			}
			
			parseMethod(firstWord, secondWord, args);
		}else{
			//System.err.println("invalid syntax");
			LostHope.debugManager.printError(debugName, "invalid syntax");
		}
	}
	
	private void parseMethod(String firstWord, String secondWord, String[] args){
		// figure out what is what
		
		String command = null;
		String variableName = null;
		
		if(commands.containsKey(firstWord)){
			command = firstWord;
			variableName = secondWord;
		}else{
			command = secondWord;
			variableName = firstWord;
		}
		
		//System.out.println("--DEBUG--  command = <<" + command + ">>");
		//System.out.println("--DEBUG--  variableName = <<" + variableName + ">>");
		
		LostHope.debugManager.printError(debugName, "--DEBUG--  command = <<" + command + ">>");
		LostHope.debugManager.printError(debugName, "--DEBUG--  variableName = <<" + variableName + ">>");
		
		runCommand(command, variableName, args);
	}
	
	private int lockToGrid(int gridSize, int number){
		return (number / gridSize) * gridSize;
	}
	
	private void runCommand(String command, String variableName, String[] args){
		MagicController magicController = controller.getMagicController();
		
		if(command.equalsIgnoreCase("is")){ //////////// TODO: CREATE PRIMITIVES
			if(args == null){
				//System.err.println("you have to say *what* something is...");
			}else{
				if(variableName != null){
					
					String primitiveType = args[0];
					
					if(primitiveType.equalsIgnoreCase("fireball")){ ////////////////////// FIREBALL
						Projectile primitive = LostHope.factory.createProjectile(Projectile.FIREBALL, 1, player.getHandX(), 
								player.getHandY());
						
						Random r = new Random();
						
						if(player.isForward()){
							primitive.setXSpeed(r.nextInt(10));
						}else{
							primitive.setXSpeed(r.nextInt(10) * -1);
						}
						
						primitive.setYSpeed(r.nextInt(4));
						
						magicController.addVariable(variableName, primitive);
					}else if(primitiveType.equalsIgnoreCase("arrow")){/////////////////// ARROW
						Projectile primitive = LostHope.factory.createProjectile(Projectile.ARROW, 1, 
								player.getHandX(), player.getHandY());
						Random r = new Random();
						
						if(player.isForward()){
							primitive.setXSpeed(r.nextInt(10));
						}else{
							primitive.setXSpeed(r.nextInt(10) * -1);
						}
						
						primitive.setYSpeed(r.nextInt(4));
						
						magicController.addVariable(variableName, primitive);
					}else if(primitiveType.equalsIgnoreCase("block")){ /////////////////// BLOCK
						GameObject block = LostHope.factory.createGameObject(GameBlock.DIRT, player.getHandX(), player.getHandY());
						
						magicController.addVariable(variableName, block);
					}else if(primitiveType.equalsIgnoreCase("water")){ /////////////////// WATER
						LostHope.factory.createLiquidGameBlock(lockToGrid(LostHope.BLOCKSIDE,player.getHandX()), 
								lockToGrid(LostHope.BLOCKSIDE,player.getHandY()), 
								LiquidGameBlock.WATER_BLOCK);
					}
					
					
				}else{
					//System.err.println("you need to give a magical name to an object");
				}
			}
		}else if(command.equalsIgnoreCase("duplicate")){ //////////////////////////////// TODO: duplicate 
			if(args != null){
				if(variableName != null){
					if(magicController.doesVariableExist(variableName, true)){
						int amountOfTimesToDuplicate = Integer.parseInt(args[0]);
						
						//System.out.println("creating " + amountOfTimesToDuplicate + " copy(s)");
						LostHope.debugManager.printError(debugName, "creating" + amountOfTimesToDuplicate + " copy(s)");
						
						MagicPrimitive objectToDuplicate = magicController.getVariable(variableName);
						
						for(int x=0; x<amountOfTimesToDuplicate; x++){
							objectToDuplicate.createCopyOfSelf();
						}
					}
				}else{
					//System.err.println("What do you want to duplicate??");
				}
			}else{
				//System.err.println("amount of times to duplicate must be specified");
			}
		}else if(command.equalsIgnoreCase("send")){ /////////////////////////////////////// TODO: set direction (send)
			if(args != null && args.length >= 2){
				if(variableName != null){
					
					if(magicController.doesVariableExist(variableName, true)){
						String direction = args[0];
						
						int verticalSpeed = 0;
						int horizontalSpeed = 0;
						
						int power = Integer.parseInt(args[1]);
						
						if(direction.equalsIgnoreCase("left")){
							horizontalSpeed = -1 * power;
						}else if(direction.equalsIgnoreCase("right")){
							horizontalSpeed = power;
						}else if(direction.equalsIgnoreCase("up")){
							verticalSpeed = -1 * power;
						}else if(direction.equalsIgnoreCase("down")){
							verticalSpeed = power;
						}
						
						MagicPrimitive primitive = magicController.getVariable(variableName);
						
						if(primitive instanceof Projectile){
							PhysicsObject object = (PhysicsObject) primitive;
							
							object.setXSpeed(horizontalSpeed);
							object.setYSpeed(verticalSpeed);
						}
					}
					
				}else{
					//System.err.println("what do you want to send...?");
				}
			}else{
				//System.err.println("Where do you want to send it? How Fast?");
			}
		}else if(command.equalsIgnoreCase("stop") || command.equalsIgnoreCase("hold")){ ////// TODO: stop/hold
			if(variableName != null){
				if(magicController.doesVariableExist(variableName, true)){
					MagicPrimitive primitive = magicController.getVariable(variableName);
					
					primitive.toggleHold(true);
				}
			}else{
				//System.err.println("what do you want to stop?");
			}
		}else if(command.equalsIgnoreCase("release")){ //////////////////////////////////////// TODO: release [from hold]
			if(variableName != null){
				if(magicController.doesVariableExist(variableName, true)){
					MagicPrimitive primitive = magicController.getVariable(variableName);
					
					primitive.toggleHold(false);
				}
			}else{
				//System.err.println("what do you want to release?");
			}
		}else if(command.equalsIgnoreCase("explode")){ /////////////////////////////////////////// TODO: explode
			if(args != null){
				if(variableName != null){
					if(magicController.doesVariableExist(variableName, true)){
						MagicPrimitive primitive = magicController.getVariable(variableName);
						
						int power = Integer.parseInt(args[0]);
						
						primitive.magicExplode(controller, power);
					}
				}else{
					//System.err.println("what do you want to explode?");
				}
			}
		}else if(command.equalsIgnoreCase("summon")){ ///////////////////////////////////////////// TODO: summon
			if(args!=null && args.length >= 2){
				if(variableName != null){
					//System.err.println("summoning");
					LostHope.debugManager.printError(debugName, "summoning");
					
					
					int xLocation = 0;
					int yLocation = 0;
					Player player = controller.getCurrentPlayer();
					
					if(args[2].equalsIgnoreCase("left")){
						xLocation = (int)player.getX() - 64;
						yLocation = (int)player.getY();
					}else{
						xLocation = (int)player.getX() + 64;
						yLocation = (int)player.getY();
					}
					
					//System.err.println("args[1] = <<" + args[1] + ">>");
					
					if(args[1].equalsIgnoreCase("skeleton")){
						
						/*NPC npc = LostHope.factory.createNPC(new Skeleton(variableName, NPC.SKELETON, xLocation, yLocation,32,32));
						//it is not time, Skeletons are not implemented
						npc.setAI(new AngryEnemyAI());
						
						xLocation = lockToGrid(32, xLocation);
						yLocation = lockToGrid(32, yLocation);
						
						npc.setX(xLocation);
						npc.setY(yLocation);
						
						magicController.addVariable(variableName, npc);*/
					}
				}else{
					//System.err.println("what do you want to name the creature?");
				}
			}
		}else if(command.equalsIgnoreCase("place") || command.equalsIgnoreCase("move")){ // TODO: place/move
			if(args != null && args.length >= 2){
				if(variableName != null){
					if(magicController.doesVariableExist(variableName, true)){
						MagicPrimitive mp = magicController.getVariable(variableName);
						
						if(mp instanceof GameObject){
							GameObject go = (GameObject) mp;
							
							int x = Integer.parseInt(args[0]);
							int y = Integer.parseInt(args[1]);
							
							Location currentLocation = controller.getCurrentLocation();
							Player currentPlayer = controller.getCurrentPlayer();
							
							LostHope.factory.destroyGameObject(go);
							go.setX(x + currentPlayer.getHandX());
							go.setY(y + currentPlayer.getHandY());
							currentLocation.addObject(go);
						}
					}else{
						//System.err.println("that variable does not exist");
					}
				}else{
					//System.err.println("What do you want to " + command + "?");
				}
			}else{
				//System.err.println("where do you want to " + command + " that?");
			}
		}else if(command.equalsIgnoreCase("transmutate")){ /////////////////// TODO: transmutate
			if(args != null){
				if(variableName != null && magicController.doesVariableExist(variableName, true)){
					MagicPrimitive mp = magicController.getVariable(variableName);
					
					if(mp instanceof GameBlock){
						GameBlock gb = (GameBlock) mp;
						
						String typeName = args[0];
						typeName.trim();
						typeName.toLowerCase();
						
						byte type = 0;
						
						if(typeName.equalsIgnoreCase("stone")){
							type = GameBlock.STONE_BLOCK;
						}else if(typeName.equalsIgnoreCase("dirt")){
							type = GameBlock.DIRT;
						}else{
							//System.err.println("beerrrgh that is not a type!!!!");
							LostHope.debugManager.printError(debugName, "beerrrgh that is not a type!!!!");
						}
						
						if(type != 0){
							gb.transmutate(type);
						}
					}
				}
			}else{
				//System.err.println("What do you want to change it into?");
			}
		}
	}
	
	private void setTimer(int amountToWait){
		this.timerStart = System.currentTimeMillis();
		this.amountToWait = amountToWait;
		this.isWaiting = true;
	}

}
