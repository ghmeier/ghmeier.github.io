package squareInfinity;

//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileReader;
//import java.io.IOException;
import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.StringTokenizer;

public class GameObjectInfo {
	
	public static final ArrayList<GameObjectInfo> info = new ArrayList<GameObjectInfo>();
	
	public GameObjectInfo findItemWithType(byte type){
		for(int x=0; x<info.size(); x++){
			GameObjectInfo information = info.get(x);
			
			if(information.getType() == type){
				return information;
			}
		}
		
		return null;
	}
	
//	public static void loadGameObjectInfo(String filename, String refFilename){
//		try{
//			File file = new File(filename);
//			File refFile = new File(filename);
//			
//			BufferedReader reader = new BufferedReader(new FileReader(refFilename));
//			
//			Map<String, Byte> conversionTable = new HashMap<String, Byte>();
//			
//			// first fill the conversion table
//		
//			StringTokenizer tokenizer;
//			
//			String currentLine = reader.readLine().trim();
//			
//			while(currentLine != null){
//				tokenizer = new StringTokenizer(currentLine, " ,"); // spaces and commas are counted
//				
//				byte value = Byte.parseByte(tokenizer.nextToken());
//				String name = tokenizer.nextToken();
//				
//				conversionTable.put(name, value);
//				
//				currentLine = reader.readLine().trim();
//			}
//			
//			// now that the conversion table is built, use it to read from a lead file
//			
//			reader = new BufferedReader(new FileReader(filename));
//			
//			currentLine = reader.readLine().trim();
//			
//			while(currentLine != null){
//				tokenizer = new StringTokenizer(currentLine, " ,");
//				
//				// this all assumes that the file is formatted correctly :/
//				String fileLocation = tokenizer.nextToken();
//				String type = tokenizer.nextToken();
//				String primary = tokenizer.nextToken();
//				String secondary = tokenizer.nextToken();
//				byte percent = Byte.parseByte(tokenizer.nextToken());
//				
//				info.add(new GameObjectInfo(fileLocation, conversionTable.get(type), conversionTable.get(primary), conversionTable.get(secondary), percent));
//			
//				currentLine = reader.readLine().trim();
//			}
//			
//		}catch(IOException ioe){
//			System.err.println("Something has not loaded correctly!");
//		}
//	}
	
	protected String imageLocation;
	
	protected byte primaryType;
	protected byte secondaryType;
	
	protected byte type;
	
	protected byte percent;
	
	public GameObjectInfo(String imageLocation, byte type, byte primaryType, byte secondaryType, byte percent){
		this.imageLocation = imageLocation;
		
		this.primaryType = primaryType;
		this.secondaryType = secondaryType;
		
		this.type = type;
		
		this.percent = percent;
	}
	
	public String getImageLocation(){
		return this.imageLocation;
	}
	
	public byte getPrimaryType(){
		return this.primaryType;
	}
	
	public byte getSecondaryType(){
		return this.secondaryType;
	}
	
	public byte getPercent(){
		return this.percent;
	}
	
	public byte getType(){
		return this.type;
	}

}
