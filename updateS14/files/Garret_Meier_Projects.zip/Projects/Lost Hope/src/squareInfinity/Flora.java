package squareInfinity;


public abstract class Flora {
	
	protected int x;
	protected int y;
	
	protected int width;
	protected int height;
	
	protected boolean isLighted=true;//set that until we get water and light working
	protected boolean isWatered=true;
	
	public Flora(int x, int y, int width, int height){
		this.x = x;
		this.y = y;
		
		this.width = width;
		this.height = height;
	}
	
	public void setX(int x){
		this.x = x;
	}
	
	public void setY(int y){
		this.y = y;
	}
	
	public int getX(){
		return this.x;
	}
	
	public int getY(){
		return this.y;
	}
	
	public void setHeight(int height){
		this.height = height;
	}
	
	public  void setWidth(int width){
		this.width = width;
	}
	
	//public abstract void drawSelf(Graphics g, int xOffset, int yOffset);
	
	// collision stuff
	
	public boolean isCollidingWith(PhysicsObject object){
		return object.getX() <= x + width && object.getY() <= y + height && 
				object.getX() + object.getWidth() >= x && object.getY() + object.getHeight() >= y;
	}
	
	public boolean getIsLighted() {
		return this.isLighted;
	}

	public boolean getIsWatered() {
		return this.isWatered;
	}
	public abstract void grow(LostHope controller);//add stuff in other classes to look through proper designs 
}
