package squareInfinity;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.StringTokenizer;

import squareInfinity.gui.GUIActionListener;
import squareInfinity.gui.GUIAlignment;
import squareInfinity.gui.GUIButton;
import squareInfinity.gui.GUIElement;
import squareInfinity.gui.GUIElementController;
import squareInfinity.gui.GUIItemButton;

public class PrimitiveCraftingInterface implements MouseListener, GUIActionListener{
	
	public static ArrayList<PrimitiveBlueprint> blueprints;
	
	private int x;
	private int y;
	
	private int width;
	private int height;
	
	private int mouseX;
	private int mouseY;
	private boolean mouseDown;
	
	private boolean isMouseOverFillable = false;
	
	private boolean fillMenu = false;
	private ArrayList<GUIItemButton> fillMenuButtons;
	private GUIButton fillOptionsButton;
	
	private PrimitiveBlueprint selectedBlueprint;
	
	private LostHope controller;
	
	private int requiredMateriel;
	
	private GUIButton switchBlueprintButton;
	private int blueprintCount = 0;
	
	public PrimitiveCraftingInterface(int x, int y, LostHope controller){
		this.x = x;
		this.y = y;
		
		this.requiredMateriel = -1;
		
		this.fillOptionsButton = new GUIButton(this.x + 125, this.y + 5, "Show Fill Options");
		this.fillOptionsButton.addActionListener(this);
		GUIElementController gc = controller.elementController;
		GUIAlignment ga = gc.getCurrentAlignment();
		ga.addElement(this.fillOptionsButton);
		
		this.switchBlueprintButton = new GUIButton(this.x + 5, this.y + 5, "Switch Blueprints");
		this.switchBlueprintButton.addActionListener(this);
		ga.addElement(this.switchBlueprintButton);
		
		this.width = 300;
		this.height = 150;
		
		this.mouseX = -1;
		this.mouseY = -1;
		
		this.controller = controller;
		
		if(blueprints == null){
			loadBlueprints();
		}
		
		if(blueprints.size() > 0){
			selectedBlueprint = blueprints.get(0);
			this.calculateNeededMateriel();
		}
	}
	
	public static void loadBlueprints(){
		blueprints = new ArrayList<PrimitiveBlueprint>();
		
		File location = new File("CraftingDesigns/");
		
		File[] files = location.listFiles();
		
		for(int i = 0; i < files.length; i++){
			File currentFile = files[i];
			
			String name = currentFile.getName();
			//System.err.println("current File: <<" + name + ">>");
			StringTokenizer nameTokenizer = new StringTokenizer(name, "-");
			
			String firstPart = nameTokenizer.nextToken();
			
			if(firstPart.equalsIgnoreCase("design")){
				PrimitiveBlueprint pb = PrimitiveBlueprint.getFromFile("CraftingDesigns/" + name);
				
				if(pb!= null){
					blueprints.add(pb);
				}
			}
		}
		
		System.out.println("loaded " + blueprints.size() + " crafting blueprints");
	}
	
	public void drawSelf(Graphics g, int mouseX, int mouseY){
		this.mouseX = mouseX;
		this.mouseY = mouseY;
		
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(x, y, width, height);
		
		g.setColor(Color.DARK_GRAY);
		g.drawRect(x + 1, y + 1, width - 3, height - 3);
		
		drawBlueprint(g,x + 5, y + 20, 8);
	}
	
	public void drawBlueprint(Graphics g, int x, int y, int scale){		
		if(selectedBlueprint != null){
			String name = selectedBlueprint.getName();
			
			FontMetrics fm = g.getFontMetrics();
			
			int height = fm.getHeight();
			
			g.setColor(Color.BLACK);
			g.drawString(name, x, y + height);
			
			y = y + height + 1;
			
			byte[][] values = selectedBlueprint.getValues();
			
			for(int i=0; i<values.length; i++){
				for(int j=0; j<values[0].length; j++){
					int drawX = x + (i * scale);
					int drawY = y + (j * scale);
					
					byte currentValue = values[i][j];
					
					boolean doDraw = true;
					
					if(currentValue == PrimitiveBlueprint.OUTLINE_SLOT){
						g.setColor(Color.BLACK);
					}else if(currentValue == PrimitiveBlueprint.FILL_SLOT){
						g.setColor(Color.YELLOW);
					}else if(currentValue == PrimitiveBlueprint.HAND_SLOT){
						g.setColor(Color.BLUE);
					}else{
						doDraw = false;
					}
					
					if(doDraw){
						g.fillRect(drawX, drawY, scale, scale);
					}
				}
			}
			
			g.setColor(Color.BLACK);
			
			int reach = selectedBlueprint.getReach();
			int baseDamage = selectedBlueprint.getBaseDamage();
			
			int drawX = x + (values.length * scale) + 4;
			
			g.drawString("Reach: " + reach, drawX, y + (2 * height));
			g.drawString("Damage: " + baseDamage, drawX, y + (3 * height));
			g.drawString("Materiel: " + this.requiredMateriel, drawX, y + (4 * height));
		}
	}
	
	public boolean mouseIsWithinArea(int x, int y, int ex, int ey){
		return mouseX >= x && mouseX <= ex && mouseY >= y && mouseY <= ey;
	}
	
	public void close(){
		GUIElementController gc = controller.elementController;
		GUIAlignment ga = gc.getCurrentAlignment();
		
		ga.removeElement(this.fillOptionsButton);
		ga.removeElement(this.switchBlueprintButton);
		
		if(this.fillMenu){
			this.hideFillMenu();
		}
	}
	
	public int calculateNeededMateriel(){
		int tempCount = 0;
		
		if(this.selectedBlueprint != null){
			byte[][] stuff = this.selectedBlueprint.getValues();
			
			for(int x=0; x<stuff.length; x++){
				for(int y=0; y<stuff[0].length; y++){
					if(stuff[x][y] == PrimitiveBlueprint.FILL_SLOT){
						tempCount = tempCount + 1;
					}
				}
			}
		}
		
		
		this.requiredMateriel = tempCount;
		return tempCount;
	}
	
	public void craft(InventoryPeicesHolder holder){
		calculateNeededMateriel();
		
		// subtract and stuff
		
		if(holder.getCount() > this.requiredMateriel){
			holder.setCount(holder.getCount() - this.requiredMateriel);
		}else if(holder.getCount() == this.requiredMateriel){
			controller.getCurrentPlayer().getInventory().remove(holder);
		}
		
		Color[][] pictureColors = new Color[selectedBlueprint.getWidth()][selectedBlueprint.getHeight()];
		byte typeToFillWith = holder.getType();
		Color colorToFillWith = ObjectData.getColorForType(typeToFillWith);
		
		// fill the color array
		
		byte[][] stuff = selectedBlueprint.getValues();
		
		for(int x=0; x<stuff.length; x++){
			for(int y=0; y<stuff[0].length; y++){
				if(stuff[x][y] == PrimitiveBlueprint.FILL_SLOT || stuff[x][y] == PrimitiveBlueprint.OUTLINE_SLOT ||
						stuff[x][y] == PrimitiveBlueprint.HAND_SLOT){
					pictureColors[x][y] = colorToFillWith;
				}
			}
		}
		
		BufferedImage itemImage = new BufferedImage(selectedBlueprint.getWidth(), selectedBlueprint.getHeight(), 
				BufferedImage.TYPE_INT_ARGB);
		
		Graphics imageGraphics = itemImage.createGraphics();
		
		//draw stuff ironically
		
		for(int x=0; x<pictureColors.length; x++){
			for(int y=0; y<pictureColors[0].length; y++){
				if(pictureColors[x][y] != null){
					imageGraphics.setColor(pictureColors[x][y]);
					imageGraphics.fillRect(x, y, 1, 1);
				}
			}
		}
		
		// now make the item
		
		Dimension handLocation = this.selectedBlueprint.getHandLocation();
		
		if(handLocation == null){
			handLocation = new Dimension(selectedBlueprint.getWidth(), selectedBlueprint.getHeight());
		}
		
		String typeName = ObjectData.getNameForType(typeToFillWith);
		String blueprintName = selectedBlueprint.getName();
		
		String itemName = typeName + " " + blueprintName;
		
		PrimitiveItem newItem = new PrimitiveItem(itemName, stuff.length, stuff[0].length, 1, selectedBlueprint.getBaseDamage(), 
				selectedBlueprint.getReach(), handLocation, itemImage, true);
		
		// now set snap points
		
		for(int x=0; x<stuff.length; x++){
			for(int y=0; y<stuff[0].length; y++){
				if(selectedBlueprint.isSnapPoint(x, y)){
					newItem.setSnapPoint(x, y);
				}
			}
		}
		
		newItem.finalize();
		
		Player currentPlayer = controller.getCurrentPlayer();
		
		currentPlayer.addItemToInventory(newItem);
	}
	
	public void showFillMenu(){
		int needed = this.calculateNeededMateriel();
		
		this.fillMenu = true;
		this.fillMenuButtons = new ArrayList<GUIItemButton>();
		
		GUIElementController gc = controller.elementController;
		GUIAlignment ga = gc.getCurrentAlignment();
		Player currentPlayer = controller.getCurrentPlayer();
		ArrayList<InventoryItem> items = currentPlayer.getInventory();
		
		int trueCounter = 0;
		
		for(int x=0; x<items.size(); x++){
			InventoryItem item = items.get(x);
			
			if(item instanceof InventoryPeicesHolder){
				InventoryPeicesHolder iph = (InventoryPeicesHolder) item;
				
				if(iph.getCount() >= needed){
					GUIItemButton tempButton = new GUIItemButton(this.x + 125, this.y + 10 + ((trueCounter + 1) * 13), "Use " + iph.getName());
					tempButton.setItem(iph);
					tempButton.addActionListener(this);
					
					fillMenuButtons.add(tempButton);
					ga.addElement(tempButton);
					
					trueCounter = trueCounter + 1;
				}
			}
		}
	}
	
	public void hideFillMenu(){
		this.fillMenu = false;
		
		GUIElementController gc = controller.elementController;
		GUIAlignment ga = gc.getCurrentAlignment();
		
		for(int x=0; x<fillMenuButtons.size(); x++){
			ga.removeElement(fillMenuButtons.get(x));
		}
		
		this.fillMenuButtons.clear();
		//this.fillMenuButtons = null;
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		mouseX = arg0.getX();
		mouseY = arg0.getY();
		
		mouseDown = true;
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		mouseX = arg0.getX();
		mouseY = arg0.getY();
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		mouseX = arg0.getX();
		mouseY = arg0.getY();
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		mouseX = arg0.getX();
		mouseY = arg0.getY();
		
		mouseDown = true;
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		mouseX = arg0.getX();
		mouseY = arg0.getY();
		
		mouseDown = false;
	}

	@Override
	public void elementClicked(GUIElement element) {
		if(element == this.fillOptionsButton){
			if(!this.fillMenu){
				this.showFillMenu();
			}else{
				this.hideFillMenu();
			}
		}else if(element == this.switchBlueprintButton){
			this.blueprintCount = this.blueprintCount + 1;
			
			if(this.blueprintCount >= blueprints.size()){
				this.blueprintCount = 0;
			}
			
			this.selectedBlueprint = blueprints.get(this.blueprintCount);
			this.calculateNeededMateriel();
		}else{ // check for button pressing in the fill menu
			if(this.fillMenuButtons != null && this.fillMenu){
				for(int x=0; x<this.fillMenuButtons.size(); x++){
					GUIItemButton currentButton = this.fillMenuButtons.get(x);
					
					if(currentButton == element){
						InventoryItem item = currentButton.getItem();
						
						if(item != null && item instanceof InventoryPeicesHolder){
							InventoryPeicesHolder iph = (InventoryPeicesHolder) item;
							
							this.craft(iph);
							this.hideFillMenu();
						}
					}
				}
			}
		}
	}

}
