package squareInfinity;

import java.awt.Color;
import java.awt.Graphics;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

@SuppressWarnings("serial")
public class GameBlock extends GameObject implements MagicPrimitive, Serializable{
	
	//// COLLISIONS
	
	public static final byte NO_COLLISION = 0;
	
	public static final byte TOP_LEFT_COLLISION = 5;
	public static final byte TOP_RIGHT_COLLISION = 6;
	public static final byte BOTTOM_RIGHT_COLLISION = 7;
	public static final byte BOTTOM_LEFT_COLLISION = 8;
	
	public static final byte TOP_COLLISION = 1;
	public static final byte BOTTOM_COLLISION = 2;
	public static final byte LEFT_COLLISION = 3;
	public static final byte RIGHT_COLLISION = 4;
	
	///

	public static final byte NOTHING = 0;
	public static final byte DIRT = 1;
	public static final byte ROCK = 2;
	public static final byte IRON_VEIN = 3;
	public static final byte GRASS = 4;
	public static final byte ADAMANTINE_VEIN = 5;
	public static final byte COAL_VEIN = 6;
	public static final byte GOLD_VEIN = 7;
	public static final byte DIAMOND_VEIN = 8;
	public static final byte MITHRIL_VEIN = 9;
	public static final byte WATER = 100;
	public static final byte BROWN_AGATE = 10;
	public static final byte GARNET = 11;
	public static final byte OAK_WOOD = 12;
	public static final byte LEAF = 13;
	public static final byte COPPER_VEIN = 14;
	public static final byte TIN_VEIN=15;
	public static final byte SAND = 16;
	public static final byte MARBLE = 17;
	public static final byte GRANITE = 18;
	public static final byte SANDSTONE = 19;
	public static final byte BIRCH_WOOD = 20;
	public static final byte URANIUM_VEIN = 21;
	public static final byte AMETHYST = 22;
	public static final byte ONYX = 23;
	public static final byte BERYL = 24;
	public static final byte SERAPHINITE = 25;
	public static final byte RED_FLOWER = 26;
	public static final byte  YELLOW_FLOWER = 27;
	public static final byte  WORKBENCH = 28;
	public static final byte  BED = 29;
	public static final byte  CHAIR = 30;
	public static final byte  TABLE = 31;
	public static final byte  CHEST = 32;
	public static final byte  STONE_WALL = 33;
	public static final byte  STONE_BLOCK = 34;
	public static final byte  WOOD_STAIRS = 35;
	public static final byte  WOOD_PLANK = 36;
	public static final byte ANVIL = 37;
	public static final byte FURNACE = 38;
	public static final byte LADDER = 39;
	public static final byte SAPLING = 40;
	public static final byte CACTUS = 41;
	///
	
	
	///
	
	protected ArrayList<ObjectCollisionListener> listeners; 
	
	protected byte primaryType;
	protected byte type;
	
	protected byte[][] pixels;
	
	protected boolean isImage;
	
	protected double friction;
	
	//protected Image mainImage;
	
	protected boolean isOneType;
	
	protected boolean canPickUp;
	protected boolean exploded;
	
	public GameBlock(byte type, int x, int y, int width, int height){
		super(x,y,type);
		
		isImage = false;
		
		this.pixels = new byte[width / 2][height / 2];
		
		listeners = new ArrayList<ObjectCollisionListener>();
		
//		this.x = x;
//		this.y = y;e
		
		this.isOneType = true;
		
		this.width = width;
		this.height = height;
		
		fillWithCorrectMaterial(type);
		
		this.primaryType = type;
		
		//this.collidingObjects = new HashSet<GameObject>();
	}
	
	public byte getPrimaryType(){
		return this.primaryType;
	}
	
	public GameBlock(byte type, int x, int y){
		super(x,y,type);
		isImage = true;
		
		this.isOneType = true;
		
		pixels = new byte[8][8];
		
		this.width = 16;
		this.height = 16;
		
		switch(type){
		case DIRT: friction=.5; break;
		case IRON_VEIN: friction=.4; break;
		case GRASS: friction=.5; break;
		case ROCK: friction=.45; break;
		case ADAMANTINE_VEIN: friction=.4; break;
		case COAL_VEIN: friction=.4; break;
		case GOLD_VEIN: friction=.4; break;
		case DIAMOND_VEIN: friction=.4; break;
		case MITHRIL_VEIN: friction=.4; break;
		case COPPER_VEIN: friction=.4; break;
		case TIN_VEIN: friction=.4; break;
		case SAND: friction = .4; break;
		case SANDSTONE: friction = .4; break;
		case MARBLE: friction = .3; break;
		case GRANITE: friction = .3; break;
		case BIRCH_WOOD: friction = .4; break;
		case URANIUM_VEIN: friction = .4; break;
		default: friction=.4; break;
		}
		this.fillWithCorrectMaterial(type);
	}
	
	public byte getType(){
		return this.type;
	}
	
	public void transmutate(byte newType){
		this.type = newType;
		
		fillWithCorrectMaterial(newType);
		this.isImage = true;
	}
	
	public void fillWithCorrectMaterial(byte type){
		if(type == DIRT){
			fillWith(ObjectData.DIRT, ObjectData.CLAY, 10); // aprox 10% of the dirt will be clay
		}else if(type == ROCK){
			fillWith(ObjectData.STONE, ObjectData.IRON, 2); // maybe 2% of the rock will have iron. MAYBE.
		}else if(type == IRON_VEIN){
			fillWith(ObjectData.STONE, ObjectData.IRON, 25); // much greater amount/chance of iron here
		}else if(type == GRASS){
			fillWithOne(ObjectData.GRASS);
		}else if(type == ADAMANTINE_VEIN){
			fillWith(ObjectData.STONE, ObjectData.ADAMANTINE, 20);
		}else if(type == COAL_VEIN){
			fillWith(ObjectData.STONE, ObjectData.COAL, 40);
		}else if(type == GOLD_VEIN){
			fillWith(ObjectData.STONE, ObjectData.GOLD, 25);
		}else if(type == MITHRIL_VEIN){
			fillWith(ObjectData.STONE, ObjectData.MITHRIL, 20);
		}else if(type == DIAMOND_VEIN){
			fillWith(ObjectData.STONE, ObjectData.DIAMOND, 10);
		} else if(type==COPPER_VEIN) {
			fillWith(ObjectData.STONE, ObjectData.COPPER, 40);
		} else if(type==TIN_VEIN) {
			fillWith(ObjectData.STONE, ObjectData.TIN, 40);
		} else if(type==OAK_WOOD) {
			fillWith(ObjectData.OAK);
		} else if(type==LEAF) {
			fillWith(ObjectData.LEAF);
		} else if(type== GARNET) {
			fillWith(ObjectData.GARNET);
		} else if(type==BROWN_AGATE) {
			fillWith(ObjectData.BROWN_AGATE);
		} else if(type==SAND) {
			fillWith(ObjectData.SAND);
		} else if(type==MARBLE) {
			fillWith(ObjectData.MARBLE);
		} else if(type==GRANITE) {
			fillWith(ObjectData.GRANITE);
		} else if (type == SANDSTONE) {
			fillWith(ObjectData.SANDSTONE);
		} else if (type == BIRCH_WOOD) {
			fillWith(ObjectData.BIRCH_WOOD);
		} else if(type == URANIUM_VEIN) {
			fillWith(ObjectData.STONE,ObjectData.URANIUM,15);
		} else if(type == AMETHYST) {
			fillWith(ObjectData.AMETHYST);
		} else if(type == ONYX) {
			fillWith(ObjectData.ONYX);
		} else if(type == BERYL) {
			fillWith(ObjectData.BERYL);
		} else if(type==SERAPHINITE) {
			fillWith(ObjectData.SERAPHINITE);
		} else if (type==RED_FLOWER) {
			fillWithOne(ObjectData.RED_FLOWER);
		} else if(type==YELLOW_FLOWER) {
			fillWithOne(ObjectData.YELLOW_FLOWER);
		} else if(type==WORKBENCH) {
			fillWithOne(ObjectData.WORKBENCH);
		} else if(type==BED) {
			fillWithOne(ObjectData.BED);
		} else if(type==CHAIR) {
			fillWithOne(ObjectData.CHAIR);
		} else if(type==TABLE) {
			fillWithOne(ObjectData.TABLE);
		} else if(type==CHEST) {
			fillWithOne(ObjectData.CHEST);
		} else if(type==STONE_WALL) {
			fillWithOne(ObjectData.STONE_WALL);
		} else if(type==STONE_BLOCK) {
			fillWithOne(ObjectData.STONE_BLOCK);
		} else if(type==WOOD_PLANK) {
			fillWithOne(ObjectData.WOOD_PLANK);
		} else if(type==WOOD_STAIRS) {
			fillWithOne(ObjectData.WOOD_STAIRS);
		} else if(type==ANVIL) {
			fillWithOne(ObjectData.ANVIL);
		} else if(type==FURNACE) {
			fillWithOne(ObjectData.FURNACE);
		} else if(type==LADDER) {
			fillWithOne(ObjectData.LADDER);
		} else if(type==SAPLING) {
			fillWithOne(ObjectData.SAPLING);
		} else if(type==CACTUS) {
			fillWithOne(ObjectData.CACTUS);
		}
		
		this.type = type;
	}
	
	public void fillWith(byte type){
		for(int x=0; x<this.pixels.length; x++){
			for(int y=0; y<this.pixels[0].length; y++){
				this.pixels[x][y] = type;
			}
		}
	}
	
/*	private void releaseTouchingParticles(LostHope controller, Location location){ // TODO: name this better
		Iterator<GameObject> objects = location.getObjectsBetween(x-1, y-1, x+width+1, y+height+1).iterator();
		
		while(objects.hasNext()){
			GameObject currentObject = objects.next();
			
			if(currentObject instanceof GameBlock) ((GameBlock)currentObject).drop(controller);
		}
	}*/
	
//	public void setMainImage(BufferedImage mainImage){
//		this.mainImage = mainImage;
//		this.isImage = true;
//	}
//	
//	public Image getMainImage(){
//		return this.mainImage;
//	}
	
	protected void fillWithOne(byte type) {
		for (int x = 0; x<pixels.length; x++) {
			for (int y=0; y<pixels[0].length; y++) {
				if (x==pixels.length/2 && y==pixels[0].length/2) {
					pixels[x][y] = type;
				} else {
					//pixels[x][y] = NOTHING;
				}
			}
		}
	}
	
	protected void fillWith(byte primaryType, byte secondType, int percent){
		Random r = new Random();
		
		this.primaryType = primaryType;
		
		for(int x=0; x < pixels.length; x++){
			for(int y=0; y<pixels[0].length; y++){
				int roll = r.nextInt(101);
				
				if(roll <= percent){
					pixels[x][y] = secondType;
				}else{
					pixels[x][y] = 0;
				}
			}
			
		}
	}
	
	public void addObjectCollisionListener(ObjectCollisionListener ocl){
		this.listeners.add(ocl);
	}
	
	public void removeObjectCollisionListener(ObjectCollisionListener ocl){
		this.listeners.remove(ocl);
	}
	
	public void drawSelf(Graphics g, int xModifier, int yModifier){
		
		if(isImage){
			//g.drawImage(mainImage,this.x + xModifier, this.y + yModifier,null);
			
			g.drawImage(GameFactory.blocks[this.type], this.x + xModifier, this.y + yModifier, null);
		}else if(isOneType){
			Color currentColor = ObjectData.getColorForType(this.primaryType);
			
			g.setColor(currentColor);
			
			g.fillRect(this.x + xModifier, this.y + yModifier, this.width, this.height);
		}else{
			
			System.err.println("what the heck is happening!!!");
		
			byte currentType = this.primaryType;
			
			Color currentColor = ObjectData.getColorForType(currentType);
			g.setColor(currentColor);
			
			g.fillRect(x + xModifier, y + yModifier, pixels.length, pixels[0].length);
			
			for(int x=0; x < pixels.length; x++){
				for(int y=0; y<pixels[0].length; y++){
					currentType = pixels[x][y];
					
					if(currentType != 0){
				
						currentColor = ObjectData.getColorForType(currentType);
						g.setColor(currentColor);
						
						int trueX = this.x + x + xModifier;
						int trueY = this.y + y + yModifier;
						
						g.drawRect(trueX,trueY,1,1);
					}
				}
				
			}
		}
		
		if(setExplodeController!=null){
			explode(setExplodeController, setExplodeStrength);
			setExplodeController=null;
		}
	}
	
	public byte isObjectWithin(PhysicsObject object){
		double oldx=object.getOldX(), oldy=object.getOldY();
		double sx=this.x+1, sy=this.y;
		double ex = this.x + this.width;
		double ey = this.y + this.height;
		
		double pex = object.getX() + object.getWidth(); // object end x
		double pey = object.getY() + object.getHeight(); // object end y

		byte whatToReturn = NO_COLLISION;
		/*whatToReturn = GameFactory.getCollisionSide(new double[]{
				oldx+1, oldy+1, oldx+object.width-1, oldy+object.height-1, object.x-oldx, object.y-oldy}, 
				new double[]{
				x, y, x+width, y+height, 0, 0
		});*/
		
		// first check if is in
		if(whatToReturn==NO_COLLISION&&object.x <= ex && object.y <= ey && pex >= sx && pey >= sy){
			
			double min=Double.POSITIVE_INFINITY;
			/*if(oldy + object.getHeight() <= sy && oldx + object.getWidth() <= sx){
				double d=Math.max(sy - (oldy + object.getHeight()), sx - oldx + object.getWidth());
				if(d<min){
					min=d;
					whatToReturn = TOP_LEFT_COLLISION;
				}
			}
			if(oldy + object.getHeight() <= sy && oldx >= ex){
				double d=Math.max(sy - (oldy + object.getHeight()), oldx - ex);
				if(d<min){
					min=d;
					whatToReturn = TOP_RIGHT_COLLISION;
				}
			}
			if(oldy >= ey && oldx >= ex){
				double d=Math.max(oldy - ey, oldx - ex);
				if(d<min){
					min=d;
					whatToReturn = BOTTOM_RIGHT_COLLISION;
				}
			}
			if(oldy >= ey && oldx + object.getWidth() <= sx){
				double d=Math.max(oldy - ey, sx - oldx + object.getWidth());
				if(d<min){
					min=d;
					whatToReturn = BOTTOM_LEFT_COLLISION;
				}
			}*/
			if(oldx >= ex){
				if(oldx - ex<min){
					min=oldx - ex;
					whatToReturn = RIGHT_COLLISION;
				}
			}
			if(oldx + object.getWidth() <= sx){
				if(sx - (oldx + object.getWidth())<min){
					min=sx - (oldx + object.getWidth());
					whatToReturn = LEFT_COLLISION;
				}
			}
			if(oldy + object.getHeight() <= sy){
				if(sy - (oldy + object.getHeight())<min){
					min=sy - (oldy + object.getHeight());
					whatToReturn = TOP_COLLISION;
				}
			}
			if(oldy >= ey){
				if(oldy - ey<min){
					min=oldy - ey;
					whatToReturn = BOTTOM_COLLISION;
				}
			}
		}
		//if(object instanceof Player && whatToReturn > 0) System.out.println(whatToReturn);
		return whatToReturn;
	}
	
	public boolean drop(LostHope controller){
		if(canPickUp && !exploded){
			exploded=true;
			return true;
			//LostHope.factory.convertGameObjectToParticle(this);
			//releaseTouchingParticles(controller, controller.getCurrentLocation());
		}
		return false;
	}
	
	public void explode(LostHope controller, double strength){
		//Random r = new Random();
		if(exploded) return;
		exploded=true;
		
		double min = -strength;
		double max = strength;

		double diff = max - min;
	
		//int xMid = pixels.length / 2;
		//int yMid = pixels[0].length / 2;
		
		int pixelCounterX = 0;
		int pixelCounterY = 0;
		
		for(int x=0; x < pixels.length; x = x + 1){
			pixelCounterY = 0;
			for(int y=0; y<pixels[0].length; y = y + 1){
					
				Particle tempParticle;
				
				//System.out.println("x: " + pixelCounterX);
				//System.out.println("y: " + pixelCounterY);
				
				if(pixels[pixelCounterX][pixelCounterY] != 0){
					//tempParticle = new Particle(x + this.x,y + this.y, pixels[x][y]);
					tempParticle = LostHope.factory.createParticle((x * 2) + this.x, (y * 2) + this.y, pixels[pixelCounterX][pixelCounterY]);
				}else{
					//tempParticle = new Particle(x + this.x, y + this.y, this.primaryType);
					tempParticle = LostHope.factory.createParticle((x * 2) + this.x, (y * 2) + this.y, this.primaryType);
				}
				
				tempParticle.setXSpeed(min + diff * Math.random());
				tempParticle.setYSpeed(min + diff * Math.random());

				
				pixels[pixelCounterX][pixelCounterY] = 0;
				
				pixelCounterY = pixelCounterY + 1;
				
				//location.addParticle(tempParticle);
			}
			
			pixelCounterX = pixelCounterX + 1;
		}
		
		LostHope.factory.destroyGameObject(this);
		//controller.removePlayerMoveListener(this);
		
	//	Player player = controller.getCurrentPlayer();
		
	//	player.removeObjectCollidingWith(this);
		
		//this.releaseTouchingParticles(controller, location);
	}
	
	private LostHope setExplodeController;
	private double setExplodeStrength;
	public void setExplode(LostHope controller, double strength){
		setExplodeController=controller;
		setExplodeStrength=strength;
	}
	
	@Override
	public void forceApplied(double force, LostHope controller){
		if(Math.abs(force) > 7){ // if hardness is overcome
			this.explode(controller, Math.abs(force) * .25); // DOOOOOOOOM
		}
	}

	@Override
	public void setPower(int power) {
		//this.explode(controller, this.);
	}

	@Override
	public void magicExplode(LostHope controller, int power) {
		this.explode(controller, power);
	}
	
	@Override
	public void toggleHold(boolean isHeld){
		// not sure we have to do anything
	}

	@Override
	public MagicPrimitive createCopyOfSelf() {
		GameObject copy = LostHope.factory.createGameObject(this.primaryType, x, y, width, height);
		
		return copy;
	}

}
