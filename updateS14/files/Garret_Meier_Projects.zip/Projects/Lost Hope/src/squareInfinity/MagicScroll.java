package squareInfinity;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class MagicScroll extends UseableItem{
	
	private String code;

	public MagicScroll(String code, String name) throws IOException {
		super("Scroll of " + name, 1, 0, new Dimension(5,15), ImageIO.read(new File("Pic/Misc/scroll.png")), false);
		
		this.code = code;
	}
	
	public String getCode(){
		return this.code;
	}
	
	public void setCode(String code){
		this.code = code;
	}
	
	public void useScroll(LostHope controller){
		MagicInterpreter mi = new MagicInterpreter(null, controller);
		
		mi.parseMagicCode(this.code);
		
		controller.getCurrentPlayer().removeItemFromInventory(this);
		controller.equipItem(0);
	}

}
