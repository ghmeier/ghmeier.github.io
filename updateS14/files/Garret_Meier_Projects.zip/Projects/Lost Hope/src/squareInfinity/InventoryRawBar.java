package squareInfinity;

import java.util.ArrayList;

public class InventoryRawBar extends InventoryItem{

	protected byte type;
	
	protected int width;
	protected int height;
	
	private InventoryRawBar(String name, byte type, int width, int height, int weight) {
		super(name, weight);
		
		this.type = type;
	}
	
	public byte getType(){
		return this.type;
	}
	
	public static InventoryRawBar createRawBar(Player player, int width, int height){
		ArrayList<InventoryItem> inventory = player.getInventory();
		
		// check if player has enough of a raw material
		
		for(int x=0; x<inventory.size(); x++){
			InventoryItem item = inventory.get(x);
			
			if(item instanceof InventoryPeicesHolder){
				InventoryPeicesHolder iph = (InventoryPeicesHolder) item;
				
				int testHeight = (int) (iph.getCount() / width);
				
				if(testHeight >= height){
					// there is enough material to make a block of that size.
					
					InventoryRawBar temp = new InventoryRawBar("Raw Bar", iph.getType(), width, height, 3);
					
					iph.setCount(iph.getCount() - (width * height));
					
					player.addItemToInventory(temp);
					
					return temp;
				}
			}
		}
		
		return null;
	}

}
