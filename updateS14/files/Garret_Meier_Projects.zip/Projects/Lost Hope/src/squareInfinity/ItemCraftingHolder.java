package squareInfinity;

public class ItemCraftingHolder {
	
	private int x;
	private int y;
	
	private PrimitiveItem item;
	
	public ItemCraftingHolder(int x, int y, PrimitiveItem item){
		this.x = x;
		this.y = y;
		
		this.item = item;
	}
	
	public void setX(int x){
		this.x = x;
	}
	
	public void setY(int y){
		this.y = y;
	}
	
	public int getX(){
		return this.x;
	}
	
	public int getY(){
		return this.y;
	}
	
	public PrimitiveItem getItem(){
		return this.item;
	}

}
