package squareInfinity;

//import java.awt.Point;

public interface ObjectCollisionListener {
	
	public void hasCollidedWithObject(PhysicsObject object2, GameObject object, byte collisionInfo);
	public void hasCollidedWithObject(PhysicsObject object1, PhysicsObject object2, byte collisionInfo);

}
