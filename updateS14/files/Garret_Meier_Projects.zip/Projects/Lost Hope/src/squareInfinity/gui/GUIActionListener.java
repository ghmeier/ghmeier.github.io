package squareInfinity.gui;

public interface GUIActionListener {
	public void elementClicked(GUIElement element);
}
