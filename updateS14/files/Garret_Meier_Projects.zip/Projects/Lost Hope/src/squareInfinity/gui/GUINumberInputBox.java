package squareInfinity.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;

public class GUINumberInputBox extends GUIElement implements KeyListener{

	protected static final char[] acceptedValues = {'0','1','2','3','4','5','6','7','8','9'};
	
	protected int value;
	protected boolean selected;
	
	protected Font font;
	
	protected long lastTimeMouseClicked = 0;
	
	public GUINumberInputBox(int x, int y, int width, int height, JPanel controller) {
		super(x, y, width, height);
		
		this.value = 0;
		this.selected = false;
		
		controller.addKeyListener(this);
		
		this.font = new Font("Times New Roman", Font.PLAIN, 12);
	}
	
	public void dispose(){
		// TODO: remove key listener here
	}
	
	public void setFont(Font font){
		this.font = font;
	}
	
	@Override
	public void mouseHasClickedOn(){
		if(System.currentTimeMillis() - lastTimeMouseClicked >= 100){
			lastTimeMouseClicked = System.currentTimeMillis();
			this.selected = !this.selected;
		}
		
		//System.out.println("mouse clicked on");
	}

	@Override
	public void drawSelf(Graphics g, boolean mouseIsOver) {
		g.setColor(Color.DARK_GRAY);
		
		g.fillRect(x, y, width, height);
		
		if(this.selected || mouseIsOver){
			g.setColor(Color.YELLOW);
			g.drawRect(x,y,width,height);
			
			g.setColor(Color.BLACK);
			
			g.drawString(this.value + "", x + 1, y + 1 + 12);
		}else{
			g.setColor(Color.LIGHT_GRAY);
			
			g.drawRect(x,y,width,height);
		}
	}
	
	@Override
	public void keyPressed(char key){
		if(isInAcceptedValues(key)){
			int number = Integer.parseInt(key + "");
			
			this.value = this.value + number;
		}
	}
	
	private boolean isInAcceptedValues(char key){
		for(int x=0; x<acceptedValues.length; x++){
			if(key == acceptedValues[x]){
				return true;
			}
		}
		
		return false;
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		keyPressed(arg0.getKeyChar());
		System.out.println("key pressed");
	}

	@Override
	public void keyReleased(KeyEvent arg0) {}

	@Override
	public void keyTyped(KeyEvent arg0) {
		keyPressed(arg0.getKeyChar());
	}

}
