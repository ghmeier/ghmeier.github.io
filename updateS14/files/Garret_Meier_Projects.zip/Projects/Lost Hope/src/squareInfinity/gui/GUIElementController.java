package squareInfinity.gui;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;

public class GUIElementController{
	
	private GUIElement[][] elements;
	private ArrayList<GUIElement> currentElements;
	
	private GUIAlignment currentAlignment;
	
	private int width;
	private int height;
	
	private int mouseX;
	private int mouseY;
	
	private boolean mouseClicked;
	
	public GUIElementController(int width, int height){
		elements = new GUIElement[width][height];
		currentElements = new ArrayList<GUIElement>();
		
		this.width = width;
		this.height = height;
		
		this.mouseX = -1;
		this.mouseY = -1;
	}
	
	public GUIAlignment getCurrentAlignment(){
		return this.currentAlignment;
	}
	
//	public void add(GUIElement element){
//		for(int x=element.getX(); x<element.getX() + element.getWidth(); x++){
//			for(int y=element.getY(); y<element.getY() + element.getHeight(); y++){
//				this.elements[x][y] = element;
//			}
//		}
//		
//		currentElements.add(element);
//	}
	
//	public void remove(GUIElement element){
//		elements[element.getX()][element.getY()] = null;
//		currentElements.remove(element);
//	}
	
	public void setCurrentAlignment(GUIAlignment alignment){
		this.currentAlignment = alignment;
	}

	public void drawElements(Graphics g){
//		Iterator <GUIElement> elementIterator = this.currentElements.iterator();
//		
//		while(elementIterator.hasNext()){
//			GUIElement element = elementIterator.next();
//			
//			element.drawSelf(g, isMouseWithinElement(element));
//		}
		
//		System.out.println("MouseX: " + mouseX);
//		System.out.println("MouseY: " + mouseY);
		
		this.currentAlignment.drawSelf(g);
	}
	
	public void mouseChanged(int mouseX, int mouseY, boolean mouseClicked){
		this.mouseX = mouseX;
		this.mouseY = mouseY;
		this.mouseClicked = mouseClicked;
		
//		if(mouseClicked){
//			Iterator<GUIElement> elementIterator = currentElements.iterator();
//			
//			while(elementIterator.hasNext()){
//				GUIElement currentElement = elementIterator.next();
//				
//				if(isMouseWithinElement(currentElement)){
//					currentElement.mouseHasClickedOn();
//				}
//			}
//		}
		
		currentAlignment.mouseChanged(mouseX, mouseY, mouseClicked);
	}
	
	public boolean isMouseWithinElement(GUIElement element){
		return mouseX >= element.getX() && mouseY >= element.getY() && 
				mouseX <= element.getX() + element.getWidth() && mouseY <= element.getY() + element.getHeight();
	}
	
	public boolean isElementAt(int x, int y){
		return this.elements[x][y] != null;
	}
	
	public void keyPressed(char key){
		Iterator<GUIElement> elementsIterator = currentElements.iterator();
		
		while(elementsIterator.hasNext()){
			GUIElement currentElement = elementsIterator.next();
			
			currentElement.keyPressed(key);
		}
	}
	
	
}
