package squareInfinity.gui;

import squareInfinity.InventoryItem;

public class GUIItemButton extends GUIButton{

	private InventoryItem item;
	
	public GUIItemButton(int x, int y, String buttonName) {
		super(x, y, buttonName);
	}
	
	public void setItem(InventoryItem item){
		this.item = item;
	}
	
	public InventoryItem getItem(){
		return this.item;
	}

}
