package squareInfinity.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

public class GUIButton extends GUIElement{

	private String buttonName;
	private Font font;
	
	public GUIButton(int x, int y, String buttonName) {
		super(x, y, 1, 1);
		
		this.buttonName = buttonName;
		
		this.font = new Font("Times New Roman", Font.PLAIN, 12);
	}
	
	public void setFont(Font font){
		this.font = font;
	}
	
	public void setName(String name){
		this.buttonName = name;
	}

	@Override
	public void drawSelf(Graphics g, boolean mouseIsOver) {
		g.setFont(this.font);
		FontMetrics fm = g.getFontMetrics();
		
		int nameSize = fm.stringWidth(buttonName);
		
		this.setWidth(nameSize + 4);
		this.setHeight((int) font.getSize2D() + 4);
		
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(this.x, this.y, this.width, this.height);
		if(mouseIsOver){
			g.setColor(Color.YELLOW);
			g.drawRect(this.x, this.y, this.width, this.height);
		}
		
		g.setColor(Color.BLACK);
		g.drawString(this.buttonName, this.x + 2, this.y + (int) this.font.getSize2D() + 1);
	}

	@Override
	public void keyPressed(char key) {
		// TODO key pressed
	}

}
