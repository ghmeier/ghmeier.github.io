package squareInfinity.gui;

import java.awt.Graphics;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class GUIAlignment {
	
	private HashSet<GUIElement> currentElements;
	private GUIElement[][] elements;
	
	private int x;
	private int y;
	
	private int width;
	private int height;
	
	private int mouseX;
	private int mouseY;
	
	private boolean mouseDown;
	
	public GUIAlignment(int x, int y, int width, int height){
		this.x = x;
		this.y = y;
		
		this.width = width;
		this.height = height;
		
		this.mouseX = -1;
		this.mouseY = -1;
		
		currentElements = new HashSet<GUIElement>();
		elements = new GUIElement[width][height];
	}
	
	public void addElement(GUIElement element){
		if(element.getX() >= 0 && element.getY() >= 0 && element.getX() + element.getWidth() < width && element.getY() + element.getHeight() < height){
			for(int x = element.getX(); x <= element.getX() + element.getWidth(); x++){
				for(int y=element.getY(); y <= element.getY() + element.getHeight(); y++){
					elements[x][y] = element;
				}
			}
			
			currentElements.add(element);
		}
	}
	
	public void removeElement(GUIElement element){
		for(int x = element.getX(); x <= element.getX() + element.getWidth(); x++){
			for(int y=element.getY(); y <= element.getY() + element.getHeight(); y++){
				elements[x][y] = null;
			}
		}
		
		this.currentElements.remove(element);
	}
	
	public void mouseChanged(int mouseX, int mouseY, boolean mouseDown){		
		this.mouseX = mouseX;
		this.mouseY = mouseY;
		
		this.mouseDown = mouseDown;
		
		if(mouseDown){
			Iterator<GUIElement> elementsIterator = ((Collection<GUIElement>)currentElements.clone()).iterator();
			
			while(elementsIterator.hasNext()){
				GUIElement currentElement = elementsIterator.next();
				
				if(isMouseWithinElement(currentElement)){
					currentElement.mouseHasClickedOn();
				}
			}
		}
	}
	
	
	
	public void drawSelf(Graphics g){
		Iterator <GUIElement> elementIterator = this.currentElements.iterator();
		
		while(elementIterator.hasNext()){
			GUIElement element = elementIterator.next();
			
			element.drawSelf(g, isMouseWithinElement(element));
		}
	}
	
	private boolean isMouseWithinElement(GUIElement element){
		return mouseX >= element.getX() && mouseY >= element.getY() && mouseX <= element.getX() + element.getWidth() &&
				mouseY <= element.getY() + element.getHeight();
	}
	

}
