package squareInfinity.gui;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;

public abstract class GUIElement {
	
	protected int x;
	protected int y;
	
	protected int width;
	protected int height;
	
	protected long oldTime;
	protected boolean waiting;
	
	protected ArrayList<GUIActionListener> listeners;
	
	public GUIElement(int x, int y, int width, int height){
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		
		this.oldTime = System.currentTimeMillis();
		
		this.listeners = new ArrayList<GUIActionListener>();
	}
	
	public void addActionListener(GUIActionListener listener){
		this.listeners.add(listener);
	}
	
	public void removeActionListener(GUIActionListener listener){
		this.listeners.remove(listener);
	}
	
	public void mouseHasClickedOn(){
		if(!waiting){
			Iterator<GUIActionListener> listenerIterator = listeners.iterator();
			
			while(listenerIterator.hasNext()){
				GUIActionListener listener = listenerIterator.next();
				
				listener.elementClicked(this);
			}
			
			waiting = true;
			oldTime = System.currentTimeMillis();
		}else{
			long currentTime = System.currentTimeMillis();
			
			if(currentTime - oldTime >= 250){ // wait 250 ms
				waiting = false;
			}
		}
	}
	
	public abstract void keyPressed(char key);
	
	public abstract void drawSelf(Graphics g, boolean mouseIsOver);

	public int getX() {
		return x;
	}


	public void setX(int x) {
		this.x = x;
	}


	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

}
