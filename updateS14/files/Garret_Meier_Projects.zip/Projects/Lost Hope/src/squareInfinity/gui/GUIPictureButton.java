package squareInfinity.gui;

import java.awt.Graphics;
import java.awt.Image;

public class GUIPictureButton extends GUIElement{
	
	private Image defaultImage;
	private Image mouseOverImage;
	
	public GUIPictureButton(int x, int y, Image defaultImage, Image mouseOverImage) {
		super(x, y, 0, 0);
		
		this.defaultImage = defaultImage;
		this.mouseOverImage = mouseOverImage;
		
		this.width = defaultImage.getWidth(null);
		this.height = defaultImage.getHeight(null);
	}
	
	@Override
	public void drawSelf(Graphics g, boolean mouseIsOver) {
		if(mouseIsOver){
			g.drawImage(defaultImage, x, y, null);
		}else{
			g.drawImage(mouseOverImage, x, y, null);
		}
	}

	@Override
	public void keyPressed(char key) {
		// TODO key pressed
	}
	
	

}
