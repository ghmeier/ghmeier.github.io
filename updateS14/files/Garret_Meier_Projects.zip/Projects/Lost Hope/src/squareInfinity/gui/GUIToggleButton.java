package squareInfinity.gui;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;

public class GUIToggleButton extends GUIElement{

	private String message;
	private boolean state;
	
	public GUIToggleButton(int x, int y, String message) {
		super(x, y, 0, 0);
		
		this.message = message;
		this.state = false;
	}
	
	public boolean getState(){
		return this.state;
	}
	
	public void setState(boolean state){
		this.state = state;
	}
	
	public String getMessage(){
		return this.message;
	}
	
	@Override
	public void mouseHasClickedOn(){
		//System.err.println("mouse has clicked on toggle");
		
		this.state = ! this.state;
		
//		try {
//			Thread.sleep(100);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
	}

	@Override
	public void drawSelf(Graphics g, boolean mouseIsOver) {
		String trueName = message;
		
		if(state){
			trueName = trueName + ": on";
		}else{
			trueName = trueName + ": off";
		}
		
		FontMetrics fm = g.getFontMetrics();
		
		int widthOfText = fm.stringWidth(trueName);
		
		this.setWidth(widthOfText + 4);
		this.setHeight(16);
		
		
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(this.x, this.y, this.width, this.height);
		
		if(mouseIsOver){
			g.setColor(Color.YELLOW);
		}else{
			g.setColor(Color.DARK_GRAY);
		}
		
		g.drawRect(this.x, this.y, this.width, this.height);
	
		
		g.setColor(Color.BLACK);
		g.drawString(trueName, this.x + 2, this.y + 14);
		
		
	}

	@Override
	public void keyPressed(char key) {
		// TODO key pressed
	}

}
