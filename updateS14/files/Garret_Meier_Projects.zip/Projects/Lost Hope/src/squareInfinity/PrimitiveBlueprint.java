package squareInfinity;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class PrimitiveBlueprint {
	
	public static final byte DEAD_SLOT = 0;
	public static final byte OUTLINE_SLOT = Byte.MAX_VALUE;
	public static final byte FILL_SLOT = 1;
	public static final byte EMPTY_SLOT = Byte.MIN_VALUE;
	public static final byte HAND_SLOT = 2;
	
	private int width;
	private int height;
	
	private String name;
	
	private int reach;
	private int baseDamage;
	
	private Dimension handLocation;
	
	private byte[][] slots;
	
	private boolean[][] snapPoints;
	
	public PrimitiveBlueprint(int width, int height){
		this.width = width;
		this.height = height;
		
		this.name = "";
		
		this.slots = new byte[width][height];
		this.snapPoints = new boolean[width][height];
		
		fillAllSlotsWith(DEAD_SLOT);
	}
	
	private void fillAllSlotsWith(byte value){
		for(int x=0; x<width; x++){
			for(int y=0; y<height; y++){
				slots[x][y] = value;
			}
		}
	}
	
	public void setHandLocation(int x, int y){
		this.handLocation = new Dimension(x,y);
	}
	
	public Dimension getHandLocation(){
		return this.handLocation;
	}
	
	public int getWidth(){
		return this.width;
	}
	
	public int getHeight(){
		return this.height;
	}
	
	public int getReach(){
		return this.reach;
	}
	
	public int getBaseDamage(){
		return this.baseDamage;
	}
	
	public byte[][] getValues(){
		return this.slots;
	}
	
	public void setValueAt(int x, int y, byte value){
		this.slots[x][y] = value;
	}
	
	public byte getValueAt(int x, int y){
		return this.slots[x][y];
	}
	
	public void setSnapPoint(int x, int y, boolean isSnapPoint){
		this.snapPoints[x][y] = isSnapPoint;
	}
	
	public boolean isSnapPoint(int x, int y){
		return this.snapPoints[x][y];
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String getName(){
		return this.name;
	}
	
	public void drawSelf(int x, int y, int xScale, int yScale, Graphics g){
		for(int xCounter=0; xCounter<width; xCounter++){
			for(int yCounter=0; yCounter<height; yCounter++){
				byte currentValue = this.slots[x][y];
				
				if(currentValue != DEAD_SLOT){
					if(currentValue == OUTLINE_SLOT){
						g.setColor(Color.BLACK);
					}else if(currentValue == EMPTY_SLOT){
						g.setColor(Color.WHITE);
					}else{
						Color theColor = ObjectData.getColorForType(currentValue);
					}
					
					int trueX = (xCounter * xScale) + x;
					int trueY = (yCounter * yScale) + y;
					
					g.fillRect(trueX, trueY, xScale, yScale);
				}else{
					// nothing
				}
			}
		}
	}
	
	////////// LOADING STUFF //////////////////
	
	public static PrimitiveBlueprint getFromFile(String filename){
		
		File f = new File(filename);
		
		try {
			Scanner s = new Scanner(f);
			
			String name = s.nextLine();
			name.trim();
			
			
			
			int width = Integer.parseInt(s.nextLine().trim());
			int height = Integer.parseInt(s.nextLine().trim());
			
			PrimitiveBlueprint pb = new PrimitiveBlueprint(width, height);
			
			pb.setName(name);
			
			for(int y=0; y<height; y++){
				String line = s.nextLine();
				line.trim();
				
				char[] trueLine = line.toCharArray();
				
				for(int x=0; x<trueLine.length; x++){
					char currentChar = trueLine[x];
					
					if(currentChar == '-'){
						pb.setValueAt(x,y,DEAD_SLOT);
					}else if(currentChar == 'O'){
						pb.setValueAt(x,y,OUTLINE_SLOT);
					}else if(currentChar == 'F'){
						pb.setValueAt(x, y, FILL_SLOT);
					}else if(currentChar == 'S'){
						pb.setSnapPoint(x, y, true);
						pb.setValueAt(x, y, OUTLINE_SLOT);
					}else if(currentChar == 'H'){
						pb.setValueAt(x, y, OUTLINE_SLOT);
						pb.setValueAt(x, y, HAND_SLOT);
						pb.setHandLocation(x, y);
					}else{
						pb.setValueAt(x, y, DEAD_SLOT);
					}
				}
			}
			
			int reach = Integer.parseInt(s.nextLine().trim());
			int baseDamage = Integer.parseInt(s.nextLine().trim());
			
			pb.reach = reach;
			pb.baseDamage = baseDamage;
			
			return pb;
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}		
		
		return null;
	}

}
