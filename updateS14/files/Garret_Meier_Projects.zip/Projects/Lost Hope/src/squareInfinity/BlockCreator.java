package squareInfinity;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class BlockCreator {
	
	protected static final int EMPTY = 1;
	protected static final int NEW_BLOCK = 2;
	
	///
	protected JFrame mainFrame;
	
	protected int currentScreen = EMPTY;
	
	protected JFileChooser fc = new JFileChooser();
	
	public BlockCreator(){
		mainFrame = new JFrame("Block Creator, v0.1");
		
		JMenuBar bar = new JMenuBar();
		mainFrame.setJMenuBar(bar);
		
		JMenu fileItem = new JMenu("File");
		
		JMenuItem newBlockItem = new JMenuItem("New Block");
		newBlockItem.addActionListener(new NewBlockItemListener());
		JMenuItem loadBlockItem = new JMenuItem("Load Block...");
		JMenuItem saveBlockItem = new JMenuItem("Save Current Block...");
		
		
		bar.add(fileItem);
		
		fileItem.add(newBlockItem);
		fileItem.add(loadBlockItem);
		fileItem.add(saveBlockItem);
		
		mainFrame.setSize(600,400);
		mainFrame.setLocationRelativeTo(null);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.setVisible(true);
	}
	
	
	public void addNewBlockPanel(){
		if(!(currentScreen == NEW_BLOCK)){
			Container mainContainer = mainFrame.getContentPane();
			mainContainer.removeAll();
			
			JPanel mainPanel = new JPanel();
			mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
			
			
			JPanel namePanel = new JPanel();
			JLabel nameLabel = new JLabel("Name:");
			JTextField nameField = new JTextField(10);
			namePanel.add(nameLabel);
			namePanel.add(nameField);
			
			
			mainPanel.add(namePanel);
			
			mainContainer.add(BorderLayout.CENTER, mainPanel);
			
			mainFrame.setSize(600,400);
			
			this.currentScreen = NEW_BLOCK;
		}
	}
	
	
	
	public class NewBlockItemListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			addNewBlockPanel();
		}
		
	}
	
	
	
	
	public static void main(String[] args){
		//BlockCreator fred = new BlockCreator();
	}

}
