package squareInfinity;

public class CraftingPlaceholder extends InventoryItem{

	public CraftingPlaceholder(String name, int weight) {
		super(name, weight);
	}

}
