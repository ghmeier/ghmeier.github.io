package squareInfinity;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

public class Weapons {
	// default weapons
	public static final byte LONGBOW = -1;
	public static final byte IRONSWORD = -2;
	public static final byte AXE = -3;
	public static final byte WOODSTAFF = -4;

	protected Set<String> createdWeapons = new HashSet<String>();

	//
	public void addWeapon(String name) {
		if (!createdWeapons.contains(name + ".png")) {
			createdWeapons.add(name + ".png");
			// create a reflection of the image and save it with name + L.png
		} else {
			// tell user that the name is already used
		}
	}

	public static void drawWeapon(Player player, LostHope controller, Graphics g, int xModifier, int yModifier) {
		
		BufferedImage imageToDraw = (BufferedImage) player.getEquippedItem().getIcon();

		double amountToRotate = 1.0;

		Dimension rotationPoint = player.getEquippedItem().getRotationPoint();

		int handX;
		int handY;
		
		int drawPointX;
		int drawPointY;

		
		//if(player.isForward() != player.getOldDirection()){
			if (player.isForward()) {
				handX = (int) player.x + player.getHandXOffset();
				handY = (int) player.y + player.getHandYOffset();
	
				drawPointX = (int) (handX - rotationPoint.getWidth()+xModifier);
				drawPointY = (int) (handY - rotationPoint.getHeight()+yModifier);
	
				player.setHandX(handX);
				player.setHandY(handY);
			} else {
				handX = (int) player.x + player.getHandXOffset();
				handY = (int) player.y + player.getHandYOffset();
	
				int trueWidth = (int) (player.getEquippedItem().icon.getWidth(null) - rotationPoint.getWidth());
				
				drawPointX = (int) (handX - trueWidth+xModifier);
				drawPointY = (int) (handY - rotationPoint.getHeight()+yModifier);
	
				player.setHandX(handX);
				player.setHandY(handY);
			}
//		}else{
//			if(player.isForward()){
//				handX = player.getHandX();
//				handY = player.getHandY();
//				
//				drawPointX = (int) (Math.abs(player.getX() - handX) + player.getX());
//				drawPointY = (int) (Math.abs(player.getY() - handY) + player.getY());
//				
//				
//			}else{
//				handX = player.getHandX();
//				handY = player.getHandY();
//				
//				int trueWidth = (int) (player.getEquippedItem().icon.getWidth(null) - rotationPoint.getWidth());
//				
//				drawPointX = (int) (handX - trueWidth+xModifier);
//				drawPointY = (int) (handY - rotationPoint.getHeight()+yModifier);
//				
//				
//			}
//		}

		if (!controller.attacking) {

			// BufferedImage imageToDraw = (BufferedImage)
			// player.getEquippedItem().getIcon();

			if (player.isForward()) {
				g.drawImage(imageToDraw, drawPointX, drawPointY, null);

			} else {

				AffineTransform at = AffineTransform.getScaleInstance(-1, 1);
				at.translate(-imageToDraw.getWidth(), 0);
				AffineTransformOp op = new AffineTransformOp(at,
						AffineTransformOp.TYPE_NEAREST_NEIGHBOR);

				BufferedImage image = op.filter(imageToDraw, null);

				g.drawImage(image, drawPointX, drawPointY, null);

			}
			player.hasSwung = false;

			// player.turn = 0.0;

		} else {

			if (player.getEquippedItem().doesRotate()) {

				Graphics2D g2d = (Graphics2D) g;
				if (player.isForward()) {
					// System.out.println("rotating " + turn);
					// g2d.rotate(player.turn,controller.wPivotPoint, player.y);
					// // Rotate the image by turn radians.
					g2d.rotate(amountToRotate, handX + xModifier, handY + yModifier);
					// player.turn += .5;
					g2d.drawImage(imageToDraw, drawPointX, drawPointY, null);
					g2d.rotate(-amountToRotate, handX + xModifier, handY + yModifier);
				} else {
					// System.out.println("rotating " + turn);

					// g2d.rotate(player.turn,controller.wPivotPoint, player.y);
					// // Rotate the image by turn radians.
					g2d.rotate(-amountToRotate, handX + xModifier, handY + yModifier);
					// player.turn -= .5;

					AffineTransform at = AffineTransform
							.getScaleInstance(-1, 1);
					at.translate(-imageToDraw.getWidth(), 0);
					AffineTransformOp op = new AffineTransformOp(at,
							AffineTransformOp.TYPE_NEAREST_NEIGHBOR);

					BufferedImage image = op.filter(imageToDraw, null);

					g2d.drawImage(image, drawPointX, drawPointY, null);

					g2d.rotate(amountToRotate, handX + xModifier, handY + yModifier);
				}

				if (!player.hasSwung) {
					player.checkWeaponCollision(controller.getCurrentLocation());
					player.hasSwung = true;
				}
			} else {
				if (player.isForward()) {
					g.drawImage(imageToDraw, drawPointX, drawPointY, null);
				} else {
					AffineTransform at = AffineTransform
							.getScaleInstance(-1, 1);
					at.translate(-imageToDraw.getWidth(), 0);
					AffineTransformOp op = new AffineTransformOp(at,
							AffineTransformOp.TYPE_NEAREST_NEIGHBOR);

					BufferedImage image = op.filter(imageToDraw, null);

					g.drawImage(image, drawPointX, drawPointY, null);

				}

				if (!player.hasSwung) {
					player.checkWeaponCollision(controller.getCurrentLocation());
					player.hasSwung = true;
				}
			}

			/*
			 * if(player.turn > 2){ player.turn = 2; }else if(player.turn < -2){
			 * player.turn = -2; }
			 */

		}
	}

}
