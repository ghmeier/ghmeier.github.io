package squareInfinity;

public class Design {
	
	private byte[][][] stuff;
	
	private int numberOfLayers;
	private int width;
	private int height;
	private byte type;
	
	public static byte HOUSE = 0;
	public static byte WELL = 1;
	public static byte BLACKSMITH = 2;
	public static byte MARKET = 3;
	public static byte INN = 4;
	public static byte OAK_TREE = 5;
	public static byte BIRCH_TREE = 6;
	public static byte FLOWER = 7;
	public static byte CACTUS = 8;
	
	public Design(int width, int height, byte type, int layers){
		this.stuff = new byte[width][height][layers];
		
		this.width = width;
		this.height = height;
		this.type = type;
		this.numberOfLayers = layers;
	}
	
	public int getType() {
		return this.type;
	}
	public int getWidth(){
		return this.width;
	}
	
	public int getHeight(){
		return this.height;
	}
	
	public byte get(int x, int y,int layer){
		return stuff[x][y][layer];
	}
	
	public void set(int x, int y,int layer, byte number){
		stuff[x][y][layer] = number;
	}
	
	public void createSelf(int startX, int startY){
		for (int layer = 0; layer<this.numberOfLayers; layer++){
			for(int x=0; x<stuff.length; x++){
				for(int y=0; y<stuff[0].length; y++){
					if(stuff[x][y][layer]!= 0){
						int trueX = (x + startX) * LostHope.BLOCKSIDE;
						int trueY = (y + startY - stuff[0].length) * LostHope.BLOCKSIDE;
						if(stuff[x][y][layer] == GameBlock.STONE_BLOCK || stuff[x][y][layer]==GameBlock.WOOD_PLANK || stuff[x][y][layer] == GameBlock.WOOD_STAIRS){
							LostHope.factory.createGameObject(stuff[x][y][layer], 
									trueX, trueY);
						}else if(stuff[x][y][layer] ==GameBlock.CHEST){
							Chest chest = new Chest(x*LostHope.BLOCKSIDE,y*LostHope.BLOCKSIDE);
						//}else if(stuff[x][y][layer] == GameBlock.DOOR){
						//	Door door = new Door(x,y);
						}else{
							LostHope.factory.createBackgroundGameObject(stuff[x][y][layer],
									trueX, trueY);
						}
					}
				}
			}
		}
	}

}
