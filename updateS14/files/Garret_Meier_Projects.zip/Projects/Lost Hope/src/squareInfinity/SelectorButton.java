package squareInfinity;

import javax.swing.JButton;

public class SelectorButton extends JButton{
	
	private byte selection;
	
	public SelectorButton(String name, byte selection){
		super(name);
		this.selection = selection;
	}
	
	public byte getSelection(){
		return this.selection;
	}

}
