package squareInfinity;

import java.util.Collection;
import java.util.Iterator;

public class Grass extends Flora {

	public Grass(int x, int y, int width, int height) {
		super(x,y,width,height);
	}
	
	private int lockToGrid(int gridSize, double number){
		return ((int)(number / gridSize)) * gridSize;
	}
	
	@Override
	public void grow(LostHope controller) {
		Location currentLocation = controller.getCurrentLocation();
		
		Collection<GameObject> objectsLeftOfMe = currentLocation.getObjectsAt(lockToGrid(LostHope.BLOCKSIDE,this.x - 15),this.y);
		Collection<GameObject> objectsRightOfMe = currentLocation.getObjectsAt(lockToGrid(LostHope.BLOCKSIDE,this.x + this.width + 15), this.y);
		
		Iterator<GameObject> leftIterator = objectsLeftOfMe.iterator();
		Iterator<GameObject> rightIterator = objectsRightOfMe.iterator();
		
		if(leftIterator.hasNext()){
			GameObject object = leftIterator.next();
			if (object.getPrimaryType()!= GameBlock.WATER) {
				System.err.println("making new grass to the left");
				
				LostHope.factory.createBackgroundGameObject(GameBlock.GRASS, object.getX()*LostHope.BLOCKSIDE, object.getY()*LostHope.BLOCKSIDE);
				Grass tempGrass = new Grass(x,y,LostHope.BLOCKSIDE,LostHope.BLOCKSIDE);
				currentLocation.grass.add(tempGrass);
				controller.plantController.add(tempGrass);
			}
		}
		
		if(rightIterator.hasNext()){
			GameObject object = rightIterator.next();
			
			if (object.getPrimaryType()!= GameBlock.WATER) {
				System.err.println("making new grass to the right");
				
				LostHope.factory.createBackgroundGameObject(GameBlock.GRASS, object.getX()*LostHope.BLOCKSIDE, object.getY()*LostHope.BLOCKSIDE);
				Grass tempGrass = new Grass(x,y,LostHope.BLOCKSIDE,LostHope.BLOCKSIDE);
				currentLocation.grass.add(tempGrass);
				controller.plantController.add(tempGrass);
			}
		}
	}
}
