package squareInfinity;

import java.awt.Graphics;

public abstract class Weather {
	
	public abstract void drawWeather(Graphics g, int xOffset, int yOffset, LostHope controller);

}
