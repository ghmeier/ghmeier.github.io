package squareInfinity;

import java.awt.*;

public class Magic {
	private double power;
	private double areaOfEffect;
	private double positionX;
	private double positionY;
	private double speedX;
	private double speedY;
	
	public Magic(double power, double areaOfEffect, double positionX, double positionY) {
		this.power = power;
		this.areaOfEffect = areaOfEffect;
		this.positionX = positionX;
		this.positionY = positionY;
	}
	
	public void move() {//this has the 'magic' object move one frame at it's speed
		this.positionX = this.positionX + this.speedX;
		this.positionY = this.positionY + this.speedY;
	}
	
	public void drawSelf(Graphics g) {
		//um dont really know what to do here?
		
	}
	
	public void setSpeedX(double x) {
		this.speedX = x;
	}
	
	public void setSpeedY(double y) {
		this.speedY = y;
	}
	
	public void setPower(double power) {
		this.power = power;
	}
	
	public void setAreaOfEffect(double area) {
		this.areaOfEffect = area;
	}
	
	public double getSpeedX() {
		return this.speedX;
	}
	
	public double getSpeedY() {
		return this.speedX;
	}
	
	public double getPositionX() {
		return this.positionX;
	}
	
	public double getPostionY() {
		return this.positionY;
	}
	
	public double getPower() {
		return this.power;
	}
	
	public double getAreaOfEffect() {
		return this.areaOfEffect ;
	}
	
}
