package squareInfinity;

import java.util.ArrayList;

public abstract class Biome {

	protected TerrainType[] validTerrainTypes;
	protected ArrayList<Design> validFloraDesigns;
	private int globalStartX;
	private int globalEndX;
	private int globalStartY;
	private int width;
	private byte type;
	
	public static final byte PLAINS = 0;
	public static final byte FOREST = 1;
	public static final byte HILL = 2;
	public static final byte DESERT = 3;
	
	public Biome(int startX, int startY, int width, byte type) {
		this.globalStartX = startX;
		this.globalEndX = startX + width;
		this.globalStartY = startY;
		this.width = width;
		this.type = type;
		this.validFloraDesigns = new ArrayList<Design>();
	}
	
	//protected abstract void fillArea();//adds surface blocks, flora, stone, and ore
	
	public byte getType() {
		return this.type;
	}
	
	public int getWidth() {
		return this.width;
	}
	
	public int getStartX() {
		return this.globalStartX;
	}
	
	public int getEndX() {
		return this.globalEndX;
	}
	
}
