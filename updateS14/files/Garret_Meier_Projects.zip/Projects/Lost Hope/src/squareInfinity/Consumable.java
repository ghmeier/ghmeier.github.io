package squareInfinity;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Consumable extends InventoryItem{
	
	private static String FILEPATH="Pic/InventoryIcons/";
	
	public static Image HEALTH_POTION_IMAGE= GameFactory.getOptimizedImage(ObjectData.invSize,ObjectData.invSize,FILEPATH +"HealthPotion.png");
	public static Image MAGIC_POTION_IMAGE = GameFactory.getOptimizedImage(ObjectData.invSize,ObjectData.invSize,FILEPATH +"MagicPotion.png");
	public static Image DRUMSTICK= GameFactory.getOptimizedImage(ObjectData.invSize,ObjectData.invSize,FILEPATH +"Drumstick.png");
	public static Image WATER_IMAGE= GameFactory.getOptimizedImage(ObjectData.invSize,ObjectData.invSize,FILEPATH +"GlassWithWater.png");
	
	public static final int HEALTH_POTION = 1;
	public static final int FOOD = 2;
	public static final int WATER = 3;
	public static final int MAGIC_POTION = 4;
	
	///
	
	
	private int amount;
	private int type;
	
	public Consumable(int amount, int type){
		super("Consumeable", 1);
		this.amount = amount;
		this.type = type;
		
		if(this.type == HEALTH_POTION){
			this.setName("Health Potion");
			this.setIcon(HEALTH_POTION_IMAGE);
		}else if(this.type == FOOD){
			this.setName("Drumstick");
			this.setIcon(DRUMSTICK);
		}else if(this.type == MAGIC_POTION){
			this.setName("Magic Potion");
			this.setIcon(MAGIC_POTION_IMAGE);
		}else if(this.type == WATER){
			this.setName("Water Jug");
			this.setIcon(WATER_IMAGE);
		}
		
		if(HEALTH_POTION_IMAGE == null){
			loadAllImages();
		}
	}
	
	public static void loadAllImages(){
		try {
			HEALTH_POTION_IMAGE = ImageIO.read(new File("Pic/Consumables/healthPotion.png"));
			MAGIC_POTION_IMAGE = ImageIO.read(new File("Pic/Consumables/manaPotion.png"));
			DRUMSTICK = ImageIO.read(new File("Pic/Consumables/drumstick.png"));
			WATER_IMAGE = ImageIO.read(new File("Pic/Consumables/water.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void useConsumeable(LostHope controller){
		Player currentPlayer = controller.getCurrentPlayer();
		
		if(type == HEALTH_POTION){
			currentPlayer.increaseHealth(amount);
		}else if(type == FOOD){
			currentPlayer.setHunger(currentPlayer.getHunger() + amount);
		}else if(type == MAGIC_POTION){
			currentPlayer.setPowerPoints(currentPlayer.getPowerPoints() + amount);
		}else if(type == WATER){
			currentPlayer.setWater(currentPlayer.getWater() + amount);
		}else{
			// fail. Epic fail.
		}
		
		currentPlayer.removeItemFromInventory(this);
	}

}
