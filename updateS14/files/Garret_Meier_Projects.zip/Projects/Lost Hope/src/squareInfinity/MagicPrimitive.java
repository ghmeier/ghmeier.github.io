package squareInfinity;

public interface MagicPrimitive {
	
	public void setPower(int power);
	
	public void magicExplode(LostHope controller, int power);
	
	public void toggleHold(boolean isHeld);
	
	public MagicPrimitive createCopyOfSelf();

}
