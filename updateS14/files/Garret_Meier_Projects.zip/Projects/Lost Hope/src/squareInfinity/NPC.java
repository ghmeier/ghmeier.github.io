package squareInfinity;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import squareInfinity.npc.AI;
import squareInfinity.npc.Bear;
import squareInfinity.npc.Bunny;
import squareInfinity.npc.Butterfly;
import squareInfinity.npc.Wolf;
//import java.util.Random;

public abstract class NPC extends PhysicsObject{
	
	// NPC types
	public static final byte BUTTERFLY = 0;
	public static final byte BUNNY = 1;
	public static final byte WOLF = 2;
	public static final byte BEAR = 3;
	//public static final byte SKELETON = 0; 
	
	protected byte type;
	protected static BufferedImage[] NPCImage = new BufferedImage[5];
	protected static BufferedImage[] NPCImageFlipped = new BufferedImage[5];
	private static final String IMAGE_LOCATION= "Pic/Characters/";
	
	protected static final String SKELETON_IMAGE = IMAGE_LOCATION + "skeleton.png";
	protected static final String BUTTERFLY_IMAGE = IMAGE_LOCATION + "Butterfly.png";
	protected static final String BUNNY_IMAGE = IMAGE_LOCATION + "Bunny.png";
	protected static final String WOLF_IMAGE = IMAGE_LOCATION + "Wolf.png";
	protected static final String BEAR_IMAGE = IMAGE_LOCATION + "Bear.png";
	
	//Overall Stats for the NPC and modifiers
	
	protected String name;	
	protected int health;
	protected int maxHealth;
	protected int damage;
	protected boolean isAggressive;	
	protected AI ai;
	protected boolean isRight;
	protected int dexterityModifier;
	protected int staminaModifier;
	protected int strengthModifier;
	protected int sizeModifier;
	protected int modifierVariability;
	
	public static ArrayList<int[]> allBaseStats = new ArrayList<int[]>();//all of the base stats with the type index
	
	
	protected int dexterity;
	protected int stamina;
	protected int strength;
	protected int size;
	
	//Now comes the base stats, unique to each NPC
	
	protected int baseDexterity;
	protected int baseStrength;
	protected int baseStamina;
	protected int baseHealth;
	protected int baseDamage;
	protected int baseSize;
	
	protected Location holder;
	protected Player lastAttacker;	
	
	public NPC(String name, byte type, double x, double y, int width, int height, Location holder){
		super(x,y,width,height, .99);	
		this.name = name;		
		this.type = type;		
		this.holder = holder;
		this.initializeStats();	
		
	}
	
	public static void initImages() throws IOException {
		//NPCImage[SKELETON] = GameFactory.getOptimizedImage(SKELETON_IMAGE);
		NPCImage[BUNNY] = GameFactory.getOptimizedImage(BUNNY_IMAGE);
		NPCImage[BEAR] = GameFactory.getOptimizedImage(BEAR_IMAGE);
		NPCImage[WOLF] = GameFactory.getOptimizedImage(WOLF_IMAGE);
		NPCImage[BUTTERFLY] = GameFactory.getOptimizedImage(BUTTERFLY_IMAGE);
		for(int i=0; i<NPCImage.length; i++) if(NPCImage[i]!=null) 
                    NPCImageFlipped[i]=GameFactory.getFlippedImage(NPCImage[i]);
	}

	
	public void setAI(AI ai){
		this.ai = ai;
	}
	
	public int getDamage(){
		return this.damage;
	}
	
	public boolean getIsAggressive() {
		return this.isAggressive;
	}
	
	public void setLastAttacker(Player player){
		this.lastAttacker = player;
	}
	
	public Player getLastAttacker(){
		return this.lastAttacker;
	}
	
	protected int getBaseDamage() {
		return baseDamage;
	}
	
	
	protected int getBaseDexterity() {
		return baseDexterity;
	}
	
	protected int getBaseHealth() {
		return baseHealth;
	}
	
	protected int getBaseSize() {
		return baseSize;
	}
	
	protected void initializeModifiers(){
		Random r = new Random();
		
		this.dexterityModifier =  r.nextInt(this.modifierVariability*2+1) - this.modifierVariability;
		this.staminaModifier =  r.nextInt(this.modifierVariability*2+1) - this.modifierVariability;
		this.strength = r.nextInt(this.modifierVariability*2+1) - this.modifierVariability;
		this.sizeModifier =  (int)((r.nextInt(this.modifierVariability*2+1) - this.modifierVariability)/2);
	}
	
	public static void initBaseStats() {
		allBaseStats.add(BUTTERFLY, Butterfly.BASESTATS);
		allBaseStats.add(BUNNY, Bunny.BASESTATS);
		allBaseStats.add(WOLF, Wolf.BASESTATS);
		allBaseStats.add(BEAR, Bear.BASESTATS);
	}
	
	protected void initializeStats() {
		int[] stats = allBaseStats.get(this.type);
		this.modifierVariability = stats[6]; 
		this.initializeModifiers();
		this.baseDamage = stats[0];
		this.baseDexterity = stats[1];
		this.baseHealth = stats[2];
		this.baseSize = stats[3] + this.sizeModifier;
		this.baseStamina = stats[4];
		this.baseStrength = stats[5];
		this.strength = this.baseStrength + this.strengthModifier;
		this.stamina = this.baseStamina + this.staminaModifier;
		this.dexterity = this.dexterityModifier + this.baseDexterity;
		this.damage = this.baseDamage + this.strength;
		this.maxHealth = this.baseHealth + this.stamina;
		this.health = this.maxHealth;
		this.size = this.baseSize + this.sizeModifier;		
	}
	
	@Override
	public abstract void drawSelf(Graphics g);
	
	protected abstract void trueDraw(Graphics g);
	
	public void hurt(int amount, boolean forward){
		this.health = this.health - amount;
		
		//System.err.println("NPC got hurt");
		
		if(holder == null){
			System.err.println("blarg");
		}
//		if(forward){
//			this.setXSpeed(-2);
//			this.setYSpeed(-2);
//		}else{
//			this.setXSpeed(2);
//			this.setYSpeed(-2);
//		}
		
		if(this.health <= 0){
			holder.kill(this);
		}
	}

	@Override
	public void setPower(int power) {
		// TODO setpower does nothing
	}

	@Override
	public void magicExplode(LostHope controller, int power) {
		// TODO magic explode does nothing
	}

	@Override
	public MagicPrimitive createCopyOfSelf() {
		//NPC npc = LostHope.factory.createNPC(this.name, this.type, this.x, this.y, this.width, this.height);
		//Cannot create an NPC variable
		return null;
	}

}
