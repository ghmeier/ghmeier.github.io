package squareInfinity;

import java.util.HashMap;
import java.util.Iterator;

public class MagicController {
	
	private HashMap<String, MagicPrimitive> variables;
	
	private LostHope controller;
	
	public MagicController(LostHope controller){
		this.controller = controller;
		
		variables = new HashMap<String, MagicPrimitive>();
	}
	
	public void addVariable(String variableName, MagicPrimitive primitive){
		variables.put(variableName, primitive);
	}
	
	public boolean doesVariableExist(String variableName, boolean output){
		if(variables.containsKey(variableName)){
			return true;
		}else{
			System.err.println("variable" + variableName + " does not exist");
			return false;
		}
	}
	
	public void removeVariable(String variableName){
		variables.remove(variableName);
	}
	
	public void removeVariable(MagicPrimitive primitive){
		Iterator<String> i=variables.keySet().iterator();
		while(i.hasNext()){
			String s=i.next();
			if(variables.get(s).equals(primitive)) i.remove();
		}
	}
	
	public MagicPrimitive getVariable(String variableName){
		return variables.get(variableName);
	}

}
