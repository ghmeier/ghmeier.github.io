package squareInfinity;

public class SuperFlat extends TerrainType {
	public int getModifier() {
		double randomNumber = WorldGenerator.theRandomizer.nextDouble();
		if (randomNumber<=.75) {
			return 0;
		} else {
			return getNegative(1);
		}

	}
}
