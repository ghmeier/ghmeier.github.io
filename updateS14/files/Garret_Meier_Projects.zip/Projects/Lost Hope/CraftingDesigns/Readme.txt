Crafting Design Reamde

A crafting design starts with a name, width, and a height on the first
three lines in that order. It is then followed by lines outlining 
the design, using the following denoting symbols:

"-" = (space) denotes empty or non-design area
"F" = denotes fill area
"O" = denotes the outline for the object
"S" = denotes a "snap-point" for the design (is considered outline, but with special stuff added)
"H" = denotes hand point, or where this design will be held by the player, not all designs will have
	  a hand point, but things like handles should

Following that is basic stats:
reach
base damage