The first line of a design is its type use a number
HOUSE = 0; WELL = 1; BLACKSMITH = 2; MARKET = 3; INN = 4;
A house design has its dimensions in the next two lines
[x]
[y]
then its the number of layers front to back
and then markers below
W = Wood Planks
- = Stone Wall
S = Wood stairs
* = Work Bench
T = Table
C = Chair
^ = Chest
B = Bed
A = Anvil
F = Furnace
# = Stone
L = Ladder

and the filename must have "design-" in front and be a .txt file