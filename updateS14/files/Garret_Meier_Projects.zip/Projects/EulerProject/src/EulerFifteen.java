//Calculating Lattice Paths
public class EulerFifteen {
	
	public static void main(String[] args) {
		int x = 21;
		int y = 21;
		long[][] grid = new long[x][y];
		
		for (int i=0;i<grid.length;i++) {
			grid[i][0] = 1;
		}
		for (int i=0;i<grid.length;i++) {
			grid[0][i] = 1;
		}
		
		for(int i=1;i<grid.length;i++) {
			for(int j=1;j<grid[0].length;j++) {
				grid[i][j]=grid[i-1][j] + grid[i][j-1];
			}
		}
		for(int i=0;i<grid.length;i++) {
			for(int j=0;j<grid[0].length;j++) {
		System.out.print(grid[i][j]+" ");
			}
			System.out.println("");
		}
	}

}
