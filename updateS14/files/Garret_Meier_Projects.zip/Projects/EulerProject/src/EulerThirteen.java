import java.math.BigInteger;
import java.util.Scanner;


public class EulerThirteen {

	public static void main(String[] args) {
		BigInteger theOne = new BigInteger("0");
		Scanner input = new Scanner(System.in);
		int count = 0;
		while(count<100) {
			theOne = theOne.add(new BigInteger(input.next()));
			count++;
			System.out.println(theOne+"\n");
		}
	
	}
}
