import java.math.BigInteger;

//Garret Meier July 2, 2013 it works :)
//Finds the largest prime factor of theNumber
public class ProblemThree {
	public static BigInteger theNumber = new BigInteger("4238232447338372673783443178376482364733");
	public static BigInteger theNumber1 = theNumber;
	public static BigInteger eleven = new BigInteger("11");
	public static BigInteger one = new BigInteger("1");
	public static BigInteger two = new BigInteger("2");
	public static BigInteger zero = new BigInteger("0");
	
	public static void main(String args[]) {
		
		long largestFactor = 0;
		/*for (long i=2;i*i<theNumber;i++) {
			//System.out.println(i);
			if (theNumber%i==0) {
				if (isPrime(i)) {
				if (i>largestFactor) {
					largestFactor = i;
					System.err.println(largestFactor);
				}
				} else if (isPrime(theNumber/i)) {
					if (theNumber/i>largestFactor) {
						largestFactor = theNumber/i;
						System.err.println(largestFactor);
					}
				}
			}
		}*/
		for (BigInteger i=theNumber;i.compareTo(theNumber)<=0;i=i.add(one)) {
			if (isPrime(i)) {
				System.out.println(i);
			}
		}
		
	}
	
	public static boolean isPrime(BigInteger toCheck) {
		
		for (BigInteger i=two; i.multiply(i).compareTo(toCheck)<=0; i=i.add(one)) {
			//System.out.println(i);
			if (toCheck.mod(i).equals(zero)) {
				//System.out.println(i);
				return false;
			}
		}
		return true;
	}
}
