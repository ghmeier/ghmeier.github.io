
public class EulerSeventeen {
	
	public static void main(String[] args) {
		int sum = 0;
		
		for (int i=1;i<=1000;i++) {
			sum = sum + parseNumber(i);
			//System.out.println(parseNumber(i));
		}
		System.out.println(sum);
		//System.out.println(parseNumber(14));
	}
	
	public static int parseNumber(int number) {
		int answer = 0;
		int firstDigit = 0;
		int count = 0;
		while (number>0) {
			firstDigit = number%10;
			number = number/10;

			if (count == 0 && number%10==1) {
				if( (firstDigit<6 && firstDigit!=4) || firstDigit==8) {
				answer --;

				}
			}else if (count==0 && number%100 >0 && number%10==0 && firstDigit!=0) {
				answer = answer+3;

			}else if (count==1) {	
				if (firstDigit==1) {
					answer=answer+4;
				}
				if (number>0 && firstDigit!=0) {
					answer = answer+3;
					
				} else {
					//answer = answer +1;
				}
				
			} else if(count==2) {
				answer = answer + 7;

			} else if(count==3) {
				answer = answer + 1;

			}
			if (count==1) { 
				if (firstDigit ==2 ||firstDigit == 3 || firstDigit==8 || firstDigit==9) {
					answer = answer + 6;
				} else if(firstDigit==4 || firstDigit == 5 || firstDigit==6) {
					answer = answer+5;
				} else if(firstDigit==7) {
					answer = answer + 7;
				}
			}else {
				if (firstDigit== 1 || firstDigit ==2 ||firstDigit == 6) {
					answer = answer + 3;
				} else if(firstDigit==4 || firstDigit == 5 || firstDigit==9) {
					answer = answer+4;
				} else if(firstDigit==3 || firstDigit ==7 || firstDigit==8) {
					answer = answer + 5;
				}
			}
			//System.out.println(answer);
			count ++;
		}
			
		return answer;
	}
}
