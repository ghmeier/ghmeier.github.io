
public class ProblemNineteen {
	
	public static void main(String[] args) {
		int[] daysPerMonth = new int[]{31,28,31,30,31,30,31,31,30,31,30,31};
		int indexOfFirst = 1;
		int sundayCount = 0;
		for (int year=1900;year<=2000;year++) {
			for (int month=0;month<12;month++) {
				indexOfFirst = indexOfFirst + daysPerMonth[month]%7-1;
				//System.out.println(daysPerMonth[month]%7);
				if (month == 1 && year%4==0 ) {
					if (year%400==0) {
						indexOfFirst ++;
					}
				}
				if (indexOfFirst>6) {
					indexOfFirst = indexOfFirst - 7;

				}
				if (indexOfFirst==0 && year>1900) {
					sundayCount ++;
				}
			}
		}
		
		System.out.println(sundayCount);
		
	}

	
}
