import java.math.BigInteger;
//Adds digits of huge numbers!!


public class EulerSixteen {

	public static void main(String[] args) {
		BigInteger myInt = new BigInteger("2").pow(1000);
		BigInteger answer = new BigInteger("0");
		while(myInt.compareTo(BigInteger.ZERO)>0) {
			answer = answer.add(myInt.mod(BigInteger.TEN)); 
			myInt = myInt.divide(BigInteger.TEN);
		}
		System.out.println(answer);
	}
}
