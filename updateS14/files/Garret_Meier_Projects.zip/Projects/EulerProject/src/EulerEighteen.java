
public class EulerEighteen {
	
	public static void main(String[] args) {
		
	}
}
