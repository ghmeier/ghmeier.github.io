import java.util.Scanner;

public class Tongues {
	public static void main(String[] args){
		Scanner in = new Scanner(System.in); 
		char[] vowel = new char[]{'a','i','y','e','o','u'};
		char[] cons = new char[]{'b','k','x','z','n','h','d','c','w','g','p','v','j','q','t','s','r','l','m','f'};
		boolean isUpper = false;
		
		while(in.hasNext()) {
			String line = in.nextLine();
			String outLine = "";
			for (int i= 0; i<line.length();i++) {
				char currentChar = ' ';
				if (line.charAt(i)>='A' && line.charAt(i)<='Z') {
					isUpper = true;
					currentChar = toLower(line.charAt(i));
				} else {
					currentChar = line.charAt(i);
				}
				
				int indexOfCurrent = getChar(cons,currentChar);
				
				if ((currentChar<'a' || currentChar>'z') &&( currentChar<'A' || currentChar>'Z')){
					outLine = outLine + currentChar;
				}else if (indexOfCurrent<0) {
					indexOfCurrent = getChar(vowel,currentChar);
					indexOfCurrent +=3;
					if (indexOfCurrent>=vowel.length) { 
						indexOfCurrent = indexOfCurrent - vowel.length;
					}
					if (isUpper) {
						outLine = outLine + toUpper(vowel[indexOfCurrent]);
					} else {
						outLine = outLine + vowel[indexOfCurrent];
					}
				} else {
					indexOfCurrent += 10;
					if (indexOfCurrent>=cons.length) { 
						indexOfCurrent = indexOfCurrent - cons.length;
					}
					if (isUpper) {
						outLine = outLine + toUpper(cons[indexOfCurrent]);
					} else {
						outLine = outLine + cons[indexOfCurrent];
					}
				}
				isUpper = false;
				
			}
			System.out.println(outLine);
		}
	}
	
	public static int getChar(char[] let, char toFind) {
		int answer = -1;
		
		for (int i=0;i<let.length;i++) {
			if (let[i]==toFind) {
				answer = i;
				break;
			}
			
		}
		
		return answer;
	}
	
	public static char toUpper(char c) {
		return (char) (c-32);
	}
	
	public static char toLower(char c) {
		return (char) (c+32);
	}
}
