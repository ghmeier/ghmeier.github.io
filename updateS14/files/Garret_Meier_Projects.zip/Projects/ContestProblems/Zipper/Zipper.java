import java.util.Scanner;


public class Zipper {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int number = in.nextInt();
		
		for (int i =1 ;i<=number; i++) {
			String one = in.next();
			int oneLength = one.length();
			String[] hold = new String[2];
			String two = in.next();
			int twoLength = two.length();
			String combo = in.next();
			boolean oneFirst = false;
			
			for (int j=0;j<combo.length();j++) {
				if (one.length()>0 && (oneLength-one.length())<=(twoLength - two.length())) {
					hold=  getString(one,two,combo,j);
					one = hold[0];
					two = hold[1];
				} else if (two.length()>0) {
					hold = getString(two,one,combo,j);
					two = hold[0];
					one = hold[1];
				}
				System.out.println(one+" " +two);
			}
			oneFirst = (one.length()==0 && two.length()==0);
			if (oneFirst) {
				System.out.println("Data set "+i+": yes");
			}else {
				System.out.println("Data set "+i+": no");
			}
			
		}
		
	}
	
	public static String[] getString(String one, String two, String look, int at) {
		if (one.length()>0 && one.charAt(0)==look.charAt(at)) {
			return new String[]{one.substring(1),two};
		} else if (two.length()>0 && two.charAt(0)==look.charAt(at)) {
			return new String[]{one,two.substring(1)};
		} else {
			return new String[]{one,two};
		}
	}
}
