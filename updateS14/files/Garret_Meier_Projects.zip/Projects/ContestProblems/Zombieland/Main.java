package Zombieland;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int numberOfRules = in.nextInt();
		in.nextLine();
		String[] rules = new String[numberOfRules];
		
		for(int rule=0;rule<numberOfRules;rule++) {			
			rules[rule] = in.nextLine();
		}
		
		int numberToLookUp = in.nextInt();
		for (int look=0;look<numberToLookUp;look++) {
			int ruleToFind = in.nextInt();
			
			if (ruleToFind>0 && ruleToFind<=numberOfRules) {
				System.out.println("Rule "+ruleToFind+": "+rules[ruleToFind-1]);
			} else {
				System.out.println("Rule "+ruleToFind+": No such rule");
			}
			
		}
		
	}
}
