package BikersOdometer;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double diameter;
		int revolutions;
		double time;
		int tripNumber = 1;
		final double P = 3.1415927;
		
		while (true) {
		diameter = input.nextDouble();
		revolutions = input.nextInt();
		time = input.nextDouble();
		if (revolutions ==0) {
			System.exit(0);
		}
		double distanceInMiles = diameter*P*revolutions/12/5280;
		double MPH = distanceInMiles/(time/3600);
		
		System.out.printf("Trip #%d: %.2f %.2f\n",tripNumber,roundToHund(distanceInMiles),roundToHund(MPH));
		tripNumber++;
		}
	}
	
	public static double roundToHund(double x) {
		double answer = Math.round(x*100);
		return answer/100;
	}
}
