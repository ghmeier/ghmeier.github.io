package CandySharing;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int numberOfStudents;
		while(input.hasNext()) {
			int rounds = 0;
			numberOfStudents = input.nextInt();
			if (numberOfStudents==0) {
				System.exit(0);
			}
			int[] students = new int[numberOfStudents];
			for(int i=0;i<numberOfStudents;i++){
				students[i]=input.nextInt();
			}
			while(!areEqual(students)) {
				students = half(students);
				rounds++;
			}
			System.out.printf("%d %d\n",rounds,students[0]);
			
		}
	}
	
	public static int[] half(int[] students) {
		int[] answer = new int[students.length];
		
		for (int i=0;i<students.length;i++){
			if (i!=0) {
				answer[i] = (students[i-1] + students[i])/2; 
				answer[i]=addToOdds(answer[i]);
			} else {
				answer[0] = (students[0] + students[students.length-1])/2;
				answer[0]=addToOdds(answer[0]);
			}
		}
		
		return answer;
	}
	
	public static int addToOdds(int x) {
		if (x%2!=0) {
			x++;
		}
		return x;
	}
	
	public static boolean areEqual(int[] students) {
		for(int i=0;i<students.length-1;i++) {
			if (students[i]!=students[i+1]){
				return false;
			}
		}
		return true;
	}
}
