package Slitherlink;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		int iterations = in.nextInt();
		int height = in.nextInt();
		int width = in.nextInt();
		
		char[][] puzzle = new char[width*2+1][height*2+1];
		
		for(int j=0;j<puzzle[0].length;j++) {
			String line = in.next();
			for (int i=0;i<puzzle.length;i++) {
				puzzle[i][j] = line.charAt(i);
			}	
		}
		boolean checkResult = checkBoard(puzzle);
		int[] location = findLocation(puzzle);
		boolean isContinuous = checkContinuous(puzzle,location,location);
		if (checkResult && isContinuous) {
			System.out.println("VALID");
		} else {
			System.out.println("INVALID");
		}
	}
	
	public static boolean checkContinuous(char[][] puzzle, int[] location, int[] originalLocation) {
		if (puzzle[]) {
			
		} else {
		return false;
		}
	}
	
	public static int[] findLocation(char[][] puzzle) {
		int i=0;
		int j=0;
		int[] current = new int[2];
		while(puzzle[i][j]!='-' || puzzle[i][j]!='|') {
			if (i<puzzle.length-1) {
				i++;
			} else {
				i=0;
				j+=2;
			}
			current[0] = i;
			current[1] = j;
		}
		return current;
	}
	
	public static boolean checkBoard(char[][] puzzle) {
		int[][] directions = new int[][]{{0,-1},{1,0},{0,1},{-1,0}};
		for(int j=1;j<puzzle[0].length;j=j+2) {
			for (int i=0;i<puzzle.length;i++) {
				if (puzzle[i][j]>='0' && puzzle[i][j]<='3') {
					int number = puzzle[i][j]-48;
					int count = 0;
					for (int  dir=0;dir<directions.length;dir++) {
						char check = puzzle[i+directions[dir][0]][j+directions[dir][1]];
						if (check == '|' || check=='-') {
							count++;
						}
					}
					if (count!=number) {
						return false;
					}
				}
			}	
		}
		return true;
	}
}
