package garret.meier.CompetitionPractice;

public class NoPossibleChainException extends Exception {

}
