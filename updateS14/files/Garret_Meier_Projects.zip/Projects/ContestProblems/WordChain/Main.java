package WordChain;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	private String startWord;
	private String endWord;
	private ArrayList<String> possibleWords;
	

	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		ArrayList<String> test = new ArrayList<String>() ;
//		test.add("curt");
//		test.add("cure");
//		test.add("foul");
//		test.add("fred");
//		test.add("copy");
		String sWord = s.next();
		String eWord = s.next();
		int length = s.nextInt();
		ArrayList<String> array = new ArrayList<String>();
//		String sWord = "Care";
//		String eWord = "Hurt";
//		int length = 5;
//		ArrayList<String> array = test;
		
		for (int i=0;i<length;i++) {
			array.add(s.next().toLowerCase());
		}
		WordChain chain = new WordChain(sWord, eWord, array);
		ArrayList<String> theChain = chain.findChain();
		for (String word: theChain) {
			System.out.println(word);
		}
	}
	
	public WordChain(String startWord, String endWord, ArrayList<String> possibleWords) {
		this.startWord = startWord.toLowerCase();
		this.endWord = endWord.toLowerCase();
		this.possibleWords = possibleWords;
		this.possibleWords.add(this.endWord);
	}
	
	public ArrayList<String> findChain() {
		ArrayList<String> answer = new ArrayList<String>();
		String currentWord = startWord;
		answer.add(currentWord);
		//while (!getEndWord().equals(currentWord)) {
		for (int i =0; i<3;i++) {
			String nextWord;
			try {
				nextWord = findNext(currentWord);
				//System.out.println("CurrentWord: "+currentWord+" NextWord "+nextWord);
				answer.add(nextWord);			
				currentWord = nextWord;
			} catch (NoPossibleChainException e) {
				System.out.println("There is no possible chain here.");
			}
		}
		return answer;
	}
	
	private String getEndWord() {
		return this.endWord;
	}
	
	private String findNext(String currentWord) throws NoPossibleChainException {
			for(String testWord:  possibleWords) {
				int count = 0;
				for (int i=0;i<testWord.length();i++){
					//System.out.println("TestWord: "+testWord+" CurrentWord: "+currentWord + " currentLetter: "+testWord.substring(i,i+1));
					if (currentWord.substring(i,i+1).equals(testWord.substring(i,i+1))) {
						count++;
						//System.out.println("Count: "+count+" i "+i);
					}
				}
				if (count==testWord.length()-1) {
					possibleWords.remove(testWord);
					return testWord;
				}
			}
			throw new NoPossibleChainException();
		//return "thisshouldntbegiven";
	}
	
}
