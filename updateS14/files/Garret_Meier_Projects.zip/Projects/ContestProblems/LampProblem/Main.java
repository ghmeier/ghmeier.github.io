package LampProblem;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int numberOfLamps = 1;
		while (input.hasNext()) {
			numberOfLamps = input.nextInt();
			Lamp[] lamps = new Lamp[numberOfLamps];
			for (int i=0;i<numberOfLamps;i++) {
				lamps[i] = new Lamp(input.next());
			}
			for (int i=0;i<numberOfLamps;i++) {
				int status = input.nextInt();
				if (status == 0) {
					lamps[i].turnOff();
				} else {
					lamps[i].turnOn();
				}
			}
			
			for (int i=0; i<numberOfLamps;i++) {
				System.out.print(lamps[i].toString()+" ");
			}
			System.out.println("");
		}
	}
}
