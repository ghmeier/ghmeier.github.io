package LampProblem;

public class Lamp {
	public boolean status;
	public String name;
	
	public Lamp(String s) {
		this.name = s;
	}
	
	public void turnOn() {
		status = true;
	}
	
	public void turnOff() {
		status = false;
	}
	
	public boolean isOn() {
		return status;
	}
	
	public String toString() {
		if(this.isOn()) {
			return name + " is ON";
		}
		return name + " is OFF";
		
	}
}
