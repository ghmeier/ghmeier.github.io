package TextualCheckerBoard;

import java.util.Scanner;

//Textual CheckerBoard
//by garret meier

public class Main {

	
	public static void main (String[] args) {
		
		Scanner s = new Scanner(System.in);
		
		int cells = s.nextInt();
		if (cells<0) {
			//System.out.println("Please enter a positive number next time, you can't have negative numbers");
			cells = -cells;
		}
		for (int i=0;i<cells;i++) {
			for (int j=0;j<cells;j++) {
				System.out.print("+---");
			}
			System.out.println("+");
			for (int x=0; x<3;x++) {
				for (int j=0;j<cells;j++) {
					System.out.print("|   ");				
				}
				System.out.println("|");
			}
			
		}
		
		for (int j=0;j<cells;j++) {
			System.out.print("+---");
		}
		System.out.println("+");
	}
}
