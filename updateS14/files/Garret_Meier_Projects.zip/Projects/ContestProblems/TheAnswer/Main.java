package TheAnswer;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		ArrayList<String> entered = new ArrayList<String>();
		
		while(input.hasNext()) {
			entered.add(input.next());
			if (entered.contains("42")) {
				entered.remove("42");
				break;
			}
		}
		
		for (String s : entered) {
			System.out.println(s);
		}
	}
}
