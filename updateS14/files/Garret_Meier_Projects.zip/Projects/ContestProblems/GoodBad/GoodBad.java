import java.util.Scanner;


public class GoodBad {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int iterations = in.nextInt();
		in.nextLine();
		String[] names = new String[iterations];
		for (int i=0;i<iterations;i++) {
			names[i] = in.nextLine();
			int j=0;
			int bCount = 0;
			int gCount = 0;
			while (j<names[i].length()) {
				if (names[i].charAt(j)=='g' || names[i].charAt(j)=='G') {
					gCount++;
				} else if(names[i].charAt(j)=='b' || names[i].charAt(j)=='B'){
					bCount++;
				}
				j++;
			}
			if (gCount>bCount) {
				System.out.println(names[i]+" is GOOD");
			} else if(bCount>gCount) {
				System.out.println(names[i] + " is A BADDY");
			} else {
				System.out.println(names[i] + " is NEUTRAL");
			}
		}
		
	}
}
