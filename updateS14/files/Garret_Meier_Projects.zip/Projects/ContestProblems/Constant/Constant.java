import java.math.BigInteger;
import java.util.Scanner;


public class Constant {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		while(in.hasNext()) {
			String dir = in.next();			
			String line = in.nextLine();			
			String[] constants = line.split(",");
			String out = "\t";
			
			if (dir.equals("db")) {
				out += ".byte\t";
			} else if(dir.equals("dw")){
				out += ".word\t";
			} else if(dir.equals("dd")) {
				out += ".long\t";
			} else if(dir.equals("dq")) {
				out+= ".quad\t";
			}		
			
			for (int i=0;i<constants.length;i++) {
				constants[i] = constants[i].trim();
				if (constants[i].endsWith("h")) {
					out = out + ("0x" + constants[i].substring(0, constants[i].length()-1)) + ", ";
				} else if(constants[i].endsWith("b")) {
					out = out + "0x" +toHex(constants[i]) + ", ";
				}else if(constants[i].endsWith("o")) {
					out = out + ("0"+constants[i].substring(0,constants[i].length()-1))+ ", ";
				}else if(constants[i].endsWith("d")){
					out = out + (constants[i].substring(0,constants[i].length()-1)) + ", ";
				}else {
					out = out + constants[i] + ", ";
				}
			}
			out = out.substring(0,out.length()-2);
			System.out.println(out);
			
			
		}		
		
	}
	
	public static String toHex(String in) {
		long answer = 0;
		int place = 0;
		for (int i= in.length()-2;i>=0;i--) {
			if (in.charAt(i)=='1') {
				
				answer += Math.pow(2, place);
				//System.out.println(in.charAt(i) + " "+ answer + " " + place);
			}
			place ++;
		}
		//System.out.println(answer);
		if (answer>4000000) {answer--;}
		return Long.toHexString(answer);
	}
	

}
