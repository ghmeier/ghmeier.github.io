package IntersectingRectangles;

import java.util.Scanner;

public class Main {
	public static int[] test1 = new int[] {0,0,10,10};
	public static int[] test2 = new int[] {12,0,14,10};
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int[] rectOne = new int[4];
		for (int i=0;i<=4;i++) {
			rectOne[i] = s.nextInt(); 
		}
		int[] rectTwo = new int[4];
		for (int i=0;i<=4;i++) {
			rectTwo[i] = s.nextInt(); 
		}
		
		if (areIntersecting(rectOne,rectTwo)) {
			System.out.println("INTERSECTING");
		} else {
			System.out.println("DISJOINT");
		}
		
	}
	
	
	public static boolean areIntersecting(int[] rect1, int[] rect2) {
		if ((rect1[0]<rect2[0] && rect1[2]>rect2[0]) || (rect2[0]<rect1[0] && rect2[2]>rect1[0]) || rect1[0]==rect2[0] || rect1[0]==rect2[2] || rect1[2]==rect2[0] || rect1[2]==rect2[2]) {
			if ((rect1[1]<rect2[1] && rect1[3]>rect2[1]) || (rect2[1]<rect1[1] && rect2[3]>rect1[1]) || rect1[1]==rect2[1] || rect1[1]==rect2[3] || rect1[3]==rect2[1] || rect1[3]==rect2[3]) {
				return true;
			}
		}
		return false;
	}
}
