import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;


public class Pascal {
	public static int[][] array;
	public static BigInteger one = new BigInteger("1");
	public static BigInteger zero = new BigInteger("0");
	public static boolean[][] done;
	public static long[][] values;
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		int n = 0;
		
		while(n!=-1) {
			n = in.nextInt();
			if (n==-1) {
				break;
			}
			in.nextLine();
			array = new int[n][n];
			done = new boolean[n][n];
			values = new long[n][n];
			
			for (int i=0;i<n;i++) {
				String line = in.nextLine();
				for (int j=0;j<n;j++) {				
					array[j][i] = line.charAt(j)-48;
				}	
			}
			
			System.out.println(legalMove(0,0));
		}
		
	}
	
	public static long legalMove(int x, int y) {
			if (x==array.length-1 && y==array.length-1) {
				return 1;
			}else if(x<array.length && y<array[0].length && done[x][y]) {

				return values[x][y];
			} else if (x<array.length && y<array[0].length && array[x][y]>0) {
				done[x][y] = true;
				values[x][y]=legalMove(x+array[x][y],y)+(legalMove(x,y+array[x][y]));
				return legalMove(x+array[x][y],y)+(legalMove(x,y+array[x][y]));
			}else {
				return 0;
			}

		
	}
}
