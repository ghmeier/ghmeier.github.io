import java.util.Scanner;


public class RateOfReturn {
	public static void main(String args[]) {
	Scanner in = new Scanner(System.in);
	int pairs =0;
	int cas = 1;
	while(pairs!=-1) {
		
		pairs = in.nextInt();
		if(pairs==-1){break;}
		double[] investments = new double[pairs+1];
		int[] months = new int[pairs+1];
		for (int i=0;i<investments.length;i++) {
			months[i] = in.nextInt();
			investments[i] = in.nextDouble();
		}
		double total = investments[investments.length-1];
		int lastMonth = months[investments.length-1];
		double currentTotal = 0;
		double i = .00000;
		while(currentTotal<total) {
			i+=.000001;
			currentTotal = 0;
			for(int j=0;j<investments.length-1;j++) {
				currentTotal = currentTotal + investments[j] * Math.pow((i+1),lastMonth - months[j] + 1);
			}
			
		}
		System.out.printf("Case %d: %.5f\n\n",cas,i);
		cas++;
	}
		
		
	}
	
}
