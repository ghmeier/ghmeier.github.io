package NewRuler;

import java.util.ArrayList;
import java.util.Scanner;

//New Ruler
//garret meier

public class Main {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		ArrayList<Integer> marks = new ArrayList<Integer>(0);
		int count=1;
		
		int currentNum = s.nextInt();
		while (currentNum>=0) {
			marks.add(currentNum);
			currentNum = s.nextInt();
		}
		
		ArrayList<Integer> distances = new ArrayList<Integer>();
		for (Integer i:marks) {
			for (Integer j:marks) {
				if (i!=j) {
					distances.add(Math.abs(i-j));
					//System.out.print(Math.abs(i-j));
				}
			}
		}
		boolean isGood = true;
		while(isGood) {
			if(distances.contains(count)) {
				count++;
			} else {
				isGood = !isGood;
			}
		}
		
		System.out.println(count);
		
		
	}
	
}
