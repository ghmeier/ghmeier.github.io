package NthLargest;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner (System.in);
		int numberOfLists = in.nextInt();
		for (int x=1;x<=numberOfLists;x++) {
			int length = 10;
			in.nextInt();
			int[] list = new int[length];
			for (int i=0;i<length;i++) {
				list[i] = in.nextInt();
			}
			list = sort(list);
			System.out.println(x+" "+list[list.length-3]);
		}
	}
	
	public static int[] sort(int[] list) {
		int[] possible = new int[1001];
		for(int i=0;i<list.length;i++) {
			possible[list[i]] ++;
		}
		int count =0 ;
		for(int i=0;i<possible.length;i++) {
			if(possible[i]>0) {
				list[count]=i;
				possible[i] --;
				i --;
				count++;
			} else {
				
			}
		}
		
		return list;
	}
}
