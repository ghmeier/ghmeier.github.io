import java.util.Scanner;


public class SpeedRacer {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		while (in.hasNext()) {
			double a = in.nextDouble();
			double b = in.nextDouble();
			double c = in.nextDouble();
			double d = in.nextDouble();
			double m = in.nextDouble();
			double t = in.nextDouble();
			double answer = 0.0;
			double v= 0.00000001;
			answer = v*v*v*(a*v+b) + v*(c*v+d);
			//System.out.printf("%.2f,%f\n",v,answer);
			v  = calculate(v,0.00001,a,b,c,d,m,t);
			//System.out.println(v);
			//v=v-.0001;
			Double x = new Double(v);
			String end = x.toString();
			int vale = end.indexOf(".");
			end = end.substring(0, vale+3);
			//double fin = Math.floor(v*100);
			System.out.println(end);
		}
		
	}
	
	public static double calculate(double v, double precision, double a, double b, double c, double d,double m, double t) {
		double answer = v*v*v*(a*v+b) + v*(c*v+d);
		while (answer/v*m<=t) {
		answer = v*v*v*(a*v+b) + v*(c*v+d);
		v=v+precision;
		//System.out.printf("%f,%.2f\n",v,answer);
		}
		if (precision<.0000001) {
			return v-precision;
		} else {
			return calculate(v-precision,precision/10,a,b,c,d,m,t);
		}
	}
}
