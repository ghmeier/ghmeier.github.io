package SixthGradeMath;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int iterations = in.nextInt();
		for(int i=1;i<=iterations;i++) {
			int first = in.nextInt();
			int second = in.nextInt();
			System.out.printf("%d %d %d\n",i,leastCommonMultiple(first, second),greatestCommonFactor(first, second));
		}
	}
	
	public static int leastCommonMultiple(int first,int second) {
		int count = 2;
		
		while(count%first!=0 || count%second!=0) {
			count++;
		}
		
		return count;
		
	}
	
	public static int greatestCommonFactor(int first, int second) {
		int answer = 0;
		int lower = 0;
		if(first<second) {
			lower = first;
		} else {
			lower = second;
		}
		
		for (int i=1;i<=lower;i++) {
			if(first%i==0 && second%i==0) {
				answer = i;
			}
		}
		
		return answer;
	}

}
