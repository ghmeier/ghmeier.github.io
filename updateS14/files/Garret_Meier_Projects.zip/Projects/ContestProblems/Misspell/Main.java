package Misspell;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int numberOfIterations = in.nextInt();
		for(int i=1;i<=numberOfIterations;i++) {
			int indexToRemove = in.nextInt();
			String word = in.next();
			String firstHalf = word.substring(0,indexToRemove-1);
			String secondHalf = word.substring(indexToRemove,word.length());
			word = firstHalf + secondHalf;
			System.out.println(i+" "+ word);
			
		}
		
		
	}
}
