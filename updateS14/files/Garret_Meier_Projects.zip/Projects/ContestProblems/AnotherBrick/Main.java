package AnotherBrick;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static int[][] checked;
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int sets = in.nextInt();
		for (int set=1;set<=sets;set++) {
			
			int y = in.nextInt();
			int x = in.nextInt();
			char[][] wall = new char[x][y];
			checked = new int[x][y];
			for (int j=0; j<wall[0].length;j++) {//load em in
				String temp = in.next();
				for (int i=0; i<wall.length;i++) {
					wall[i][j]=temp.charAt(i);
				}
				//printArray(wall);
			}
			
			int fewest = Integer.MAX_VALUE;
			int[] def = new int[]{-1,-1};
			//printArray(wall);
			//now iterate by column removing bricks to see which is fewest
			for(int i=0;i<wall.length;i++) {
				int count = 0;
					int[] current = new int[]{i,0};
					while (current[0]<=wall.length-1 && current[1]<=wall[0].length-1) {
						current = isGap(current[0],current[1],wall,wall[current[0]][current[1]]);
						//System.out.println(wall[current[0]][current[1]] + " "+current[0]+","+current[1]);
						if (current[1]<=wall[0].length-1) {
							current[1] = current[1]+1;
							count++;
						}
					}
					if (count<fewest) {
						fewest = count;
					}
			}
			
			System.out.println(fewest);
		}
		
	}
	
	public static void printArray(char[][] out) {
		for (int j=0; j<out[0].length;j++) {//load em in
			for (int i=0; i<out.length;i++) {
				if (out[i][j]==0) {
					System.out.print(" ");
				} else {
				System.out.print(out[i][j]);
				}
			}
			System.out.println("");
		}
		
	}
	
	public static boolean isOpen(int x, int y, char[][] test,char name) {
		if (x>=test.length || x<0) {
			return false;
		} else if(y>=test[0].length || y<0) {
			return false;
		}
		return test[x][y]==name;
	}
	
	public static int[] isGap(int x, int y,char[][] test, char name) {
			int[] current = new int[]{x,y};
			if (checked[x][y]==0) {
				//System.out.println(current[0]+ " " + current[1]);
				checked[x][y]=1;
			}
			if (isOpen(x,y+1,test,name) && checked[x][y+1]==0) {
				return isGap(x,y+1,test,name);
			} else if(isOpen(x+1,y,test,name) && checked[x+1][y]==0) {
				return isGap(x+1,y,test,name);
			} else if(isOpen(x-1,y,test,name) && checked[x-1][y]==0) {
				//System.out.println(name + " "+x+","+y);
				return isGap(x-1,y,test,name); 
			}else if(isOpen(x,y-1,test,name) && checked[x][y-1]==0) {
				return isGap(x,y-1,test,name);
			}else {
				//System.out.println(name + " "+x+","+y);
				return new int[]{x,y};
			}
	}

}
