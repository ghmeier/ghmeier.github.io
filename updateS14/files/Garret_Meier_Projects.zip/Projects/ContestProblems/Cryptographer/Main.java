package Cryptographer;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int numberOfIterations = in.nextInt();
		in.nextLine();
		String answer;
		for (int iteration=1;iteration<=numberOfIterations;iteration++) {
		String toDecode  = in.nextLine();
		String key = in.nextLine();//26 long 'alphabet'
		answer = "";
		for (int i=0;i<toDecode.length();i++) {
			char current = toDecode.charAt(i);
			if (current!=' ') {
				int currentVal = (int)(current-65);
				answer = answer + (char)(key.charAt(currentVal));
			} else {
				answer = answer + " ";
			}
		}
		System.out.println(iteration+ " " +answer);
		}
	}
}
