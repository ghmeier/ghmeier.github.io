package EveryDayImShuffling;

import java.util.Scanner;

//Non-Random Shuffling
//Garet Meier Andy Eagle

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int[] deck = new int[input.nextInt()];
		 for (int i=1; i <=deck.length; i++) {
			 deck[i-1] = i;
		 }	 
		 
		 int[] newDeck = shuffle(deck);

		 for (int i = 0; i < deck.length; i++) {
			 System.out.print(newDeck[i]+" ");//Output the deck
		 }
		 System.out.println("");
		 
		 while  (!isEqual(deck,newDeck)) {
			 newDeck = shuffle(newDeck);
			 for (int i = 0; i< deck.length; i++) {
				 System.out.print(newDeck[i]+ " ");
			 }
			 System.out.println("");
		 }
		 
	}
	
	public static boolean isEqual(int[] test, int[] test1) {
		for (int i=0;i<test.length;i++) {
			if (test[i]!=test1[i]) {
				return false;
			}
		}
		return true;
	}
	
	public static int[] shuffle(int[] array) {
		int[] deck1 = new int[array.length/2];
		int[] deck2 = new int[array.length/2];
		
		for (int i = 0; i < array.length/2; i++) {
			deck1[i] = array[i];
		}
		for (int i = 0; i < array.length/2; i++) {
			deck2[i] = array[i+(array.length/2)];

		}
		int[] answer = new int[array.length];
		for (int i =0; i< array.length; i ++) {
			if (i%2 == 0) {
				answer[i] = deck1[i/2];
			} else {
				answer[i] = deck2[(i-1)/2];
			}
		}
		return answer;
		
	}
}
