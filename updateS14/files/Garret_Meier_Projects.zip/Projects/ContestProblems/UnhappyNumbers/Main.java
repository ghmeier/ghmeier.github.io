package UnhappyNumbers;

import java.util.Scanner;

//Unhappy numbers :(
//Garret Meier

public class Main {
	public static final int THRESHHOLD = 1000;
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		int lo = s.nextInt();
		int hi = s.nextInt();
		int unhappycount = 0;
		
		for (int i=lo;i<=hi;i++) {
			if(!isHappy(i,0)) {
				unhappycount++;
			} else {
				//System.out.println("It's happy " + i);
			}
		}
			System.out.println(unhappycount+"");

	}
	
	public static boolean isHappy(int check, int timesThrough) {
		int sum = 0 ;
		if (timesThrough<THRESHHOLD) {
			while (check>0) {

				sum = sum+(check%10)*(check%10);
				//System.out.println("Sum "+sum + " check "+check+ " other "+ (check%10)+ " through "+timesThrough);
				check = check/10;
			}
			if (sum==1) {
				return true;
			} else {
				return isHappy(sum,timesThrough+1);
			}
		} else {
			return false;
		}
	}
}
