import java.math.BigInteger;
import java.util.Scanner;
public class saruman {
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		while(scan.hasNextLong()){
			long n = scan.nextLong();
			scan.nextLine();
			long level = 0;
			for(long i = 1; i<=n; i++ ){
				
			
				/*String b = convertToBinary(i);
				int total = 0;
				for(int j = 0; j < b.length(); j++){
					String sub = b.substring(j
							, j+1);
					if(sub.equals("1")){
						total++;
					}
				}*/
				if(Long.bitCount(i)%3 == 0){
					level++;
					//System.out.println(i+ " "+ level);
				}
			}
			System.out.printf("Day %d: Level = %d\n", n,level);
		}
		scan.close();
		
	}

	
	public static String convertToBinary(int n){
		int r;
		String binary = "";
		while(n > 1){
			r = n%2;
			n = n / 2;
			binary = r + binary;
			
			
		}
		binary = n + binary;
		return binary;
	}
}
