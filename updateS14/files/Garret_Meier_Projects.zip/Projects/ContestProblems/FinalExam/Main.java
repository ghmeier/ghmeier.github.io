package FinalExam;

import java.util.Scanner;

//Final Exam
//Garret Meier and Andy Eagle

public class Main {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		int desiredGrade = s.nextInt();
		int numberOfTests = s.nextInt();
		int[] percentageWeights = new int[numberOfTests];
		for (int i=0; i<numberOfTests; i++) {
			percentageWeights[i] = s.nextInt();
		}
		int[] scores = new int[numberOfTests-1];
		for (int i=0; i<numberOfTests-1; i++) {
			scores[i]=s.nextInt();
		}
		
		int sum = 0;
		for (int i=0; i<scores.length;i++) {
			scores[i] = toPoint(scores[i], percentageWeights[i]);
			sum = sum + scores[i];
		}
		
		int requiredScore = getTest(sum,numberOfTests,desiredGrade,percentageWeights[percentageWeights.length-1]);
		if (requiredScore<0) {
			System.out.println("Impossible");
		} else {
			System.out.println(requiredScore);
		}

	}
	
	public static int toPoint(int enter, int weight) {
		return enter*weight;
	}
	
	public static int getTest(int sumOfPrev, int totalNumber, int threshhold, int weight) {
		//System.out.println(sumOfPrev+" "+weight);
		for (int i=0;i<=100;i++) {
			//System.out.println((i*weight+sumOfPrev)/(100));
			if ((i*weight+sumOfPrev)/(100)>=threshhold) {
				return i;
			}
		}
		return -1;
	}
}
