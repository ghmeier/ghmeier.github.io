package BinaryClock;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in); 
		int numberOfTimes = in.nextInt();
		in.nextLine();
		for (int x=1;x<=numberOfTimes;x++) {
		String time = in.nextLine();
		int[] h = convert(Integer.valueOf(time.substring(0, 2)));
		int[] m = convert(Integer.valueOf(time.substring(3, 5)));
		int[] s = convert(Integer.valueOf(time.substring(6)));
		System.out.print(x + " ");
		for (int i=5;i>=0;i--) {
		System.out.printf("%d%d%d",h[i],m[i],s[i]);
		}
		System.out.printf(" ");
		for (int i=5;i>=0;i--) {
			System.out.print(h[i]);
		}
		for (int i=5;i>=0;i--) {
			System.out.print(m[i]);
		}
		for (int i=5;i>=0;i--) {
			System.out.print(s[i]);
		}
		System.out.printf("\n");
		}
		
		
	}
	
	public static int[] convert(int decimal) {
		int[] answer = new int[6];
		int base = 2;
		int count = 0;
			while (decimal>0) {
					answer[count] = decimal%base;
					decimal = decimal/base;
					count++;
			}
		return (answer);
	}
}
