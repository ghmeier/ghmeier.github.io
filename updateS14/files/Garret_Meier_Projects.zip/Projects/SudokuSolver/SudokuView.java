import java.util.Scanner;

import javax.swing.Box.Filler;


public class SudokuView {
	public static void main(String[] args) {
		int [][] uL = new int [][] {{0,2,7},{0,5,1},{0,0,4}};
		int [][] uC = new int [][] {{0,5,8},{9,0,0},{6,0,1}};
		int [][] uR = new int [][] {{0,1,0},{0,6,7},{0,8,2}};
		int [][] cL = new int [][] {{5,0,3},{2,0,8},{9,0,0}};
		int [][] cC = new int [][] {{0,0,0},{7,3,0},{4,8,2}};
		int [][] cR = new int [][] {{2,4,0},{6,0,0},{7,3,5}};
		int [][] lL = new int [][] {{1,6,0},{0,8,0},{7,3,0}};
		int [][] lC = new int [][] {{2,0,7},{0,9,3},{0,1,0}};
		int [][] lR = new int [][] {{8,0,0},{1,0,6},{4,0,9}};//the 3x3 boxes within the 9x9 board
		
		int[][][][] gameBoard = new int[3][3][3][3]; //{{uL,uC,uR},{cL,cC,cR},{lL,lC,lR}};//the board gets filled with boxes
		Scanner input = new Scanner(System.in);
		String puzzle = input.next();
		int count = 0;
		for (int row=0; row<9;row++){
			for (int column=0; column<9;column++) {
				if (puzzle.charAt(count)=='.') {
					gameBoard[row/3][column/3][row%3][column%3]=0;
				} else {
					gameBoard[row/3][column/3][row%3][column%3]=puzzle.charAt(count)-48;
				}
				count++;
			}
		}
		
		SudokuModel model = new SudokuModel(gameBoard);
		
		printBoard(gameBoard);
		
		count = 0 ;
		//while (!model.isComplete()) {
		while(count<6) {
			System.out.println("^After "+count+" rounds^");
			model.fillBoard();
			printBoard(gameBoard);
			count++;
			
		}
		
	}
	
	public static void printBoard(int[][][][] gameboard) {
		for (int i=0;i<9;i++) {//y direction
			for (int j=0;j<9;j++) {//xdirection
				if (gameboard[i/3][j/3][i%3][j%3]!=0) {
				System.out.print(gameboard[i/3][j/3][i%3][j%3]+" ");
				}else {
					System.out.print("- ");
				}
			}
			System.out.println("");
			
		}
		
	}
}
