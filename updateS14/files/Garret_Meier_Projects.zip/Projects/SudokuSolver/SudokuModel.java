
public class SudokuModel {
	private int[][][][] gameBoard;
	
	public SudokuModel(int[][][][] gameBoard) {
		this.gameBoard = gameBoard;
		
	}
	
	public int[][][][] getGameBoard() {
		return this.gameBoard;
	}
	
	public int getCell(int row, int column) {
		return this.gameBoard[row/3][column/3][row%3][column%3];
	}
	
	public int getCell(int row, int column, int x, int y) {//for specific spots
		return this.gameBoard[row/3][column/3][x][y];
	}
	
	public void setCell(int row, int column, int toSet) {
		this.gameBoard[row/3][column/3][row%3][column%3]=toSet;
	}
	
	private boolean rowIsFree(int row, int toCheck) {
		if (row<0 || row>8) {
			return false;
		} else {
			for (int column=0;column<9;column++) {
				if (spaceIsEqual(row, column, toCheck)) {
					return false;
				}
			}
		}
		return true;
	}
	
	private boolean columnIsFree(int column, int toCheck) {
		if (column<0 || column >8) {
			return false;
		} else {
			for (int row=0;row<9;row++) {
				if (spaceIsEqual(row, column, toCheck)) {
					return false;
				}
			}
		}
		return true;
	}
	
	private boolean boxIsFree(int row,int column, int toCheck) {
		for (int x=0;x<3;x++) {
			for (int y=0;y<3;y++) {
				if (spaceIsEqual(row, column,x,y, toCheck)) {
					return false;
				}
			}
		}
		return true;
	}
	
	private boolean spaceIsEqual(int row,int column,int x,int y, int toCheck) {
		return (getCell(row,column,x,y)==toCheck);
	}
	
	private boolean spaceIsEqual(int row,int column, int toCheck) {
		return (getCell(row,column)==toCheck);
	}
	
	
	private boolean isEmpty(int row, int column) {
		return spaceIsEqual(row, column, 0);
	}
	
	private int emptyColumn(int column,int toCheck) {
		int emptyCounter = 0;
		int base = (column/3) * 3;
		for (int x=base;x<base+3;x++) {
			if (columnIsFree(x,toCheck)) {
				emptyCounter ++;
			}
		}
		return emptyCounter;
	}
	
	private int emptyRow(int row,int toCheck) {
		int emptyCounter = 0;
		int base = (row/3) *3;
		for (int x=base;x<base+3;x++) {
			if (rowIsFree(x,toCheck)) {
				emptyCounter ++;
			}
		}
		return emptyCounter;
	}
	
	private int emptyInBoxColumn(int row, int column) {
		int emptyCounter = 0;
		for (int x=0;x<3;x++) {
			if (spaceIsEqual(row, column,row%3,x,0)) {
				emptyCounter ++;
			}
		}
		return emptyCounter;
	}
	
	private int emptyInBoxRow(int row, int column) {
		int emptyCounter = 0;
		for (int x=0;x<3;x++) {
			if (spaceIsEqual(row, column,x,column%3,0)) {
				emptyCounter ++;
			}
		}
		return emptyCounter;
	}
	
	private int sumOfRow(int row) {
		int sum = 0;
		for (int column=0; column<9; column++) {
			sum = sum + getCell(row,column);
		}
		
		return sum;
	}
	
	private int sumOfColumn(int column) {
		int sum = 0;
		for (int row=0; row<9; row++) {
			sum = sum + getCell(row,column);
		}
		
		return sum;
	}
	
	public boolean legalMove(int toPlace, int row, int column) {
		if (boxIsFree(row,column,toPlace) && rowIsFree(row,toPlace) && columnIsFree(column,toPlace)) {//Checks the 3x3, row and column for the same number
			if (sumOfRow(row)>=36) {
				setCell(row,column,45-sumOfRow(row));
			} else if(sumOfColumn(column)>=36) {
				setCell(row,column,45-sumOfColumn(column));
			}
			if (emptyRow(row, toPlace)==1) {//Checks for the number of rows in the sector which don't contain toPlace
				if (emptyColumn(column,toPlace)==1) {//As previous but with columns
					return true;//if all of those then this is a perfect spot to place the number
				} else {
					if (emptyInBoxRow(row, column)==1) {//looks at the empty spaces in this row within the box.
						return true;
					} else {
						return false;
					}
				}
			} else {
				if (emptyInBoxColumn(row, column)==1) {//looks at the empty space in the column within this box
					return true;
				} else {
					return false;
				}
			}
		} else {
			return false;
		}
	}
	
	public void placeNumber(int toPlace, int row, int column) {//Just sets the space equal to toPlace
		setCell(row,column,toPlace);
		System.out.println(toPlace+ " placed here: "+row/3+" "+column/3+" "+row%3+" "+column%3);
	}
	
	public boolean isComplete() {//looks for incomplete spaces in the board
		for (int row = 0;row<9;row++) {
			for (int column = 0; column<9; column++) {
				if (isEmpty(row,column)) {
					return false;
				}
			}
		}
		return true;
	}
	
	public void fillBoard() {//from top-left to bottom right goes through the board, checks to see that it's ok to place them, and the puts them in the current position
			for (int row=0;row<9;row++) {
				for (int column=0;column<9;column++) {
					for (int number=1;number<=9;number++) {
						if (isEmpty(row,column)) {							
							if (legalMove(number,row,column)) {
								placeNumber(number, row, column);
								//System.err.println(number+" at "+row+","+column+" placed");
							} else {
								//System.err.println(number+" at "+row+","+column+" is illegal");
							}
						}
					}
				}
		}
		
	}
}
