package quickGenerator;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class DNDParser {
	private String filePath;
	private File dndFile;
	private Scanner s;
	private Pattern startPattern = Pattern.compile("<.*>");
	private Pattern endPattern = Pattern.compile("</.*>");
	
	public static void main(String[] args) {
		DNDParser parser = new DNDParser("info.dnd");
		String tag = "";
		while (tag!="</dnd>" && tag!=null) {
			tag = parser.nextTag();
			System.out.println(tag);
		}
	}
	
	public DNDParser(String filePath){
		this.filePath = filePath;
		this.dndFile = new File(filePath);
		try {
			this.s = new Scanner(this.dndFile);
		} catch (FileNotFoundException e) {
			System.err.println(".dnd file does not exist at "+this.filePath);
			e.printStackTrace();
		}
	}
	
	private String nextTag(){
		while (s.hasNext()) {
			if (s.hasNext(startPattern)) {
				return s.next(startPattern);
			}else if (s.hasNext(endPattern)){
				return s.next(endPattern);
			}
			s.next();
		}
		return null;
	}
	
	public boolean hasNextTag(){
		if (s.hasNext(startPattern) || s.hasNext(endPattern)) {
			return true;
		} else {
			return false;
		}
	}
}
