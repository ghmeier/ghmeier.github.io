package quickGenerator;

public class NoMoreTagException extends Exception {
	public NoMoreTagException(){
		super();
	}
}
