package quickGenerator;

public class MainApplication {

}
