package quickGenerator;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class Class {
	public static Map<String,Class> allClasses = new HashMap<String,Class>();
	
	private String className;
	private int hitDie;
	private HashSet<String> classSkills = new HashSet<String>();
	private int skillModifier;
	private HashSet<String> proficiencies = new HashSet<String>();
	private int baseFortSave;
	private int baseRefSave;
	private int baseWillSave;
	private int baseBA;
	private double BAIncrement;
	private double FortSaveIncrement;
	private double WillSaveIncrement;
	private double RefSaveIncrement;
	private int baseArmor;
	private Map<Integer,String> abilities = new HashMap<Integer,String>();
	
	public Class(String className) {
		this.className = className;
	}
	
	public String getClassName() {
		return this.className;
	}
	
	public int getHitDie() {
		return this.hitDie;
	}
	
	public HashSet<String> getClassSkills() {
		return this.classSkills;
	}
	
	public int getSkillModifier() {
		return this.skillModifier;
	}
	
	public HashSet<String> getProficiencies() {
		return this.proficiencies;
	}
	
	public String getAbility(int level) {
		if (this.abilities.containsKey(level)) {
			return this.abilities.get(level);
		} else {
			return "NA";
		}
	}
	
	public int getBaseArmor() {
		return this.baseArmor;
	}
	
	public Character levelUp(Character c) {
		
	}
}
