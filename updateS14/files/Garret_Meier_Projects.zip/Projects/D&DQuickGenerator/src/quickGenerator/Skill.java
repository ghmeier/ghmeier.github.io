package quickGenerator;

public class Skill {
	public static final byte STR = 0;
	public static final byte DEX = 1;
	public static final byte CON = 2;
	public static final byte INT = 3;
	public static final byte WIS = 4;
	public static final byte CHA = 5;
	
	private byte abilityMod;
	private int ranks;
	private int misc;
	
	public Skill(byte abilityMod) {
		this.abilityMod = abilityMod;
	}
	
	public getSkillMod(Character c) {
		return this.ranks + this.misc + c.getMod(stat)
	}
}
