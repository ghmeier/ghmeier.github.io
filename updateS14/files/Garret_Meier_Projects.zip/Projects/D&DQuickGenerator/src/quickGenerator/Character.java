package quickGenerator;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class Character {
	private String name;
	private String race;
	private String theClass;
	private int level;
	private String alignment;
	private String diety;
	private String size;
	private int age;
	private String gender;
	private int height;//in inches
	private int weight;
	private int str;
	private int dex;
	private int con;
	private int intel;
	private int wis;
	private int cha;
	private int baseFort;
	private int baseRef;
	private int baseWill;
	private int baseAttack;
	private int health;
	private int baseArmor;
	private Map<String,Integer> skills = new HashMap<String,Integer>();
	private HashSet<String> feats = new HashSet<String>();
	private HashSet<String> abilities = new HashSet<String>();
	
	public Character(String name,String race, String theClass) {
		
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getRace() {
		return this.race;
	}
	
	public String getTheClass() {
		return this.theClass;
	}
	
	public int getGrapple() {
		return this.baseAttack + getMod(this.str);
	}
	
	public int getInitiative() {
		return getMod(this.dex);
	}
	
	public HashSet<String> getAbilities() {
		return this.abilities;
	}
	
	public int getAge() {
		return this.age;
	}
	
	public String getAlignment(){
		return this.alignment;
	}
	
	public int getArmorClass() {
		return getMod(this.dex) + this.baseArmor;
	}
	
	public int getBaseAttack() {
		return this.baseAttack;
	}
	
	public int getFort() {
		return this.baseFort + getMod(this.con);
	}
	
	public int getRef() {
		return this.baseRef + getMod(this.dex);
	}
	
	public int getWill() {
		return this.baseWill + getMod(this.wis);
	}
	
	public int getMod(int stat) {
		return stat/2 - 5;
	}
	
	public int getStat(byte stat) {
		if (stat==Skill.CHA) {
			return this.cha;
		}else if(stat==Skill.CON) {
			return this.con;
		}else if(stat==Skill.DEX) {
			return this.dex;
		}else if(stat==Skill.INT){
			return this.intel;
		}else if(stat==Skill.STR) {
			return this.str;
		}else if(stat==Skill.WIS){
			return this.wis;
		}else {
			return -1;
		}
	}
	
	public String getDiety() {
		return this.diety;
	}
	
	public HashSet<String> getFeats(){
		return this.feats;
	}
	
	public String getGender() {
		return this.gender;
	}
	
	public int getHealth(){
		return this.health;
	}
	
	public int getHeight() {
		return this.height;//in inches
	}
	
	public int getLevel(){
		return this.level;
	}
	
	public String getSize(){
		return this.size;
	}
	
	public int getWeight(){
		return this.weight;
	}
	
	public Map<String,Integer> getSkills() {
		return this.skills;
	}
	
	public int getSkillLevel(String skill) {
		if (this.skills.containsKey(skill)) {
			return this.skills.get(skill);
		}else {
			return -1;
		}
	}
}
