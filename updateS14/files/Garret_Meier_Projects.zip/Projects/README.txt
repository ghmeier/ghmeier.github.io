
==To follow is a brief description of the classes within this folder which I have worked on==

/ContestProblems/. - 
	*These are problems I completed as part of a team at Iowa State for the regional 
	ACM programming competition as well as solutions to high school programming competition
	problems.


/EulerProject/. - 
	*Problems designed to compute the answer to questions on projecteuler.net


/LostHope/src/squareinfinity/. - 
	*Project I worked on as part of Square Infinity which is similar to minecraft or Terraria.
	 The class with the main method is LostHope.java. The class structures I wrote are to
	 follow.


 	*WorldGenerator and supporting classes* 
 	Biome		Chest		Design		DownSlope	Flora	ForestBiome
 	Grass		HillsBiome	HouseDesign	SemiFlat 	NPC	SuperFlat
 	Tree		TerrainType	UpSlop		
 
 	/LostHope/src/squareinfinity/npc/.
 	*NPC class Heirarchy*
 	AI	AngryEnemyAI	Animal	Bear	BlockAI		BunnyAI
 	Bunny	BunnyAI		ButterflyAI	EnemyAI		Wolf
 	WolfAI 
 
 	LostHope/src/squareinfinity/Pic/.
 	*I created all images except Hero.png*
  
 	*Game Controls-
 	WASD - movement
 	Space- use weapon
 	E    - fly
 	C    - craft menu
 	I	  - inventory (Right click to equip items)
 	Q    - break blocks


/OthelloGame/src/. - 
	*Created this game from scratch as part of my final project for my College java class. 
	 OthelloApplication contains the main method.
	

/planIt/. - 
	*A currently in progress side project which I intend to turn into a pc to-do list/planner application
	 with a more intuitive UI than current linear options to hopefully benefit college students
	 unsure of what's going on at any given time. I hope to transfer the project from pc to Android
	 as the next step and maybe help people know when their obligations occur.

/SudokuSolver/. - 
	*A fun side project I'm working on to make solving the daily sudoku problem in the paper a breeze. 